package com.notdogshit.exoscanner.illegal;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public enum IllegalType {
    EXOTIC,
    CRYSTAL,
    FAIRY,
    OG_FAIRY,
    BLEACHED,
    GLITCHED;

    private static final Set<String> CRYSTAL_COLORS = Set.of(
        "#FCF3FF", "#EFE1F5", "#E5D1ED", "#D9C1E3", "#C6A3D4", "#B88BC9",
        "#A875BD", "#9C64B3", "#8E51A6", "#7E4196", "#6A2C82", "#63237D",
        "#5D1C78", "#54146E", "#46085E", "#1F0030"
    );
    private static final Set<String> FAIRY_COLORS = Set.of(
        "#FFCCE5", "#FF99CC", "#FF66B2", "#FF3399", "#FF007F", "#CC0066",
        "#99004C", "#660033"
    );
    private static final Set<String> OG_FAIRY_COLORS = Set.of(
        "#FFCCFF", "#FF99FF", "#E5CCFF", "#CC99FF", "#FF66FF", "#FF33FF",
        "#B266FF", "#9933FF", "#FF00FF", "#CC00CC", "#7F00FF", "#6600CC",
        "#990099", "#660066", "#4C0099", "#330066"
    );
    private static final String BLEACHED_HEX = "#A06540";
    private static final Set<String> WITHER_SETS = Set.of("STORM", "NECRON", "GOLDOR", "MAXOR");
    private static final Set<String> WITHER_KEYS = Set.of(
        "WISE_WITHER", "POWER_WITHER", "TANK_WITHER", "SPEED_WITHER",
        "STORM", "NECRON", "GOLDOR", "MAXOR"
    );

    private static final String STORM_CHEST = "#1793C4";
    private static final String STORM_LEGS = "#17A8C4";
    private static final String STORM_BOOTS = "#1CD4E4";
    private static final String NECRON_CHEST = "#E7413C";
    private static final String NECRON_LEGS = "#E75C3C";
    private static final String NECRON_BOOTS = "#E76E3C";
    private static final String MAXOR_CHEST = "#4A14B7";
    private static final String MAXOR_LEGS = "#5D2FB9";
    private static final String MAXOR_BOOTS = "#8969C8";
    private static final String GOLDOR_CHEST = "#45413C";
    private static final String GOLDOR_LEGS = "#65605A";
    private static final String GOLDOR_BOOTS = "#88837E";

    private static final String SHARK_SCALE_COLOR = "#002CA6";
    private static final String SPONGE_COLOR = "#FFDC51";
    private static final String BLAZE_COLOR = "#F7DA33";
    private static final String FROZEN_BLAZE_COLOR = "#A0DAEF";

    public static IllegalType classify(String colorHex) {
        return classify(colorHex, null);
    }

    public static IllegalType classify(String colorHex, String armorKey) {
        if (colorHex == null) {
            return EXOTIC;
        }
        String normalized = normalize(colorHex);
        if (isGlitchedWither(armorKey, normalized)) {
            return GLITCHED;
        }
        if (isGlitchedPair(armorKey, normalized, "SHARK_SCALE", "SPONGE", SHARK_SCALE_COLOR, SPONGE_COLOR)) {
            return GLITCHED;
        }
        if (isGlitchedPair(armorKey, normalized, "FROZEN_BLAZE", "BLAZE", FROZEN_BLAZE_COLOR, BLAZE_COLOR)) {
            return GLITCHED;
        }
        if (CRYSTAL_COLORS.contains(normalized)) {
            return CRYSTAL;
        }
        if (FAIRY_COLORS.contains(normalized)) {
            return FAIRY;
        }
        if (OG_FAIRY_COLORS.contains(normalized)) {
            return OG_FAIRY;
        }
        if (BLEACHED_HEX.equals(normalized)) {
            return BLEACHED;
        }
        return EXOTIC;
    }

    private static boolean isGlitchedWither(String armorKey, String normalizedHex) {
        if (armorKey == null || armorKey.isBlank()) {
            return false;
        }
        String key = armorKey.trim().toUpperCase(Locale.ROOT);
        String set = resolveWitherSet(key);
        if (set == null || !WITHER_SETS.contains(set)) {
            return false;
        }
        String piece = resolvePiece(key);
        if (piece == null) {
            return false;
        }
        String ownColor = getWitherColor(set, piece);
        if (ownColor == null) {
            return false;
        }
        if (normalizedHex.equals(ownColor)) {
            return false;
        }
        for (String otherSet : WITHER_SETS) {
            if (otherSet.equals(set)) {
                continue;
            }
            String otherColor = getWitherColor(otherSet, piece);
            if (otherColor != null && normalizedHex.equals(otherColor)) {
                return true;
            }
        }
        return false;
    }

    private static String resolveWitherSet(String armorKey) {
        String key = armorKey.toUpperCase(Locale.ROOT);
        for (String token : WITHER_KEYS) {
            if (key.contains(token)) {
                if (token.contains("WISE_WITHER") || token.equals("STORM")) {
                    return "STORM";
                }
                if (token.contains("POWER_WITHER") || token.equals("NECRON")) {
                    return "NECRON";
                }
                if (token.contains("TANK_WITHER") || token.equals("GOLDOR")) {
                    return "GOLDOR";
                }
                if (token.contains("SPEED_WITHER") || token.equals("MAXOR")) {
                    return "MAXOR";
                }
            }
        }
        return null;
    }

    private static boolean isGlitchedPair(String armorKey, String normalizedHex, String setA, String setB,
                                          String colorA, String colorB) {
        if (armorKey == null || armorKey.isBlank()) {
            return false;
        }
        String set = resolveSetKey(armorKey);
        if (set == null) {
            return false;
        }
        if (!set.equals(setA) && !set.equals(setB)) {
            return false;
        }
        String piece = resolvePiece(armorKey);
        if (piece == null) {
            return false;
        }
        if (!isThreePieceType(piece)) {
            return false;
        }
        if (set.equals(setA)) {
            return normalizedHex.equals(colorB);
        }
        return normalizedHex.equals(colorA);
    }

    private static String resolveSetKey(String armorKey) {
        String key = armorKey.toUpperCase(Locale.ROOT);
        String wither = resolveWitherSet(key);
        if (wither != null) {
            return wither;
        }
        if (key.contains("SHARK_SCALE") || (key.contains("SHARK") && key.contains("SCALE"))) {
            return "SHARK_SCALE";
        }
        if (key.contains("SPONGE")) {
            return "SPONGE";
        }
        if (key.contains("FROZEN_BLAZE") || (key.contains("FROZEN") && key.contains("BLAZE"))) {
            return "FROZEN_BLAZE";
        }
        if (key.contains("BLAZE")) {
            return "BLAZE";
        }
        return null;
    }

    private static String resolvePiece(String armorKey) {
        if (armorKey.endsWith("_CHESTPLATE")) {
            return "CHESTPLATE";
        }
        if (armorKey.endsWith("_LEGGINGS") || armorKey.endsWith("_PANTS")) {
            return "LEGGINGS";
        }
        if (armorKey.endsWith("_BOOTS")) {
            return "BOOTS";
        }
        if (armorKey.endsWith("_HELMET")) {
            return "HELMET";
        }
        return null;
    }

    private static boolean isThreePieceType(String piece) {
        return "CHESTPLATE".equals(piece) || "LEGGINGS".equals(piece) || "BOOTS".equals(piece);
    }

    private static String getWitherColor(String set, String piece) {
        return switch (set) {
            case "STORM" -> switch (piece) {
                case "CHESTPLATE" -> STORM_CHEST;
                case "LEGGINGS" -> STORM_LEGS;
                case "BOOTS" -> STORM_BOOTS;
                default -> null;
            };
            case "NECRON" -> switch (piece) {
                case "CHESTPLATE" -> NECRON_CHEST;
                case "LEGGINGS" -> NECRON_LEGS;
                case "BOOTS" -> NECRON_BOOTS;
                default -> null;
            };
            case "MAXOR" -> switch (piece) {
                case "CHESTPLATE" -> MAXOR_CHEST;
                case "LEGGINGS" -> MAXOR_LEGS;
                case "BOOTS" -> MAXOR_BOOTS;
                default -> null;
            };
            case "GOLDOR" -> switch (piece) {
                case "CHESTPLATE" -> GOLDOR_CHEST;
                case "LEGGINGS" -> GOLDOR_LEGS;
                case "BOOTS" -> GOLDOR_BOOTS;
                default -> null;
            };
            default -> null;
        };
    }

    private static String normalize(String colorHex) {
        String value = colorHex.trim().toUpperCase(Locale.ROOT);
        if (!value.startsWith("#")) {
            value = "#" + value;
        }
        return value;
    }
}
