package com.notdogshit.exoscanner.armor;

import com.notdogshit.exoscanner.whitelist.WhitelistManager;

import java.util.Locale;

public final class ArmorKeyResolver {
    private ArmorKeyResolver() {
    }

    public static String resolveForWhitelist(String rawKey, WhitelistManager whitelistManager) {
        if (rawKey == null || rawKey.isBlank()) {
            return null;
        }
        String normalized = normalizeKey(rawKey);
        normalized = normalizePieceSynonyms(normalized);
        String mapped = mapWitherAndAliases(normalized);
        String candidate = mapped == null ? normalized : mapped;
        return whitelistManager.resolveArmorKey(candidate);
    }

    public static String normalizeKey(String input) {
        String upper = input.trim().toUpperCase(Locale.ROOT);
        String cleaned = upper.replaceAll("[^A-Z0-9]+", "_");
        cleaned = cleaned.replaceAll("^_+", "").replaceAll("_+$", "");
        cleaned = cleaned.replaceAll("_S_", "_");
        cleaned = cleaned.replaceAll("_S$", "");
        return cleaned.isEmpty() ? "UNKNOWN" : cleaned;
    }

    public static String normalizePieceSynonyms(String armorKey) {
        if (armorKey == null) {
            return null;
        }
        if (armorKey.endsWith("_PANTS")) {
            return armorKey.substring(0, armorKey.length() - "_PANTS".length()) + "_LEGGINGS";
        }
        return armorKey;
    }

    public static String mapWitherAndAliases(String armorKey) {
        if (armorKey == null) {
            return null;
        }
        String piece = pieceSuffix(armorKey);
        if (piece == null) {
            return null;
        }
        if (armorKey.contains("STORM")) {
            return "WISE_WITHER_" + piece;
        }
        if (armorKey.contains("NECRON")) {
            return "POWER_WITHER_" + piece;
        }
        if (armorKey.contains("GOLDOR")) {
            return "TANK_WITHER_" + piece;
        }
        if (armorKey.contains("MAXOR")) {
            return "SPEED_WITHER_" + piece;
        }
        if (armorKey.contains("PROSPECTING")) {
            return "MINER_OUTFIT_" + piece;
        }
        if (armorKey.contains("STEREO")) {
            return "MUSIC_" + piece;
        }
        return null;
    }

    private static String pieceSuffix(String armorKey) {
        if (armorKey.endsWith("_HELMET")) {
            return "HELMET";
        }
        if (armorKey.endsWith("_CHESTPLATE")) {
            return "CHESTPLATE";
        }
        if (armorKey.endsWith("_LEGGINGS")) {
            return "LEGGINGS";
        }
        if (armorKey.endsWith("_BOOTS")) {
            return "BOOTS";
        }
        return null;
    }
}
