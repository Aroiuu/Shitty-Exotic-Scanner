package com.notdogshit.exoscanner.armor;

import java.util.Set;

public final class SeymourKeys {
    public static final Set<String> KEYS = Set.of(
        "VELVET_TOP_HAT",
        "CASHMERE_JACKET",
        "SATIN_TROUSERS",
        "OXFORD_SHOES"
    );

    private SeymourKeys() {
    }

    public static String normalizeKey(String armorKey) {
        if (armorKey == null) {
            return null;
        }
        return ArmorKeyResolver.normalizeKey(armorKey);
    }

    public static boolean isSeymourKey(String armorKey) {
        if (armorKey == null || armorKey.isBlank()) {
            return false;
        }
        return KEYS.contains(normalizeKey(armorKey));
    }

    public static boolean isSeymourNormalized(String normalizedKey) {
        if (normalizedKey == null || normalizedKey.isBlank()) {
            return false;
        }
        return KEYS.contains(normalizedKey);
    }
}
