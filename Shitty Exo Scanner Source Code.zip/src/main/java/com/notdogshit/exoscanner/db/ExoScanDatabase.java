package com.notdogshit.exoscanner.db;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.notdogshit.exoscanner.ExoScannerClient;
import com.notdogshit.exoscanner.armor.SeymourKeys;
import com.notdogshit.exoscanner.color.SeymourTierService;
import com.notdogshit.exoscanner.config.ExoScannerConfig;
import com.notdogshit.exoscanner.illegal.IllegalType;
import com.notdogshit.exoscanner.util.IgnoredDyeColors;
import net.fabricmc.loader.api.FabricLoader;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.function.IntConsumer;

public final class ExoScanDatabase {
    // Local JSONL-backed database with in-memory indexes and coarse file locking.
    private static final Gson GSON = new GsonBuilder().disableHtmlEscaping().create();
    private static final double SEYMOUR_BUCKET_SIZE = 5.0;

    private final Path dbDir;
    private final Path lockFile;
    private final ExoScannerConfig config;
    // De-duplication and lookup indexes built on load and updated on writes.
    private final Set<String> seenKeys = new HashSet<>();
    private final Set<String> seenSoftKeys = new HashSet<>();
    private final Map<String, ScanRecord> byArmorUuid = new HashMap<>();
    private final Map<String, ScanRecord> bySoftKeyNoUuid = new HashMap<>();
    private final Set<String> armorKeySuggestions = new TreeSet<>();
    private final Set<String> armorSetSuggestions = new TreeSet<>();
    private volatile SeymourIndex seymourIndex;
    private volatile boolean seymourIndexDirty = true;

    public ExoScanDatabase(ExoScannerConfig config) {
        this.config = config;
        this.dbDir = resolveDbDir(config);
        this.lockFile = dbDir.resolve("exoscanner_db.lock");
    }

    public void loadExisting() {
        // Build indexes from disk on startup.
        try {
            Files.createDirectories(dbDir);
            try (var files = Files.list(dbDir)) {
                files.filter(p -> p.toString().endsWith(".jsonl")).forEach(this::loadFile);
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to load database.", e);
        }
    }

    public int clearAll() {
        int removed = 0;
        try {
            if (Files.exists(dbDir)) {
                try (var files = Files.list(dbDir)) {
                    for (Path file : files.filter(p -> p.toString().endsWith(".jsonl")).toList()) {
                        removed += readAll(file).size();
                        Files.deleteIfExists(file);
                    }
                }
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to clear database.", e);
        }
        seenKeys.clear();
        seenSoftKeys.clear();
        byArmorUuid.clear();
        bySoftKeyNoUuid.clear();
        armorKeySuggestions.clear();
        armorSetSuggestions.clear();
        seymourIndexDirty = true;
        return removed;
    }

    public int clearByArmorKeyOrSet(String keyOrSet) {
        if (keyOrSet == null || keyOrSet.isBlank()) {
            return 0;
        }
        String needle = keyOrSet.toUpperCase();
        boolean matchPiece = hasPieceSuffix(needle);
        int removed = 0;
        try {
            if (!Files.exists(dbDir)) {
                return 0;
            }
            try (var files = Files.list(dbDir)) {
                for (Path file : files.filter(p -> p.toString().endsWith(".jsonl")).toList()) {
                    List<ScanRecord> records = readAll(file);
                    int before = records.size();
                    records.removeIf(record -> {
                        if (record == null) {
                            return false;
                        }
                        if (matchPiece) {
                            return record.armorKey != null && record.armorKey.equalsIgnoreCase(needle);
                        }
                        return record.armorSetKey != null && record.armorSetKey.equalsIgnoreCase(needle);
                    });
                    int after = records.size();
                    if (after != before) {
                        removed += (before - after);
                        writeAll(file, records);
                    }
                }
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to clear database.", e);
        }
        reloadIndexes();
        return removed;
    }

    public int clearByPlayerName(String playerName) {
        if (playerName == null || playerName.isBlank()) {
            return 0;
        }
        String needle = playerName.toLowerCase();
        int removed = 0;
        try {
            if (!Files.exists(dbDir)) {
                return 0;
            }
            try (var files = Files.list(dbDir)) {
                for (Path file : files.filter(p -> p.toString().endsWith(".jsonl")).toList()) {
                    List<ScanRecord> records = readAll(file);
                    int before = records.size();
                    records.removeIf(record -> record != null
                        && record.playerName != null
                        && record.playerName.toLowerCase().contains(needle));
                    int after = records.size();
                    if (after != before) {
                        removed += (before - after);
                        writeAll(file, records);
                    }
                }
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to clear database.", e);
        }
        reloadIndexes();
        return removed;
    }

    public int rollbackSince(long cutoffEpochMs, java.util.function.BiConsumer<Integer, Integer> progress) {
        return withDbLockTimeout(() -> {
            int removed = 0;
            try {
                if (!Files.exists(dbDir)) {
                    return 0;
                }
                List<Path> sources;
                try (var files = Files.list(dbDir)) {
                    sources = files.filter(p -> p.toString().endsWith(".jsonl")).toList();
                }
                int total = sources.size();
                int processed = 0;
                for (Path file : sources) {
                    List<ScanRecord> records = readAll(file);
                    int before = records.size();
                    records.removeIf(record -> record != null && record.timestamp >= cutoffEpochMs);
                    int after = records.size();
                    if (after != before) {
                        removed += (before - after);
                        if (after == 0) {
                            Files.deleteIfExists(file);
                        } else {
                            writeAll(file, records);
                        }
                    }
                    processed++;
                    if (progress != null && (processed % 50 == 0 || processed == total)) {
                        progress.accept(processed, total);
                    }
                }
            } catch (IOException e) {
                ExoScannerClient.LOGGER.warn("Failed to rollback database.", e);
            }
            reloadIndexes();
            return removed;
        }, 5000L);
    }

    public synchronized boolean appendIfNew(ScanRecord record) {
        // Insert with de-dupe (by UUID when present; otherwise by soft key).
        String key = record.uniqueKey();
        String softKey = record.softKey();
        boolean hasArmorUuid = record.armorUuid != null && !record.armorUuid.isBlank();
        if (!hasArmorUuid && seenSoftKeys.contains(softKey)) {
            return false;
        }
        if (hasArmorUuid) {
            ScanRecord existing = byArmorUuid.get(record.armorUuid);
            if (existing != null) {
                if (!hasRelevantChange(existing, record)) {
                    return false;
                }
                boolean ownerChanged = !equalsIgnoreCase(existing.playerName, record.playerName)
                    || !equalsNullable(existing.playerUuid, record.playerUuid);
                String oldOwner = resolveOwner(existing);
                String newOwner = resolveOwner(record);
                String oldFile = existing.fileName();
                existing.timestamp = record.timestamp;
                existing.playerName = record.playerName;
                existing.playerUuid = record.playerUuid;
                existing.armorKey = record.armorKey;
                existing.armorSetKey = record.armorSetKey;
                existing.pieceType = record.pieceType;
                existing.colorHex = record.colorHex;
                existing.illegalType = record.illegalType;

                String newFile = existing.fileName();
                if (!oldFile.equals(newFile)) {
                    removeRecordFromFile(oldFile, record.armorUuid);
                    appendRecordToFile(newFile, existing);
                } else {
                    replaceRecordInFile(newFile, record.armorUuid, existing);
                }
                trackSuggestionKeys(existing);
                seymourIndexDirty = true;
                if (ownerChanged && config != null && config.notifyOnOwnerTransfer) {
                    ExoScannerClient.notifyOwnerTransfer(
                        existing.armorKey,
                        existing.armorUuid,
                        oldOwner,
                        newOwner
                    );
                }
                return false;
            }
            ScanRecord softExisting = bySoftKeyNoUuid.get(softKey);
            if (softExisting != null) {
                String oldFile = softExisting.fileName();
                String newFile = record.fileName();
                if (!oldFile.equals(newFile)) {
                    boolean removed = removeRecordBySoftKey(oldFile, softKey);
                    if (!removed) {
                        ExoScannerClient.LOGGER.warn(
                            "Failed to remove soft-key duplicate from file {} for armorUuid={}",
                            oldFile,
                            record.armorUuid
                        );
                    }
                    appendRecordToFile(newFile, record);
                } else {
                    boolean replaced = replaceRecordBySoftKey(oldFile, softKey, record);
                    if (!replaced) {
                        appendRecordToFile(newFile, record);
                    }
                }
                trackSuggestionKeys(record);
                bySoftKeyNoUuid.remove(softKey);
                byArmorUuid.put(record.armorUuid, record);
                seenKeys.add(key);
                seenSoftKeys.add(softKey);
                seymourIndexDirty = true;
                return false;
            }
            byArmorUuid.put(record.armorUuid, record);
        }
        if (!seenKeys.add(key)) {
            return false;
        }
        seenSoftKeys.add(softKey);
        appendRecordToFile(record.fileName(), record);
        trackSuggestionKeys(record);
        if (!hasArmorUuid) {
            trackSoftKeyNoUuid(record);
        }
        seymourIndexDirty = true;
        return true;
    }

    public synchronized ImportResult importFrom(Path sourcePath) {
        // Import external jsonl records with de-dupe/update semantics.
        if (sourcePath == null) {
            return new ImportResult(0, 0, 0, 0, 0);
        }
        Path normalized = sourcePath.normalize();
        if (!Files.exists(normalized)) {
            return new ImportResult(0, 0, 0, 1, 0);
        }
        List<Path> sources = new ArrayList<>();
        try {
            if (Files.isDirectory(normalized)) {
                try (var files = Files.list(normalized)) {
                    sources.addAll(files.filter(p -> p.toString().endsWith(".jsonl")).toList());
                }
            } else if (normalized.toString().endsWith(".jsonl")) {
                sources.add(normalized);
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to enumerate import files: {}", normalized, e);
            return new ImportResult(0, 0, 0, 1, 0);
        }
        if (sources.isEmpty()) {
            return new ImportResult(0, 0, 0, 0, 0);
        }
        int added = 0;
        int updated = 0;
        int skipped = 0;
        int failed = 0;
        int total = 0;
        for (Path file : sources) {
            for (ScanRecord record : readExternal(file)) {
                total++;
                if (record == null) {
                    skipped++;
                    continue;
                }
                String armorUuid = record.armorUuid;
                if (armorUuid != null && !armorUuid.isBlank()) {
                    ScanRecord existing = byArmorUuid.get(armorUuid);
                    if (existing != null) {
                        long incomingTs = record.timestamp;
                        long existingTs = existing.timestamp;
                        if (incomingTs > existingTs) {
                            String oldFile = existing.fileName();
                            String newFile = record.fileName();
                            if (!oldFile.equals(newFile)) {
                                removeRecordFromFile(oldFile, armorUuid);
                                appendRecordToFile(newFile, record);
                            } else {
                                replaceRecordInFile(newFile, armorUuid, record);
                            }
                            byArmorUuid.put(armorUuid, record);
                            updated++;
                        } else {
                            skipped++;
                        }
                        continue;
                    }
                }
                boolean stored = appendIfNew(record);
                if (stored) {
                    added++;
                } else {
                    skipped++;
                }
            }
        }
        if (added > 0 || updated > 0) {
            reloadIndexes();
        }
        return new ImportResult(added, updated, skipped, failed, total);
    }

    private static boolean hasRelevantChange(ScanRecord existing, ScanRecord incoming) {
        if (existing == incoming) {
            return false;
        }
        if (!equalsIgnoreCase(existing.playerName, incoming.playerName)) {
            return true;
        }
        if (!equalsNullable(existing.playerUuid, incoming.playerUuid)) {
            return true;
        }
        if (!equalsIgnoreCase(existing.armorKey, incoming.armorKey)) {
            return true;
        }
        if (!equalsIgnoreCase(existing.armorSetKey, incoming.armorSetKey)) {
            return true;
        }
        if (!equalsIgnoreCase(existing.pieceType, incoming.pieceType)) {
            return true;
        }
        if (!equalsIgnoreCase(existing.colorHex, incoming.colorHex)) {
            return true;
        }
        if (!equalsIgnoreCase(existing.illegalType, incoming.illegalType)) {
            return true;
        }
        return false;
    }

    private static String resolveOwner(ScanRecord record) {
        if (record == null) {
            return "UNKNOWN";
        }
        if (record.playerName != null && !record.playerName.isBlank()) {
            return record.playerName;
        }
        if (record.playerUuid != null) {
            return record.playerUuid.toString();
        }
        return "UNKNOWN";
    }

    private static boolean equalsIgnoreCase(String left, String right) {
        if (left == null && right == null) {
            return true;
        }
        if (left == null || right == null) {
            return false;
        }
        return left.equalsIgnoreCase(right);
    }

    private static boolean equalsNullable(Object left, Object right) {
        if (left == null && right == null) {
            return true;
        }
        if (left == null || right == null) {
            return false;
        }
        return left.equals(right);
    }

    private void reloadIndexes() {
        seenKeys.clear();
        seenSoftKeys.clear();
        byArmorUuid.clear();
        bySoftKeyNoUuid.clear();
        armorKeySuggestions.clear();
        armorSetSuggestions.clear();
        seymourIndexDirty = true;
        loadExisting();
    }

    private void loadFile(Path path) {
        for (ScanRecord record : readAll(path)) {
            if (record != null) {
                seenKeys.add(record.uniqueKey());
                seenSoftKeys.add(record.softKey());
                trackSuggestionKeys(record);
                if (record.armorUuid != null && !record.armorUuid.isBlank()) {
                    byArmorUuid.put(record.armorUuid, record);
                } else {
                    trackSoftKeyNoUuid(record);
                }
            }
        }
    }

    public synchronized Set<String> getArmorKeySuggestions() {
        // Cached keys for command suggestions to avoid disk scanning on typing.
        return new TreeSet<>(armorKeySuggestions);
    }

    public synchronized Set<String> getArmorSetSuggestions() {
        // Cached set keys for command suggestions to avoid disk scanning on typing.
        return new TreeSet<>(armorSetSuggestions);
    }

    public void forEachRecord(Consumer<ScanRecord> consumer) {
        // Full scan across all jsonl files (disk-bound).
        if (consumer == null) {
            return;
        }
        try {
            if (!Files.exists(dbDir)) {
                return;
            }
            try (var files = Files.list(dbDir)) {
                for (Path file : files.filter(p -> p.toString().endsWith(".jsonl")).toList()) {
                    for (ScanRecord record : readAll(file)) {
                        consumer.accept(record);
                    }
                }
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to iterate database records.", e);
        }
    }

    public Set<String> collectArmorKeys() {
        Set<String> out = new TreeSet<>();
        forEachRecord(record -> {
            if (record.armorKey != null && !record.armorKey.isBlank()) {
                out.add(record.armorKey.toUpperCase());
            }
        });
        return out;
    }

    public Set<String> collectArmorSets() {
        Set<String> out = new TreeSet<>();
        forEachRecord(record -> {
            if (record.armorSetKey != null && !record.armorSetKey.isBlank()) {
                out.add(record.armorSetKey.toUpperCase());
            }
        });
        return out;
    }

    private void appendRecordToFile(String fileName, ScanRecord record) {
        Path filePath = dbDir.resolve(fileName);
        withDbLock(() -> {
            try {
                Files.createDirectories(dbDir);
                try (BufferedWriter writer = Files.newBufferedWriter(filePath, StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
                    writer.write(GSON.toJson(record));
                    writer.newLine();
                }
            } catch (IOException e) {
                ExoScannerClient.LOGGER.warn("Failed to write scan record.", e);
            }
        });
    }

    private void replaceRecordInFile(String fileName, String armorUuid, ScanRecord updated) {
        Path filePath = dbDir.resolve(fileName);
        List<ScanRecord> records = readAll(filePath);
        boolean replaced = false;
        for (int i = 0; i < records.size(); i++) {
            ScanRecord record = records.get(i);
            if (armorUuid.equals(record.armorUuid)) {
                records.set(i, updated);
                replaced = true;
                break;
            }
        }
        if (!replaced) {
            records.add(updated);
        }
        writeAll(filePath, records);
    }

    private boolean replaceRecordBySoftKey(String fileName, String softKey, ScanRecord updated) {
        Path filePath = dbDir.resolve(fileName);
        List<ScanRecord> records = readAll(filePath);
        boolean replaced = false;
        for (int i = 0; i < records.size(); i++) {
            ScanRecord record = records.get(i);
            if (record == null) {
                continue;
            }
            if ((record.armorUuid == null || record.armorUuid.isBlank()) && softKey.equals(record.softKey())) {
                records.set(i, updated);
                replaced = true;
                break;
            }
        }
        if (replaced) {
            writeAll(filePath, records);
        }
        return replaced;
    }

    private void removeRecordFromFile(String fileName, String armorUuid) {
        Path filePath = dbDir.resolve(fileName);
        List<ScanRecord> records = readAll(filePath);
        records.removeIf(record -> armorUuid.equals(record.armorUuid));
        writeAll(filePath, records);
    }

    private boolean removeRecordBySoftKey(String fileName, String softKey) {
        Path filePath = dbDir.resolve(fileName);
        List<ScanRecord> records = readAll(filePath);
        int before = records.size();
        records.removeIf(record -> record != null
            && (record.armorUuid == null || record.armorUuid.isBlank())
            && softKey.equals(record.softKey()));
        if (records.size() != before) {
            writeAll(filePath, records);
            return true;
        }
        return false;
    }

    private List<ScanRecord> readAll(Path filePath) {
        return withDbLock(() -> {
            List<ScanRecord> records = new ArrayList<>();
            if (!Files.exists(filePath)) {
                return records;
            }
            try (BufferedReader reader = Files.newBufferedReader(filePath)) {
                String line;
                while ((line = reader.readLine()) != null) {
                    ScanRecord record = GSON.fromJson(line, ScanRecord.class);
                    if (record != null) {
                        records.add(record);
                    }
                }
            } catch (IOException e) {
                ExoScannerClient.LOGGER.warn("Failed to read database file for update: {}", filePath, e);
            }
            return records;
        });
    }

    private void trackSoftKeyNoUuid(ScanRecord record) {
        if (record == null) {
            return;
        }
        if (record.armorUuid != null && !record.armorUuid.isBlank()) {
            return;
        }
        String softKey = record.softKey();
        ScanRecord existing = bySoftKeyNoUuid.get(softKey);
        if (existing == null || record.timestamp >= existing.timestamp) {
            bySoftKeyNoUuid.put(softKey, record);
        }
    }

    private void trackSuggestionKeys(ScanRecord record) {
        if (record == null) {
            return;
        }
        if (record.armorKey != null && !record.armorKey.isBlank()) {
            armorKeySuggestions.add(record.armorKey.toUpperCase());
        }
        if (record.armorSetKey != null && !record.armorSetKey.isBlank()) {
            armorSetSuggestions.add(record.armorSetKey.toUpperCase());
        }
    }

    private List<ScanRecord> readExternal(Path filePath) {
        List<ScanRecord> records = new ArrayList<>();
        if (filePath == null || !Files.exists(filePath)) {
            return records;
        }
        try (BufferedReader reader = Files.newBufferedReader(filePath)) {
            String line;
            while ((line = reader.readLine()) != null) {
                ScanRecord record = GSON.fromJson(line, ScanRecord.class);
                if (record != null) {
                    records.add(record);
                }
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to read import file: {}", filePath, e);
        }
        return records;
    }

    private void writeAll(Path filePath, List<ScanRecord> records) {
        withDbLock(() -> {
            try (BufferedWriter writer = Files.newBufferedWriter(filePath, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                for (ScanRecord record : records) {
                    writer.write(GSON.toJson(record));
                    writer.newLine();
                }
            } catch (IOException e) {
                ExoScannerClient.LOGGER.warn("Failed to rewrite database file: {}", filePath, e);
            }
        });
    }

    private static Path resolveDbDir(ExoScannerConfig config) {
        Path configDir = FabricLoader.getInstance().getConfigDir();
        if (config == null || config.dbPath == null || config.dbPath.isBlank()) {
            return configDir.resolve("exoscanner_db");
        }
        Path raw = Path.of(config.dbPath.trim());
        if (!raw.isAbsolute()) {
            raw = configDir.resolve(raw);
        }
        return raw.normalize();
    }

    private void withDbLock(Runnable action) {
        withDbLock(() -> {
            action.run();
            return null;
        });
    }

    private <T> T withDbLock(Callable<T> action) {
        try {
            Files.createDirectories(dbDir);
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to create database directory.", e);
        }
        try (FileChannel channel = FileChannel.open(lockFile, StandardOpenOption.CREATE, StandardOpenOption.WRITE);
             FileLock lock = channel.lock()) {
            return action.call();
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to lock database file, proceeding without lock.", e);
            try {
                return action.call();
            } catch (Exception ex) {
                throw new RuntimeException(ex);
            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private <T> T withDbLockTimeout(Callable<T> action, long timeoutMs) {
        try {
            Files.createDirectories(dbDir);
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to create database directory.", e);
        }
        long deadline = System.currentTimeMillis() + Math.max(0, timeoutMs);
        try (FileChannel channel = FileChannel.open(lockFile, StandardOpenOption.CREATE, StandardOpenOption.WRITE)) {
            FileLock lock = null;
            while (lock == null) {
                try {
                    lock = channel.tryLock();
                } catch (IOException ignored) {
                    lock = null;
                }
                if (lock != null) {
                    break;
                }
                if (System.currentTimeMillis() >= deadline) {
                    break;
                }
                try {
                    Thread.sleep(50);
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                    break;
                }
            }
            if (lock != null) {
                try {
                    return action.call();
                } finally {
                    try {
                        lock.release();
                    } catch (IOException ignored) {
                        // ignore
                    }
                }
            }
        } catch (Exception e) {
            ExoScannerClient.LOGGER.warn("Failed to lock database file with timeout, proceeding without lock.", e);
        }
        try {
            return action.call();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    public List<ScanRecord> findByPlayerName(String name) {
        // Disk scan by player name substring.
        String needle = name == null ? "" : name.toLowerCase();
        List<ScanRecord> results = new ArrayList<>();
        try {
            if (!Files.exists(dbDir)) {
                return results;
            }
            try (var files = Files.list(dbDir)) {
                files.filter(p -> p.toString().endsWith(".jsonl")).forEach(path -> {
                    for (ScanRecord record : readAll(path)) {
                        if (record.playerName != null && record.playerName.toLowerCase().contains(needle)) {
                            results.add(record);
                        }
                    }
                });
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to search database.", e);
        }
        return results;
    }

    public List<ScanRecord> findByArmorAndColor(String armorKey, String colorHex) {
        // Disk scan by exact armor key + exact hex color.
        String key = armorKey == null ? "" : armorKey.toUpperCase();
        String color = colorHex == null ? "" : colorHex.toUpperCase();
        List<ScanRecord> results = new ArrayList<>();
        try {
            if (!Files.exists(dbDir)) {
                return results;
            }
            try (var files = Files.list(dbDir)) {
                files.filter(p -> p.toString().endsWith(".jsonl")).forEach(path -> {
                    for (ScanRecord record : readAll(path)) {
                        if (record.armorKey != null
                            && record.colorHex != null
                            && record.armorKey.equalsIgnoreCase(key)
                            && record.colorHex.equalsIgnoreCase(color)) {
                            results.add(record);
                        }
                    }
                });
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to search database.", e);
        }
        return results;
    }

    public List<ScanRecord> findByArmorKeysAndColor(Set<String> armorKeys, String colorHex) {
        // Disk scan by multiple armor keys and exact color.
        List<ScanRecord> results = new ArrayList<>();
        if (armorKeys == null || armorKeys.isEmpty()) {
            return results;
        }
        Set<String> normalized = new HashSet<>();
        for (String key : armorKeys) {
            if (key == null || key.isBlank()) {
                continue;
            }
            normalized.add(key.toUpperCase());
        }
        if (normalized.isEmpty()) {
            return results;
        }
        String color = colorHex == null ? "" : colorHex.toUpperCase();
        try {
            if (!Files.exists(dbDir)) {
                return results;
            }
            try (var files = Files.list(dbDir)) {
                files.filter(p -> p.toString().endsWith(".jsonl")).forEach(path -> {
                    for (ScanRecord record : readAll(path)) {
                        if (record.armorKey != null
                            && record.colorHex != null
                            && normalized.contains(record.armorKey.toUpperCase())
                            && record.colorHex.equalsIgnoreCase(color)) {
                            results.add(record);
                        }
                    }
                });
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to search database.", e);
        }
        return results;
    }

    public List<ScanRecord> findByArmorAndColorDistance(String armorKey, String colorHex, double maxDistance, boolean useCie76) {
        // Disk scan + per-record color distance calculation.
        String key = armorKey == null ? "" : armorKey.toUpperCase();
        String color = colorHex == null ? "" : colorHex.toUpperCase();
        List<ScanRecord> results = new ArrayList<>();
        int targetRgb;
        try {
            targetRgb = com.notdogshit.exoscanner.util.ColorUtils.parseHex(color);
        } catch (RuntimeException e) {
            return results;
        }
        boolean exactPiece = hasPieceSuffix(key);
        try {
            if (!Files.exists(dbDir)) {
                return results;
            }
            try (var files = Files.list(dbDir)) {
                files.filter(p -> p.toString().endsWith(".jsonl")).forEach(path -> {
                    for (ScanRecord record : readAll(path)) {
                        if (record.armorKey == null || record.colorHex == null) {
                            continue;
                        }
                        if (exactPiece) {
                            if (!record.armorKey.equalsIgnoreCase(key)) {
                                continue;
                            }
                        } else {
                            if (record.armorSetKey == null
                                || !record.armorSetKey.equalsIgnoreCase(key)) {
                                continue;
                            }
                        }
                        if (record.colorHex == null) {
                            continue;
                        }
                        try {
                            int recordRgb = com.notdogshit.exoscanner.util.ColorUtils.parseHex(record.colorHex);
                            double distance = useCie76
                                ? com.notdogshit.exoscanner.util.ColorUtils.cie76(targetRgb, recordRgb)
                                : com.notdogshit.exoscanner.util.ColorUtils.ciede2000(targetRgb, recordRgb);
                            if (distance <= maxDistance) {
                                record.matchDistance = distance;
                                results.add(record);
                            }
                        } catch (RuntimeException ignored) {
                            // skip bad color
                        }
                    }
                });
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to search database.", e);
        }
        return results;
    }

    public List<ScanRecord> findByArmorKeysAndColorDistance(Set<String> armorKeys, String colorHex, double maxDistance, boolean useCie76) {
        // Disk scan + per-record color distance for multiple keys.
        List<ScanRecord> results = new ArrayList<>();
        if (armorKeys == null || armorKeys.isEmpty()) {
            return results;
        }
        Set<String> normalized = new HashSet<>();
        for (String key : armorKeys) {
            if (key == null || key.isBlank()) {
                continue;
            }
            normalized.add(key.toUpperCase());
        }
        if (normalized.isEmpty()) {
            return results;
        }
        String color = colorHex == null ? "" : colorHex.toUpperCase();
        int targetRgb;
        try {
            targetRgb = com.notdogshit.exoscanner.util.ColorUtils.parseHex(color);
        } catch (RuntimeException e) {
            return results;
        }
        try {
            if (!Files.exists(dbDir)) {
                return results;
            }
            try (var files = Files.list(dbDir)) {
                files.filter(p -> p.toString().endsWith(".jsonl")).forEach(path -> {
                    for (ScanRecord record : readAll(path)) {
                        if (record.armorKey == null || record.colorHex == null) {
                            continue;
                        }
                        if (!normalized.contains(record.armorKey.toUpperCase())) {
                            continue;
                        }
                        try {
                            int recordRgb = com.notdogshit.exoscanner.util.ColorUtils.parseHex(record.colorHex);
                            double distance = useCie76
                                ? com.notdogshit.exoscanner.util.ColorUtils.cie76(targetRgb, recordRgb)
                                : com.notdogshit.exoscanner.util.ColorUtils.ciede2000(targetRgb, recordRgb);
                            if (distance <= maxDistance) {
                                record.matchDistance = distance;
                                results.add(record);
                            }
                        } catch (RuntimeException ignored) {
                            // skip bad color
                        }
                    }
                });
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to search database.", e);
        }
        return results;
    }

    public List<ScanRecord> findByArmorKeys(Set<String> armorKeys) {
        // Disk scan by armor key set membership.
        List<ScanRecord> results = new ArrayList<>();
        if (armorKeys == null || armorKeys.isEmpty()) {
            return results;
        }
        Set<String> normalized = new HashSet<>();
        for (String key : armorKeys) {
            if (key == null || key.isBlank()) {
                continue;
            }
            normalized.add(key.toUpperCase());
        }
        if (normalized.isEmpty()) {
            return results;
        }
        try {
            if (!Files.exists(dbDir)) {
                return results;
            }
            try (var files = Files.list(dbDir)) {
                files.filter(p -> p.toString().endsWith(".jsonl")).forEach(path -> {
                    for (ScanRecord record : readAll(path)) {
                        if (record == null || record.armorKey == null) {
                            continue;
                        }
                        if (normalized.contains(record.armorKey.toUpperCase())) {
                            results.add(record);
                        }
                    }
                });
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to search database.", e);
        }
        return results;
    }

    public List<ScanRecord> findRecentSince(long sinceEpochMs) {
        // Disk scan by timestamp cutoff.
        List<ScanRecord> results = new ArrayList<>();
        try {
            if (!Files.exists(dbDir)) {
                return results;
            }
            try (var files = Files.list(dbDir)) {
                files.filter(p -> p.toString().endsWith(".jsonl")).forEach(path -> {
                    for (ScanRecord record : readAll(path)) {
                        if (record.timestamp >= sinceEpochMs) {
                            results.add(record);
                        }
                    }
                });
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to search database.", e);
        }
        return results;
    }

    public int countAllRecords() {
        // Disk scan record count across all files.
        int total = 0;
        try {
            if (!Files.exists(dbDir)) {
                return 0;
            }
            try (var files = Files.list(dbDir)) {
                for (Path file : files.filter(p -> p.toString().endsWith(".jsonl")).toList()) {
                    total += readAll(file).size();
                }
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to count database records.", e);
        }
        return total;
    }

    public Map<String, Integer> countByIllegalType() {
        Map<String, Integer> counts = new HashMap<>();
        try {
            if (!Files.exists(dbDir)) {
                return counts;
            }
            try (var files = Files.list(dbDir)) {
                for (Path file : files.filter(p -> p.toString().endsWith(".jsonl")).toList()) {
                    for (ScanRecord record : readAll(file)) {
                        if (record == null) {
                            continue;
                        }
                        String type = record.illegalType == null || record.illegalType.isBlank()
                            ? "EXOTIC"
                            : record.illegalType;
                        counts.merge(type, 1, Integer::sum);
                    }
                }
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to count database records by type.", e);
        }
        return counts;
    }

    public int countByArmorKeys(Set<String> armorKeys) {
        if (armorKeys == null || armorKeys.isEmpty()) {
            return 0;
        }
        Set<String> normalized = new HashSet<>();
        for (String key : armorKeys) {
            if (key == null || key.isBlank()) {
                continue;
            }
            normalized.add(key.trim().toUpperCase());
        }
        if (normalized.isEmpty()) {
            return 0;
        }
        int total = 0;
        try {
            if (!Files.exists(dbDir)) {
                return 0;
            }
            try (var files = Files.list(dbDir)) {
                for (Path file : files.filter(p -> p.toString().endsWith(".jsonl")).toList()) {
                    for (ScanRecord record : readAll(file)) {
                        if (record == null || record.armorKey == null) {
                            continue;
                        }
                        if (normalized.contains(record.armorKey.toUpperCase())) {
                            total++;
                        }
                    }
                }
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to count database records by armor keys.", e);
        }
        return total;
    }

    public static final class BackfillResult {
        public final int updatedIllegalTypes;
        public final int updatedSeymourTiers;
        public final int removedDuplicates;
        public final int removedIgnoredDyes;
        public final int removedSoftKeyDuplicates;
        public final int scanned;

        public BackfillResult(int updatedIllegalTypes, int updatedSeymourTiers, int removedDuplicates,
                              int removedIgnoredDyes, int removedSoftKeyDuplicates, int scanned) {
            this.updatedIllegalTypes = updatedIllegalTypes;
            this.updatedSeymourTiers = updatedSeymourTiers;
            this.removedDuplicates = removedDuplicates;
            this.removedIgnoredDyes = removedIgnoredDyes;
            this.removedSoftKeyDuplicates = removedSoftKeyDuplicates;
            this.scanned = scanned;
        }
    }

    public static final class ImportResult {
        public final int added;
        public final int updated;
        public final int skipped;
        public final int failed;
        public final int total;

        public ImportResult(int added, int updated, int skipped, int failed, int total) {
            this.added = added;
            this.updated = updated;
            this.skipped = skipped;
            this.failed = failed;
            this.total = total;
        }
    }

    public BackfillResult backfillIllegalTypesAndSeymourTiers(
        SeymourTierService.Settings settings,
        IntConsumer progress
    ) {
        int updatedIllegal = 0;
        int updatedTier = 0;
        int removedDuplicates = 0;
        int removedIgnored = 0;
        int removedSoft = 0;
        int scanned = 0;
        try {
            if (!Files.exists(dbDir)) {
                return new BackfillResult(0, 0, 0, 0, 0, 0);
            }
            List<ScanRecord> allRecords = new ArrayList<>();
            try (var files = Files.list(dbDir)) {
                for (Path file : files.filter(p -> p.toString().endsWith(".jsonl")).toList()) {
                    allRecords.addAll(readAll(file));
                }
            }
            java.util.Iterator<ScanRecord> iterator = allRecords.iterator();
            while (iterator.hasNext()) {
                ScanRecord record = iterator.next();
                if (record == null) {
                    continue;
                }
                boolean isSeymour = SeymourKeys.isSeymourKey(record.armorKey)
                    || "SEYMOUR".equalsIgnoreCase(record.illegalType);
                if (!isSeymour && IgnoredDyeColors.isIgnored(record.colorHex)) {
                    iterator.remove();
                    removedIgnored++;
                }
            }
            for (ScanRecord record : allRecords) {
                if (record == null) {
                    continue;
                }
                scanned++;
                if (progress != null && scanned % 500 == 0) {
                    progress.accept(scanned);
                }
                String desired;
                boolean isSeymour = SeymourKeys.isSeymourKey(record.armorKey)
                    || "SEYMOUR".equalsIgnoreCase(record.illegalType);
                if (isSeymour) {
                    desired = "SEYMOUR";
                } else if (record.colorHex == null || record.colorHex.isBlank()) {
                    desired = IllegalType.EXOTIC.name();
                } else {
                    desired = IllegalType.classify(record.colorHex, record.armorKey).name();
                }
                if (record.illegalType == null || record.illegalType.isBlank()
                    || !record.illegalType.equalsIgnoreCase(desired)) {
                    record.illegalType = desired;
                    updatedIllegal++;
                }
                if (isSeymour && settings != null) {
                    SeymourTierService.SeymourTierResult result =
                        SeymourTierService.computeTierForHex(record.colorHex, record.armorKey, settings);
                    if (result != null) {
                        boolean changedTier = record.seymourTier == null
                            || record.seymourBestDeltaE == null
                            || record.seymourTier != result.tier
                            || record.seymourBestDeltaE == null
                            || Math.abs(record.seymourBestDeltaE - result.bestDeltaE) > 0.0001
                            || record.seymourBestMatchName == null
                            || record.seymourBestMatchHex == null;
                        record.seymourTier = result.tier;
                        record.seymourBestDeltaE = result.bestDeltaE;
                        record.seymourBestMatchName = result.bestMatchName;
                        record.seymourBestMatchHex = result.bestMatchHex;
                        record.seymourTierComputedAt = System.currentTimeMillis();
                        if (changedTier) {
                            updatedTier++;
                        }
                    }
                }
            }

            Map<String, ScanRecord> deduped = new HashMap<>();
            for (ScanRecord record : allRecords) {
                if (record == null) {
                    continue;
                }
                String key = record.uniqueKey();
                ScanRecord existing = deduped.get(key);
                if (existing == null) {
                    deduped.put(key, record);
                } else {
                    removedDuplicates++;
                    if (record.timestamp >= existing.timestamp) {
                        deduped.put(key, record);
                    }
                }
            }

            Map<String, List<ScanRecord>> bySoft = new HashMap<>();
            for (ScanRecord record : deduped.values()) {
                if (record == null) {
                    continue;
                }
                bySoft.computeIfAbsent(record.softKey(), key -> new ArrayList<>()).add(record);
            }
            List<ScanRecord> finalRecords = new ArrayList<>();
            for (List<ScanRecord> group : bySoft.values()) {
                if (group.isEmpty()) {
                    continue;
                }
                List<ScanRecord> withUuid = new ArrayList<>();
                for (ScanRecord record : group) {
                    if (record.armorUuid != null && !record.armorUuid.isBlank()) {
                        withUuid.add(record);
                    }
                }
                if (!withUuid.isEmpty()) {
                    finalRecords.addAll(withUuid);
                    removedSoft += group.size() - withUuid.size();
                    continue;
                }
                ScanRecord best = group.get(0);
                for (int i = 1; i < group.size(); i++) {
                    ScanRecord next = group.get(i);
                    if (next.timestamp > best.timestamp) {
                        best = next;
                    }
                }
                finalRecords.add(best);
                removedSoft += group.size() - 1;
            }

            if (updatedIllegal > 0 || updatedTier > 0 || removedDuplicates > 0 || removedIgnored > 0
                || removedSoft > 0) {
                Files.createDirectories(dbDir);
                Map<String, List<ScanRecord>> byFile = new HashMap<>();
                for (ScanRecord record : finalRecords) {
                    byFile.computeIfAbsent(record.fileName(), key -> new ArrayList<>()).add(record);
                }
                try (var files = Files.list(dbDir)) {
                    for (Path file : files.filter(p -> p.toString().endsWith(".jsonl")).toList()) {
                        if (!byFile.containsKey(file.getFileName().toString())) {
                            Files.deleteIfExists(file);
                        }
                    }
                }
                for (Map.Entry<String, List<ScanRecord>> entry : byFile.entrySet()) {
                    Path filePath = dbDir.resolve(entry.getKey());
                    writeAll(filePath, entry.getValue());
                }
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to backfill illegal types/tier.", e);
        }
        reloadIndexes();
        return new BackfillResult(updatedIllegal, updatedTier, removedDuplicates, removedIgnored, removedSoft, scanned);
    }

    public int backfillIllegalTypes() {
        BackfillResult result = backfillIllegalTypesAndSeymourTiers(null, null);
        return result.updatedIllegalTypes;
    }

    private static boolean hasPieceSuffix(String key) {
        return key.endsWith("_HELMET")
            || key.endsWith("_CHESTPLATE")
            || key.endsWith("_LEGGINGS")
            || key.endsWith("_BOOTS")
            || key.endsWith("_PANTS");
    }

    public List<SeymourSet> findSeymourCrossSets(double setDistance, Integer targetRgb, double targetMax, int limit,
                                                 boolean useCie76) {
        if (limit < 1) {
            return List.of();
        }
        SeymourIndex index = ensureSeymourIndex();
        if (index == null) {
            return List.of();
        }
        double[] targetLab = targetRgb == null ? null : com.notdogshit.exoscanner.util.ColorUtils.rgbToLab(targetRgb);
        List<SeymourEntry> hats = index.entriesByKey.getOrDefault("VELVET_TOP_HAT", List.of());
        List<SeymourEntry> jackets = index.entriesByKey.getOrDefault("CASHMERE_JACKET", List.of());
        List<SeymourEntry> trousers = index.entriesByKey.getOrDefault("SATIN_TROUSERS", List.of());
        List<SeymourEntry> shoes = index.entriesByKey.getOrDefault("OXFORD_SHOES", List.of());

        List<SeymourEntry> hatsFiltered = filterByTarget(hats, targetLab, targetMax, useCie76);
        List<SeymourEntry> jacketsFiltered = filterByTarget(jackets, targetLab, targetMax, useCie76);
        List<SeymourEntry> trousersFiltered = filterByTarget(trousers, targetLab, targetMax, useCie76);
        List<SeymourEntry> shoesFiltered = filterByTarget(shoes, targetLab, targetMax, useCie76);

        List<SeymourSet> results = new ArrayList<>();
        for (SeymourEntry hat : hatsFiltered) {
            List<SeymourEntry> nearJackets = index.findWithinDistance("CASHMERE_JACKET", hat, setDistance, useCie76);
            for (SeymourEntry jacket : nearJackets) {
                if (!jacketsFiltered.contains(jacket)) {
                    continue;
                }
                List<SeymourEntry> nearTrousers = index.findWithinDistance("SATIN_TROUSERS", hat, setDistance, useCie76);
                for (SeymourEntry trouser : nearTrousers) {
                    if (!trousersFiltered.contains(trouser)) {
                        continue;
                    }
                    if (distanceLab(jacket.lab, trouser.lab, useCie76) > setDistance) {
                        continue;
                    }
                    List<SeymourEntry> nearShoes = index.findWithinDistance("OXFORD_SHOES", hat, setDistance, useCie76);
                    for (SeymourEntry shoe : nearShoes) {
                        if (!shoesFiltered.contains(shoe)) {
                            continue;
                        }
                        if (distanceLab(jacket.lab, shoe.lab, useCie76) > setDistance
                            || distanceLab(trouser.lab, shoe.lab, useCie76) > setDistance) {
                            continue;
                        }
                        results.add(new SeymourSet(hat.record, jacket.record, trouser.record, shoe.record));
                        if (results.size() >= limit) {
                            return results;
                        }
                    }
                }
            }
        }
        return results;
    }

    private SeymourIndex ensureSeymourIndex() {
        SeymourIndex current = seymourIndex;
        if (current != null && !seymourIndexDirty) {
            return current;
        }
        SeymourIndex rebuilt = buildSeymourIndex();
        seymourIndex = rebuilt;
        seymourIndexDirty = false;
        return rebuilt;
    }

    private SeymourIndex buildSeymourIndex() {
        SeymourIndex index = new SeymourIndex();
        try {
            if (!Files.exists(dbDir)) {
                return index;
            }
            try (var files = Files.list(dbDir)) {
                for (Path file : files.filter(p -> p.toString().endsWith(".jsonl")).toList()) {
                    for (ScanRecord record : readAll(file)) {
                        if (record == null || record.armorKey == null || record.colorHex == null || record.colorHex.isBlank()) {
                            continue;
                        }
                        if (!SeymourKeys.isSeymourKey(record.armorKey)) {
                            continue;
                        }
                        int rgb;
                        try {
                            rgb = com.notdogshit.exoscanner.util.ColorUtils.parseHex(record.colorHex);
                        } catch (RuntimeException e) {
                            continue;
                        }
                        double[] lab = com.notdogshit.exoscanner.util.ColorUtils.rgbToLab(rgb);
                        SeymourEntry entry = new SeymourEntry(record, lab);
                        index.add(record.armorKey, entry);
                    }
                }
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to build Seymour index.", e);
        }
        return index;
    }

    private static List<SeymourEntry> filterByTarget(List<SeymourEntry> input, double[] targetLab, double targetMax,
                                                     boolean useCie76) {
        if (targetLab == null) {
            return input;
        }
        List<SeymourEntry> out = new ArrayList<>();
        for (SeymourEntry entry : input) {
            if (distanceLab(entry.lab, targetLab, useCie76) <= targetMax) {
                out.add(entry);
            }
        }
        return out;
    }

    private static double distanceLab(double[] lab1, double[] lab2, boolean useCie76) {
        if (useCie76) {
            double dl = lab1[0] - lab2[0];
            double da = lab1[1] - lab2[1];
            double db = lab1[2] - lab2[2];
            return Math.sqrt((dl * dl) + (da * da) + (db * db));
        }
        return com.notdogshit.exoscanner.util.ColorUtils.ciede2000Lab(
            lab1[0], lab1[1], lab1[2], lab2[0], lab2[1], lab2[2]
        );
    }

    public static final class SeymourSet {
        public final ScanRecord hat;
        public final ScanRecord jacket;
        public final ScanRecord trousers;
        public final ScanRecord shoes;

        public SeymourSet(ScanRecord hat, ScanRecord jacket, ScanRecord trousers, ScanRecord shoes) {
            this.hat = hat;
            this.jacket = jacket;
            this.trousers = trousers;
            this.shoes = shoes;
        }
    }

    private static final class SeymourEntry {
        private final ScanRecord record;
        private final double[] lab;

        private SeymourEntry(ScanRecord record, double[] lab) {
            this.record = record;
            this.lab = lab;
        }
    }

    private static final class SeymourIndex {
        private final Map<String, List<SeymourEntry>> entriesByKey = new HashMap<>();
        private final Map<String, Map<BucketKey, List<SeymourEntry>>> bucketsByKey = new HashMap<>();

        private void add(String armorKey, SeymourEntry entry) {
            String key = armorKey.toUpperCase();
            entriesByKey.computeIfAbsent(key, k -> new ArrayList<>()).add(entry);
            BucketKey bucket = BucketKey.of(entry.lab);
            bucketsByKey.computeIfAbsent(key, k -> new HashMap<>())
                .computeIfAbsent(bucket, k -> new ArrayList<>())
                .add(entry);
        }

        private List<SeymourEntry> findWithinDistance(String armorKey, SeymourEntry center, double maxDistance,
                                                      boolean useCie76) {
            String key = armorKey.toUpperCase();
            Map<BucketKey, List<SeymourEntry>> buckets = bucketsByKey.get(key);
            if (buckets == null) {
                return List.of();
            }
            int radius = (int) Math.ceil(maxDistance / SEYMOUR_BUCKET_SIZE);
            BucketKey base = BucketKey.of(center.lab);
            List<SeymourEntry> out = new ArrayList<>();
            for (int dl = -radius; dl <= radius; dl++) {
                for (int da = -radius; da <= radius; da++) {
                    for (int db = -radius; db <= radius; db++) {
                        BucketKey keyBucket = new BucketKey(base.l + dl, base.a + da, base.b + db);
                        List<SeymourEntry> candidates = buckets.get(keyBucket);
                        if (candidates == null) {
                            continue;
                        }
                        for (SeymourEntry entry : candidates) {
                            if (distanceLab(center.lab, entry.lab, useCie76) <= maxDistance) {
                                out.add(entry);
                            }
                        }
                    }
                }
            }
            return out;
        }
    }

    private static final class BucketKey {
        private final int l;
        private final int a;
        private final int b;

        private BucketKey(int l, int a, int b) {
            this.l = l;
            this.a = a;
            this.b = b;
        }

        private static BucketKey of(double[] lab) {
            return new BucketKey(
                (int) Math.floor(lab[0] / SEYMOUR_BUCKET_SIZE),
                (int) Math.floor(lab[1] / SEYMOUR_BUCKET_SIZE),
                (int) Math.floor(lab[2] / SEYMOUR_BUCKET_SIZE)
            );
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) {
                return true;
            }
            if (!(o instanceof BucketKey other)) {
                return false;
            }
            return l == other.l && a == other.a && b == other.b;
        }

        @Override
        public int hashCode() {
            int result = Integer.hashCode(l);
            result = 31 * result + Integer.hashCode(a);
            result = 31 * result + Integer.hashCode(b);
            return result;
        }
    }
}
