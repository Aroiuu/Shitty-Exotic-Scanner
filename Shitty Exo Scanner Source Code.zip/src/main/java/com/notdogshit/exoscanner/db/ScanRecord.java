package com.notdogshit.exoscanner.db;

import java.util.Locale;
import java.util.UUID;

public final class ScanRecord {
    // Single scan result stored in the JSONL database.
    public long timestamp;
    public String playerName;
    public UUID playerUuid;
    public String armorUuid;
    public String armorKey;
    public String armorSetKey;
    public String pieceType;
    public String colorHex;
    public String illegalType;
    public transient Double matchDistance;

    // Seymour tiering (optional, backward-compatible)
    public Integer seymourTier;
    public Double seymourBestDeltaE;
    public String seymourBestMatchName;
    public String seymourBestMatchHex;
    public Long seymourTierComputedAt;

    public String uniqueKey() {
        // Primary de-duplication key; armor UUID if present, otherwise soft key.
        if (armorUuid != null && !armorUuid.isBlank()) {
            return "ARMORUUID|" + armorUuid;
        }
        return softKey();
    }

    public String softKey() {
        // Fallback de-duplication key based on owner + armor + color.
        String owner;
        if (playerUuid != null) {
            owner = playerUuid.toString();
        } else if (playerName != null && !playerName.isBlank()) {
            owner = playerName;
        } else {
            owner = "UNKNOWN";
        }
        String key = armorKey == null ? "" : armorKey.toUpperCase(Locale.ROOT);
        String color = colorHex == null ? "" : colorHex.toUpperCase(Locale.ROOT);
        return owner + "|" + key + "|" + color;
    }

    public String fileName() {
        // Records are sharded by armor set key.
        String safe = (armorSetKey == null || armorSetKey.isBlank())
            ? "UNKNOWN"
            : armorSetKey.toUpperCase(Locale.ROOT);
        return safe.replaceAll("[^A-Z0-9_]", "_") + ".jsonl";
    }
}
