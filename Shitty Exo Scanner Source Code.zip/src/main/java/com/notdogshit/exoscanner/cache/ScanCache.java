package com.notdogshit.exoscanner.cache;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.notdogshit.exoscanner.ExoScannerClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class ScanCache {
    // Simple UUID -> last scan timestamp cache persisted to disk.
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<Map<String, Long>>() {}.getType();

    private final Path cachePath;
    private Map<String, Long> lastScanByUuid = new HashMap<>();

    public ScanCache() {
        this.cachePath = FabricLoader.getInstance().getConfigDir().resolve("exoscanner_cache.json");
    }

    public void loadOrCreate() {
        // Load cache or create a new file if missing.
        if (!Files.exists(cachePath)) {
            save();
            return;
        }
        try (Reader reader = Files.newBufferedReader(cachePath)) {
            Map<String, Long> loaded = GSON.fromJson(reader, MAP_TYPE);
            if (loaded != null) {
                lastScanByUuid = loaded;
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to read scan cache.", e);
        }
    }

    public boolean shouldScan(UUID uuid, int cacheDays) {
        // TTL-based check to avoid re-scanning the same player too often.
        if (cacheDays <= 0) {
            return true;
        }
        String key = uuid.toString();
        Long last = lastScanByUuid.get(key);
        if (last == null) {
            return true;
        }
        long ttlMs = cacheDays * 86400000L;
        return System.currentTimeMillis() - last > ttlMs;
    }

    public void markScanned(UUID uuid) {
        // Record a successful scan time for this UUID.
        lastScanByUuid.put(uuid.toString(), System.currentTimeMillis());
        save();
    }

    private void save() {
        try (Writer writer = Files.newBufferedWriter(cachePath)) {
            GSON.toJson(lastScanByUuid, writer);
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to write scan cache.", e);
        }
    }
}
