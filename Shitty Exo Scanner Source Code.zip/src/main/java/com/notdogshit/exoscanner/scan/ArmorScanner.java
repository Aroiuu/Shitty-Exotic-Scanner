package com.notdogshit.exoscanner.scan;

import com.notdogshit.exoscanner.config.ConfigManager;
import com.notdogshit.exoscanner.config.ExoScannerConfig;
import com.notdogshit.exoscanner.armor.ArmorKeyResolver;
import com.notdogshit.exoscanner.armor.SeymourKeys;
import com.notdogshit.exoscanner.color.SeymourTierService;
import com.notdogshit.exoscanner.db.ExoScanDatabase;
import com.notdogshit.exoscanner.db.ScanRecord;
import com.notdogshit.exoscanner.illegal.IllegalType;
import com.notdogshit.exoscanner.util.IgnoredDyeColors;
import com.notdogshit.exoscanner.whitelist.WhitelistManager;
import net.minecraft.client.Minecraft;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntArrayTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.network.chat.Component;

import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Pattern;

public final class ArmorScanner {
    // Client-side armor scanner for nearby players and manual item stacks.
    private final ConfigManager configManager;
    private final WhitelistManager whitelistManager;
    private final ExoScanDatabase database;
    private int ticksUntilScan;
    private static final Pattern UUID_32 = Pattern.compile("^[0-9a-fA-F]{32}$");
    private static final Pattern UUID_36 = Pattern.compile("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");

    public ArmorScanner(ConfigManager configManager, WhitelistManager whitelistManager, ExoScanDatabase database) {
        this.configManager = configManager;
        this.whitelistManager = whitelistManager;
        this.database = database;
        resetTimer();
    }

    public void onClientTick(Minecraft client) {
        // Periodic scan driven by config interval.
        if (client == null || client.level == null || client.player == null) {
            return;
        }
        if (!configManager.get().enableScanning) {
            return;
        }
        if (ticksUntilScan > 0) {
            ticksUntilScan--;
            return;
        }
        resetTimer();
        scanPlayers(client);
    }

    public void scanNow(Minecraft client) {
        // Immediate scan request (used by commands).
        if (client == null || client.level == null || client.player == null) {
            return;
        }
        scanPlayers(client);
        resetTimer();
    }

    private void resetTimer() {
        int seconds = configManager.get().scanInterval;
        if (seconds < 1) {
            seconds = 5;
        }
        ticksUntilScan = seconds * 20;
    }

    private void scanPlayers(Minecraft client) {
        // Walk all players in the current level and scan equipped armor.
        for (Player player : client.level.players()) {
            scanPlayer(player);
        }
    }

    private void scanPlayer(Player player) {
        boolean debug = configManager.get().debugArmorScan;
        for (EquipmentSlot slot : new EquipmentSlot[]{
            EquipmentSlot.HEAD,
            EquipmentSlot.CHEST,
            EquipmentSlot.LEGS,
            EquipmentSlot.FEET
        }) {
            ItemStack stack = player.getItemBySlot(slot);
            if (stack.isEmpty()) {
                continue;
            }
            scanItemStack(player.getName().getString(), player.getUUID(), stack, toPieceType(slot), "player");
        }
    }

    public void scanItemStack(String ownerName, UUID ownerUuid, ItemStack stack, String pieceTypeHint, String source) {
        // Main decision tree for whether a stack is eligible and how to record it.
        boolean debug = configManager.get().debugArmorScan;
        if (stack == null || stack.isEmpty()) {
            return;
        }
        String armorKey = getSkyblockItemId(stack);
        if (armorKey == null || armorKey.isBlank()) {
            armorKey = stack.getHoverName().getString();
        }
        String normalizedKey = SeymourKeys.normalizeKey(armorKey);
        boolean forceScan = SeymourKeys.isSeymourNormalized(normalizedKey);
        Integer dyedColor = getDyedColor(stack);
        if (dyedColor == null && !forceScan) {
            if (debug) {
                CompoundTag custom = getCustomData(stack);
                com.notdogshit.exoscanner.ExoScannerClient.LOGGER.info(
                    "Skip: no dyed color. owner={}, source={}, item={}, customData={}",
                    ownerName,
                    source,
                    stack.getItem().toString(),
                    custom == null ? "null" : custom.toString()
                );
                com.notdogshit.exoscanner.ExoScannerClient.LOGGER.info(
                    "Debug components: dyedColorComponent={}",
                    describeDyedComponent(stack)
                );
            }
            return;
        }
        String resolvedKey = ArmorKeyResolver.resolveForWhitelist(armorKey, whitelistManager);
        if (debug) {
            com.notdogshit.exoscanner.ExoScannerClient.LOGGER.info(
                "Resolve armor key. raw={}, normalized={}, resolved={}, forceScan={}",
                armorKey,
                normalizedKey,
                resolvedKey,
                forceScan
            );
        }
        String pieceType = pieceTypeHint == null ? "UNKNOWN" : pieceTypeHint;
        if (resolvedKey != null && ("UNKNOWN".equals(pieceType) || pieceType.isBlank())) {
            pieceType = pieceTypeFromKey(resolvedKey);
        }
        if (!isPieceEnabled(pieceType)) {
            if (debug) {
                com.notdogshit.exoscanner.ExoScannerClient.LOGGER.info(
                    "Skip: piece disabled. owner={}, pieceType={}, armorKey={}",
                    ownerName,
                    pieceType,
                    armorKey
                );
            }
            return;
        }
        boolean dyeMarked = hasHypixelDyeMarker(stack);
        if (debug && !dyeMarked) {
            com.notdogshit.exoscanner.ExoScannerClient.LOGGER.info(
                "Dye marker not found. loreLines={}",
                getLoreLines(stack)
            );
        }
        if (dyeMarked) {
            if (debug) {
                com.notdogshit.exoscanner.ExoScannerClient.LOGGER.info(
                    "Skip: hypixel dye marker found. owner={}, armorKey={}",
                    ownerName,
                    armorKey
                );
            }
            return;
        }
        boolean debugAll = configManager.get().debugScanAllLeather;
        if (!debugAll && resolvedKey == null && !forceScan) {
            if (debug) {
                com.notdogshit.exoscanner.ExoScannerClient.LOGGER.info(
                    "Skip: not in whitelist. owner={}, armorKey={}",
                    ownerName,
                    armorKey
                );
            }
            return;
        }
        if (resolvedKey != null) {
            armorKey = resolvedKey;
        } else if (forceScan) {
            armorKey = normalizedKey;
        }
        String armorSetKey = deriveSetKey(armorKey);
        if (!isSetEnabled(armorSetKey)) {
            if (debug) {
                com.notdogshit.exoscanner.ExoScannerClient.LOGGER.info(
                    "Skip: set disabled. owner={}, armorSetKey={}, armorKey={}",
                    ownerName,
                    armorSetKey,
                    armorKey
                );
            }
            return;
        }

        String colorHex = dyedColor == null ? "#000000" : toHex(dyedColor);
        if (!forceScan && IgnoredDyeColors.isIgnored(colorHex)) {
            if (debug) {
                com.notdogshit.exoscanner.ExoScannerClient.LOGGER.info(
                    "Skip: ignored dye color. owner={}, armorKey={}, colorHex={}",
                    ownerName,
                    armorKey,
                    colorHex
                );
            }
            return;
        }
        boolean allowed = whitelistManager.isAllowed(armorKey, colorHex);
        if (debug) {
            com.notdogshit.exoscanner.ExoScannerClient.LOGGER.info(
                "Scan: owner={}, armorKey={}, colorHex={}, allowed={}, armorUuid={}, forceScan={}",
                ownerName,
                armorKey,
                colorHex,
                allowed,
                extractArmorUuid(stack),
                forceScan
            );
        }
        boolean willStore = forceScan || debugAll || !allowed;
        if (!willStore) {
            return;
        }

        ScanRecord record = new ScanRecord();
        record.timestamp = System.currentTimeMillis();
        record.playerName = ownerName;
        record.playerUuid = ownerUuid;
        String armorUuid = extractArmorUuid(stack);
        if (debug && willStore && (armorUuid == null || armorUuid.isBlank())) {
            Object customComponent = stack.get(DataComponents.CUSTOM_DATA);
            CompoundTag custom = getCustomData(stack);
            CompoundTag extra = custom == null ? null : getCompound(custom, "ExtraAttributes");
            CompoundTag full = getFullNbt(stack);
            CompoundTag fullTag = getCompound(full, "tag");
            CompoundTag fullComponents = getCompound(full, "components");
            com.notdogshit.exoscanner.ExoScannerClient.LOGGER.info(
                "Armor UUID missing. owner={}, armorKey={}, item={}, customKeys={}, extraKeys={}, fullKeys={}, fullTagKeys={}, fullComponentKeys={}, customComponent={}",
                ownerName,
                armorKey,
                stack.getItem().toString(),
                custom == null ? "null" : getAllKeys(custom),
                extra == null ? "null" : getAllKeys(extra),
                full == null ? "null" : getAllKeys(full),
                fullTag == null ? "null" : getAllKeys(fullTag),
                fullComponents == null ? "null" : getAllKeys(fullComponents),
                describeCustomComponent(customComponent)
            );
        }
        if (willStore && (armorUuid == null || armorUuid.isBlank())
            && configManager.get().notifyOnMissingArmorUuid) {
            Minecraft client = Minecraft.getInstance();
            if (client != null && client.player != null) {
                String message = "ExoScanner: missing armor UUID (armor scan) "
                    + ownerName + " " + armorKey + " " + colorHex;
                client.player.displayClientMessage(Component.literal(message), false);
            }
        }
        record.armorUuid = armorUuid;
        record.armorKey = armorKey;
        record.armorSetKey = armorSetKey;
        record.pieceType = pieceType;
        record.colorHex = colorHex;
        record.illegalType = forceScan
            ? "SEYMOUR"
            : IllegalType.classify(colorHex, armorKey).name();

        if (forceScan) {
            // Seymour entries compute tier on a background thread before storing.
            SeymourTierService.Settings settings = new SeymourTierService.Settings(
                76,
                true,
                true,
                true
            );
            CompletableFuture.runAsync(() -> {
                SeymourTierService.SeymourTierResult result =
                    SeymourTierService.computeTierForHex(record.colorHex, record.armorKey, settings);
                if (result != null) {
                    record.seymourTier = result.tier;
                    record.seymourBestDeltaE = result.bestDeltaE;
                    record.seymourBestMatchName = result.bestMatchName;
                    record.seymourBestMatchHex = result.bestMatchHex;
                    record.seymourTierComputedAt = System.currentTimeMillis();
                }
                boolean stored = database.appendIfNew(record);
                if (stored && configManager.get().notifyOnExotic) {
                    Minecraft client = Minecraft.getInstance();
                    if (client != null && client.player != null) {
                        client.execute(() -> {
                            Component message = Component.literal(
                                    "Illegal found (" + record.illegalType + "): "
                                        + record.playerName + " " + record.armorKey + " ")
                                .append(coloredHexComponent(record.colorHex));
                            client.player.displayClientMessage(message, false);
                        });
                    }
                }
            });
            return;
        }

        boolean stored = database.appendIfNew(record);
        if (stored && configManager.get().notifyOnExotic) {
            Minecraft client = Minecraft.getInstance();
            if (client != null && client.player != null) {
                Component message = Component.literal(
                        "Illegal found (" + record.illegalType + "): "
                            + record.playerName + " " + record.armorKey + " ")
                    .append(coloredHexComponent(record.colorHex));
                client.player.displayClientMessage(message, false);
            }
        }
    }

    public LiveScanResult evaluateItemStack(ItemStack stack, String pieceTypeHint) {
        // Lightweight scan variant used for UI overlays without database writes.
        if (stack == null || stack.isEmpty()) {
            return null;
        }
        String armorKey = getSkyblockItemId(stack);
        if (armorKey == null || armorKey.isBlank()) {
            armorKey = stack.getHoverName().getString();
        }
        String normalizedKey = SeymourKeys.normalizeKey(armorKey);
        boolean forceScan = SeymourKeys.isSeymourNormalized(normalizedKey);
        boolean debugAll = configManager.get().debugScanAllLeather;
        Integer dyedColor = getDyedColor(stack);
        if (dyedColor == null && debugAll) {
            dyedColor = getLeatherColor(stack);
        }
        if (dyedColor == null && !forceScan) {
            return null;
        }
        String resolvedKey = ArmorKeyResolver.resolveForWhitelist(armorKey, whitelistManager);
        String pieceType = pieceTypeHint == null ? "UNKNOWN" : pieceTypeHint;
        if (resolvedKey != null && ("UNKNOWN".equals(pieceType) || pieceType.isBlank())) {
            pieceType = pieceTypeFromKey(resolvedKey);
        }
        if (!isPieceEnabled(pieceType)) {
            return null;
        }
        if (hasHypixelDyeMarker(stack)) {
            return null;
        }
        if (!debugAll && resolvedKey == null && !forceScan) {
            return null;
        }
        if (resolvedKey != null) {
            armorKey = resolvedKey;
        } else if (forceScan) {
            armorKey = normalizedKey;
        }
        String armorSetKey = deriveSetKey(armorKey);
        if (!isSetEnabled(armorSetKey)) {
            return null;
        }

        String colorHex = dyedColor == null ? "#000000" : toHex(dyedColor);
        if (!forceScan && IgnoredDyeColors.isIgnored(colorHex)) {
            return null;
        }
        boolean allowed = whitelistManager.isAllowed(armorKey, colorHex);
        if (!forceScan && !debugAll && allowed) {
            return null;
        }
        String illegalType = forceScan
            ? "SEYMOUR"
            : IllegalType.classify(colorHex, armorKey).name();
        return new LiveScanResult(armorKey, armorSetKey, pieceType, colorHex, illegalType);
    }

    private static Component coloredHexComponent(String hex) {
        String safe = hex == null ? "UNKNOWN" : hex;
        if (safe.startsWith("#") && safe.length() == 7) {
            try {
                int rgb = Integer.parseInt(safe.substring(1), 16);
                return Component.literal(safe).withStyle(style -> style.withColor(net.minecraft.network.chat.TextColor.fromRgb(rgb)));
            } catch (NumberFormatException ignored) {
                return Component.literal(safe);
            }
        }
        return Component.literal(safe);
    }

    private boolean isPieceEnabled(String pieceType) {
        ExoScannerConfig config = configManager.get();
        if (config.enabledPieceTypes == null || config.enabledPieceTypes.isEmpty()) {
            return true;
        }
        return config.enabledPieceTypes.contains(pieceType);
    }

    private boolean isSetEnabled(String setKey) {
        ExoScannerConfig config = configManager.get();
        if (config.enabledArmorSets == null || config.enabledArmorSets.isEmpty()) {
            return true;
        }
        return config.enabledArmorSets.contains(setKey);
    }

    private static String deriveSetKey(String armorKey) {
        if (armorKey.endsWith("_HELMET")) {
            return armorKey.substring(0, armorKey.length() - "_HELMET".length());
        }
        if (armorKey.endsWith("_CHESTPLATE")) {
            return armorKey.substring(0, armorKey.length() - "_CHESTPLATE".length());
        }
        if (armorKey.endsWith("_LEGGINGS")) {
            return armorKey.substring(0, armorKey.length() - "_LEGGINGS".length());
        }
        if (armorKey.endsWith("_BOOTS")) {
            return armorKey.substring(0, armorKey.length() - "_BOOTS".length());
        }
        return armorKey;
    }

    private static String toPieceType(EquipmentSlot slot) {
        return switch (slot) {
            case HEAD -> "HELMET";
            case CHEST -> "CHESTPLATE";
            case LEGS -> "LEGGINGS";
            case FEET -> "BOOTS";
            default -> "UNKNOWN";
        };
    }

    private static String pieceTypeFromKey(String armorKey) {
        if (armorKey.endsWith("_HELMET")) {
            return "HELMET";
        }
        if (armorKey.endsWith("_CHESTPLATE")) {
            return "CHESTPLATE";
        }
        if (armorKey.endsWith("_LEGGINGS")) {
            return "LEGGINGS";
        }
        if (armorKey.endsWith("_BOOTS")) {
            return "BOOTS";
        }
        return "UNKNOWN";
    }

    private static String toHex(int color) {
        return String.format("#%06X", (0xFFFFFF & color));
    }

    private static String extractArmorUuid(ItemStack stack) {
        // Pull armor UUID from full NBT or custom data if present.
        String fromFull = readUuidFromFullNbt(stack);
        if (fromFull != null) {
            return fromFull;
        }
        CompoundTag nbt = getCustomData(stack);
        if (nbt == null) {
            return null;
        }
        String uuid = readUuidFrom(nbt);
        if (uuid != null) {
            return uuid;
        }
        if (nbt.contains("ExtraAttributes")) {
            Tag tag = nbt.get("ExtraAttributes");
            if (tag instanceof CompoundTag extra) {
                return readUuidFrom(extra);
            }
        }
        return null;
    }

    private static String getSkyblockItemId(ItemStack stack) {
        // Resolve Hypixel item ID from custom data / ExtraAttributes.
        CompoundTag nbt = getCustomData(stack);
        if (nbt == null) {
            return null;
        }
        String id = readString(nbt, "id");
        if (id != null) {
            return id.trim().toUpperCase(Locale.ROOT);
        }
        String itemId = readString(nbt, "item_id");
        if (itemId != null) {
            return itemId.trim().toUpperCase(Locale.ROOT);
        }
        if (!nbt.contains("ExtraAttributes")) {
            return null;
        }
        Tag tag = nbt.get("ExtraAttributes");
        if (!(tag instanceof CompoundTag extra)) {
            return null;
        }
        String extraId = readString(extra, "id");
        if (extraId == null) {
            extraId = readString(extra, "item_id");
        }
        return extraId == null ? null : extraId.trim().toUpperCase(Locale.ROOT);
    }

    private static boolean hasHypixelDyeMarker(ItemStack stack) {
        // Detect Hypixel dye markers to avoid scanning dyed items.
        CompoundTag nbt = getCustomData(stack);
        if (nbt == null) {
            return hasDyeNameMarker(stack) || hasDyeLoreMarker(stack);
        }
        if (readString(nbt, "dye_item") != null) {
            return true;
        }
        if (nbt.contains("ExtraAttributes")) {
            Tag tag = nbt.get("ExtraAttributes");
            if (tag instanceof CompoundTag extra) {
                return readString(extra, "dye_item") != null;
            }
        }
        return hasDyeNameMarker(stack) || hasDyeLoreMarker(stack);
    }

    private static boolean hasDyeNameMarker(ItemStack stack) {
        String name = stack.getHoverName().getString();
        return name != null && name.contains("✿");
    }

    private static boolean hasDyeLoreMarker(ItemStack stack) {
        for (String line : getLoreLines(stack)) {
            String lower = line.toLowerCase(Locale.ROOT);
            if (lower.contains(" dyed")) {
                return true;
            }
            if (line.contains("✿") && lower.contains("dyed")) {
                return true;
            }
        }
        return false;
    }

    private static java.util.List<String> getLoreLines(ItemStack stack) {
        java.util.List<String> lines = new java.util.ArrayList<>();
        Object lore = stack.get(DataComponents.LORE);
        if (lore != null) {
            try {
                var m = lore.getClass().getMethod("lines");
                Object value = m.invoke(lore);
                if (value instanceof java.util.List<?> list) {
                    for (Object entry : list) {
                        String text = componentToString(entry);
                        if (text != null && !text.isBlank()) {
                            lines.add(text);
                        }
                    }
                }
            } catch (ReflectiveOperationException ignored) {
                // fallback below
            }
            if (!lines.isEmpty()) {
                return lines;
            }
            String fallback = lore.toString();
            if (fallback != null && !fallback.isBlank()) {
                lines.add(fallback);
            }
            return lines;
        }
        return lines;
    }

    private static String componentToString(Object component) {
        if (component == null) {
            return null;
        }
        if (component instanceof Component comp) {
            return comp.getString();
        }
        try {
            var m = component.getClass().getMethod("getString");
            Object value = m.invoke(component);
            return value == null ? null : value.toString();
        } catch (ReflectiveOperationException ignored) {
            return component.toString();
        }
    }

    private static String readUuidFrom(CompoundTag nbt) {
        // Best-effort UUID extraction from common key names and tag types.
        for (String key : new String[] {
            "uuid", "UUID", "id", "Id", "item_uuid", "itemUUID", "ItemUUID",
            "uniqueId", "unique_id", "itemId", "item_id"
        }) {
            if (!nbt.contains(key)) {
                continue;
            }
            Tag tag = nbt.get(key);
            String value = readTagString(tag);
            String normalized = normalizeUuidString(value);
            if (normalized != null) {
                return normalized;
            } else if (tag instanceof IntArrayTag intArrayTag) {
                int[] arr = intArrayTag.getAsIntArray();
                if (arr.length == 4) {
                    long most = ((long) arr[0] << 32) | (arr[1] & 0xFFFFFFFFL);
                    long least = ((long) arr[2] << 32) | (arr[3] & 0xFFFFFFFFL);
                    return new java.util.UUID(most, least).toString();
                }
            } else if (tag instanceof CompoundTag compoundTag) {
                Long most = readLong(compoundTag, "Most");
                Long least = readLong(compoundTag, "Least");
                if (most != null && least != null) {
                    return new java.util.UUID(most, least).toString();
                }
            }
        }
        return null;
    }

    private static String normalizeUuidString(String value) {
        if (value == null) {
            return null;
        }
        String cleaned = value.trim();
        if (cleaned.isEmpty()) {
            return null;
        }
        if (UUID_36.matcher(cleaned).matches()) {
            try {
                return UUID.fromString(cleaned).toString();
            } catch (IllegalArgumentException ignored) {
                return null;
            }
        }
        if (UUID_32.matcher(cleaned).matches()) {
            String dashed = cleaned.substring(0, 8) + "-" +
                cleaned.substring(8, 12) + "-" +
                cleaned.substring(12, 16) + "-" +
                cleaned.substring(16, 20) + "-" +
                cleaned.substring(20);
            try {
                return UUID.fromString(dashed).toString();
            } catch (IllegalArgumentException ignored) {
                return null;
            }
        }
        return null;
    }

    private static String readString(CompoundTag tag, String key) {
        if (!tag.contains(key)) {
            return null;
        }
        String value = readTagString(tag.get(key));
        return value == null || value.isEmpty() ? null : value;
    }

    private static String readTagString(Tag tag) {
        try {
            var getAsString = tag.getClass().getMethod("getAsString");
            Object value = getAsString.invoke(tag);
            return value == null ? null : value.toString().trim();
        } catch (ReflectiveOperationException ignored) {
            String fallback = tag.toString();
            if (fallback == null) {
                return null;
            }
            return fallback.replace("\"", "").trim();
        }
    }

    private static Long readLong(CompoundTag tag, String key) {
        if (!tag.contains(key)) {
            return null;
        }
        try {
            var getLong = tag.getClass().getMethod("getLong", String.class);
            Object value = getLong.invoke(tag, key);
            if (value instanceof Long l) {
                return l;
            }
            if (value instanceof java.util.Optional<?> optional) {
                Object inner = optional.orElse(null);
                if (inner instanceof Long l) {
                    return l;
                }
            }
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
        return null;
    }

    private static Integer getDyedColor(ItemStack stack) {
        Integer fromComponent = readDyedColorComponent(stack);
        if (fromComponent != null) {
            return fromComponent;
        }
        CompoundTag custom = getCustomData(stack);
        if (custom == null) {
            return null;
        }
        Integer fromCustom = readColorFromCustomData(custom);
        if (fromCustom != null) {
            return fromCustom;
        }
        return null;
    }

    private static Integer getLeatherColor(ItemStack stack) {
        if (stack == null) {
            return null;
        }
        try {
            Class<?> leatherClass = Class.forName("net.minecraft.world.item.LeatherArmorItem");
            Object item = stack.getItem();
            if (item != null && leatherClass.isInstance(item)) {
                for (String method : new String[] { "getColor", "color" }) {
                    try {
                        var m = leatherClass.getMethod(method, ItemStack.class);
                        Object result = m.invoke(item, stack);
                        Object unwrapped = unwrapOptional(result);
                        if (unwrapped instanceof Integer integer) {
                            return integer;
                        }
                    } catch (ReflectiveOperationException ignored) {
                        // try next
                    }
                }
                return 0xA06540;
            }
        } catch (ClassNotFoundException ignored) {
            // fall through
        } catch (RuntimeException ignored) {
            return null;
        }
        String key = stack.getItem().getDescriptionId();
        if (key != null && key.toLowerCase(Locale.ROOT).contains("leather")) {
            return 0xA06540;
        }
        return null;
    }

    private static Integer readDyedColorComponent(ItemStack stack) {
        Object dyed = stack.get(DataComponents.DYED_COLOR);
        if (dyed == null) {
            return null;
        }
        Object value = unwrapOptional(dyed);
        if (value instanceof Integer integer) {
            return integer;
        }
        Object target = value == null ? dyed : value;
        for (String method : new String[] { "getColor", "color", "getRgb", "rgb", "value" }) {
            try {
                var m = target.getClass().getMethod(method);
                Object result = m.invoke(target);
                Object unwrapped = unwrapOptional(result);
                if (unwrapped instanceof Integer integer) {
                    return integer;
                }
            } catch (ReflectiveOperationException ignored) {
                // try next
            }
        }
        String text = target.toString();
        if (text != null) {
            Integer parsed = parseRgbFromText(text);
            if (parsed != null) {
                return parsed;
            }
        }
        return null;
    }

    private static Integer readColorFromCustomData(CompoundTag custom) {
        Integer dyed = readInt(custom, "minecraft:dyed_color");
        if (dyed != null) {
            return dyed;
        }
        String color = readString(custom, "color");
        if (color != null) {
            Integer parsed = parseRgbString(color);
            if (parsed != null) {
                return parsed;
            }
        }
        Integer colorInt = readInt(custom, "color");
        if (colorInt != null) {
            return colorInt;
        }
        return null;
    }

    private static Integer readInt(CompoundTag tag, String key) {
        if (!tag.contains(key)) {
            return null;
        }
        try {
            var getInt = tag.getClass().getMethod("getInt", String.class);
            Object value = getInt.invoke(tag, key);
            Object unwrapped = unwrapOptional(value);
            if (unwrapped instanceof Integer integer) {
                return integer;
            }
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
        return null;
    }

    private static Integer parseRgbString(String value) {
        String cleaned = value.trim();
        String[] parts = cleaned.split("[,: ]+");
        if (parts.length != 3) {
            return null;
        }
        try {
            int r = Integer.parseInt(parts[0].trim());
            int g = Integer.parseInt(parts[1].trim());
            int b = Integer.parseInt(parts[2].trim());
            r = clampColor(r);
            g = clampColor(g);
            b = clampColor(b);
            return (r << 16) | (g << 8) | b;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static Integer parseRgbFromText(String text) {
        int idx = text.indexOf("rgb=");
        if (idx < 0) {
            return null;
        }
        int start = idx + 4;
        int end = start;
        while (end < text.length() && Character.isDigit(text.charAt(end))) {
            end++;
        }
        if (end <= start) {
            return null;
        }
        try {
            return Integer.parseInt(text.substring(start, end));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static int clampColor(int value) {
        if (value < 0) {
            return 0;
        }
        if (value > 255) {
            return 255;
        }
        return value;
    }

    private static Object unwrapOptional(Object value) {
        if (value instanceof java.util.Optional<?> optional) {
            return optional.orElse(null);
        }
        return value;
    }

    private static String describeDyedComponent(ItemStack stack) {
        Object dyed = stack.get(DataComponents.DYED_COLOR);
        if (dyed == null) {
            return "null";
        }
        Object unwrapped = unwrapOptional(dyed);
        Object target = unwrapped == null ? dyed : unwrapped;
        return target.getClass().getName() + ":" + target.toString();
    }

    private static CompoundTag getCustomData(ItemStack stack) {
        // Read client-visible custom data component across MC versions.
        Object custom = stack.get(DataComponents.CUSTOM_DATA);
        if (custom == null) {
            return null;
        }
        try {
            var getTag = custom.getClass().getMethod("getTag");
            Object tagObj = getTag.invoke(custom);
            if (tagObj instanceof CompoundTag compoundTag) {
                return unwrapCustomData(compoundTag);
            }
            if (tagObj instanceof java.util.Optional<?> optional) {
                Object inner = optional.orElse(null);
                if (inner instanceof CompoundTag compoundTag) {
                    return unwrapCustomData(compoundTag);
                }
            }
        } catch (ReflectiveOperationException ignored) {
            // Try alternate method names across versions.
        }
        try {
            var copyTag = custom.getClass().getMethod("copyTag");
            Object tagObj = copyTag.invoke(custom);
            if (tagObj instanceof CompoundTag compoundTag) {
                return unwrapCustomData(compoundTag);
            }
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
        return null;
    }

    private static String readUuidFromFullNbt(ItemStack stack) {
        // Attempt UUID extraction from the serialized stack NBT.
        CompoundTag root = getFullNbt(stack);
        if (root == null) {
            return null;
        }
        CompoundTag tag = getCompound(root, "tag");
        String uuid = readUuidFromExtraAttributes(tag);
        if (uuid != null) {
            return uuid;
        }
        if (tag != null) {
            uuid = readUuidFrom(tag);
            if (uuid != null) {
                return uuid;
            }
        }
        CompoundTag components = getCompound(root, "components");
        CompoundTag custom = getCompound(components, "minecraft:custom_data");
        if (custom != null && custom.contains("data")) {
            Tag data = custom.get("data");
            if (data instanceof CompoundTag compoundTag) {
                custom = compoundTag;
            }
        }
        uuid = readUuidFromExtraAttributes(custom);
        if (uuid != null) {
            return uuid;
        }
        if (custom != null) {
            uuid = readUuidFrom(custom);
            if (uuid != null) {
                return uuid;
            }
        }
        return readUuidFromExtraAttributes(root);
    }

    private static CompoundTag getFullNbt(ItemStack stack) {
        // Serialize the stack to NBT via reflective save() variants.
        if (stack == null) {
            return null;
        }
        try {
            CompoundTag root = new CompoundTag();
            var method = stack.getClass().getMethod("save", CompoundTag.class);
            Object result = method.invoke(stack, root);
            if (result instanceof CompoundTag compound) {
                return compound;
            }
            return root;
        } catch (ReflectiveOperationException ignored) {
            // try other variants below
        } catch (RuntimeException ignored) {
            // fall through
        }
        CompoundTag direct = tryInvokeNoArgTag(stack, "save");
        if (direct != null) {
            return direct;
        }
        net.minecraft.core.RegistryAccess registryAccess = getRegistryAccess();
        if (registryAccess != null) {
            CompoundTag fromOptional = tryInvokeRegistryTag(stack, "saveOptional", registryAccess);
            if (fromOptional != null) {
                return fromOptional;
            }
            CompoundTag fromSave = tryInvokeRegistryTag(stack, "save", registryAccess);
            if (fromSave != null) {
                return fromSave;
            }
        }
        return null;
    }

    private static CompoundTag tryInvokeNoArgTag(ItemStack stack, String name) {
        try {
            var method = stack.getClass().getMethod(name);
            Object result = method.invoke(stack);
            if (result instanceof CompoundTag compound) {
                return compound;
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return null;
        }
        return null;
    }

    private static CompoundTag tryInvokeRegistryTag(ItemStack stack, String name, net.minecraft.core.RegistryAccess registryAccess) {
        try {
            var method = stack.getClass().getMethod(name, net.minecraft.core.RegistryAccess.class);
            Object result = method.invoke(stack, registryAccess);
            if (result instanceof CompoundTag compound) {
                return compound;
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return null;
        }
        return null;
    }

    private static net.minecraft.core.RegistryAccess getRegistryAccess() {
        Minecraft client = Minecraft.getInstance();
        if (client == null || client.level == null) {
            return null;
        }
        try {
            return client.level.registryAccess();
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private static CompoundTag getCompound(CompoundTag tag, String key) {
        if (tag == null || key == null || key.isBlank() || !tag.contains(key)) {
            return null;
        }
        Tag value = tag.get(key);
        if (value instanceof CompoundTag compound) {
            return compound;
        }
        return null;
    }

    private static CompoundTag unwrapCustomData(CompoundTag tag) {
        if (tag == null) {
            return null;
        }
        if (tag.contains("data")) {
            Tag data = tag.get("data");
            if (data instanceof CompoundTag compoundTag) {
                return compoundTag;
            }
        }
        return tag;
    }

    private static java.util.Set<String> getAllKeys(CompoundTag tag) {
        try {
            var method = tag.getClass().getMethod("getAllKeys");
            Object value = method.invoke(tag);
            if (value instanceof java.util.Set<?> set) {
                java.util.Set<String> keys = new java.util.HashSet<>();
                for (Object entry : set) {
                    if (entry != null) {
                        String raw = entry.toString();
                        int eq = raw.indexOf('=');
                        keys.add(eq > 0 ? raw.substring(0, eq) : raw);
                    }
                }
                return keys;
            }
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        try {
            var method = tag.getClass().getMethod("getKeys");
            Object value = method.invoke(tag);
            if (value instanceof java.util.Set<?> set) {
                java.util.Set<String> keys = new java.util.HashSet<>();
                for (Object entry : set) {
                    if (entry != null) {
                        String raw = entry.toString();
                        int eq = raw.indexOf('=');
                        keys.add(eq > 0 ? raw.substring(0, eq) : raw);
                    }
                }
                return keys;
            }
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        return java.util.Set.of();
    }

    private static String describeCustomComponent(Object customComponent) {
        if (customComponent == null) {
            return "null";
        }
        String name = customComponent.getClass().getName();
        String raw = customComponent.toString();
        if (raw == null) {
            return name + ":null";
        }
        String safe = raw.length() > 300 ? raw.substring(0, 300) + "..." : raw;
        return name + ":" + safe;
    }

    private static String readUuidFromExtraAttributes(CompoundTag tag) {
        if (tag == null) {
            return null;
        }
        if (tag.contains("ExtraAttributes")) {
            Tag extraTag = tag.get("ExtraAttributes");
            if (extraTag instanceof CompoundTag extra) {
                return readUuidFrom(extra);
            }
        }
        return null;
    }

    private static String normalizeKey(String input) {
        return ArmorKeyResolver.normalizeKey(input);
    }

    private static String mapStormToWiseWither(String armorKey) {
        return ArmorKeyResolver.mapWitherAndAliases(armorKey);
    }

    public static final class LiveScanResult {
        public final String armorKey;
        public final String armorSetKey;
        public final String pieceType;
        public final String colorHex;
        public final String illegalType;

        private LiveScanResult(String armorKey, String armorSetKey, String pieceType, String colorHex, String illegalType) {
            this.armorKey = armorKey;
            this.armorSetKey = armorSetKey;
            this.pieceType = pieceType;
            this.colorHex = colorHex;
            this.illegalType = illegalType;
        }
    }
}
