package com.notdogshit.exoscanner.scan;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;

import java.util.function.Consumer;

public final class LobbyChangeDetector {
    // Detects lobby changes via world/server/chat signals and notifies a callback.
    private final Consumer<String> callback;
    private ClientLevel lastWorld;
    private String lastServerAddress;

    public LobbyChangeDetector(Consumer<String> callback) {
        this.callback = callback;
    }

    public void onJoin() {
        // Explicit join hook (connection event).
        trigger("join");
    }

    public void onDisconnect() {
        // Explicit disconnect hook (connection event).
        trigger("disconnect");
    }

    public void onChatMessage(String message) {
        // Detect lobby move hints from chat.
        if (message == null) {
            return;
        }
        if (message.contains("Sending to server")) {
            trigger("chat");
        }
    }

    public void onTick(Minecraft client) {
        // Detect world or server address transitions.
        if (client == null) {
            return;
        }
        ClientLevel world = client.level;
        if (world != lastWorld) {
            lastWorld = world;
            trigger("world");
        }
        if (client.getCurrentServer() != null) {
            String address = client.getCurrentServer().ip;
            if (address != null && !address.equals(lastServerAddress)) {
                lastServerAddress = address;
                trigger("server");
            }
        }
    }

    private void trigger(String reason) {
        if (callback != null) {
            callback.accept(reason);
        }
    }
}
