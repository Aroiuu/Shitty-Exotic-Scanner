package com.notdogshit.exoscanner.scan;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.decoration.ItemFrame;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class DisplayEntityTracker {
    // Tracks armor stands and item frames for scan/debug utilities.
    private final Map<Integer, Tracked> tracked = new ConcurrentHashMap<>();

    public void onEntityLoad(ClientLevel world, Entity entity) {
        // Register display entities when they load.
        if (world == null || entity == null) {
            return;
        }
        if (!isDisplayEntity(entity)) {
            return;
        }
        tracked.put(entity.getId(), new Tracked(world, entity));
    }

    public void onEntityUnload(ClientLevel world, Entity entity) {
        // Remove tracked entities on unload.
        if (entity == null) {
            return;
        }
        tracked.remove(entity.getId());
    }

    public List<Entity> snapshot(ClientLevel world) {
        // Snapshot of currently valid display entities in this world.
        List<Entity> out = new ArrayList<>();
        if (world == null) {
            return out;
        }
        for (var entry : tracked.entrySet()) {
            Tracked value = entry.getValue();
            if (value == null || value.entity == null) {
                tracked.remove(entry.getKey());
                continue;
            }
            if (value.world != world || value.entity.isRemoved()) {
                tracked.remove(entry.getKey());
                continue;
            }
            out.add(value.entity);
        }
        return out;
    }

    public void clear() {
        // Clear all tracked entities (e.g., on disconnect).
        tracked.clear();
    }

    public Stats stats(ClientLevel world) {
        // Convenience counts for debug stats output.
        int total = 0;
        int armorStands = 0;
        int itemFrames = 0;
        for (Entity entity : snapshot(world)) {
            total++;
            if (entity instanceof ArmorStand) {
                armorStands++;
            } else if (entity instanceof ItemFrame) {
                itemFrames++;
            }
        }
        return new Stats(total, armorStands, itemFrames);
    }

    private static boolean isDisplayEntity(Entity entity) {
        return entity instanceof ArmorStand || entity instanceof ItemFrame;
    }

    private record Tracked(ClientLevel world, Entity entity) {}

    public record Stats(int total, int armorStands, int itemFrames) {}
}
