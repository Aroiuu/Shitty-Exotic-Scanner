package com.notdogshit.exoscanner.scan;

import com.notdogshit.exoscanner.ExoScannerClient;
import com.notdogshit.exoscanner.api.ApiKeyManager;
import com.notdogshit.exoscanner.api.HypixelApiClient;
import com.notdogshit.exoscanner.cache.ScanCache;
import com.notdogshit.exoscanner.config.ConfigManager;
import com.notdogshit.exoscanner.config.ExoScannerConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.world.entity.player.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

public final class AutoLobbyScanService {
    // Background scheduler for automatic lobby scans with rate limiting.
    private static final long PERIODIC_INTERVAL_MS = 5L * 60L * 1000L;
    private static final long MOJANG_NEGATIVE_TTL_MS = 6L * 60L * 60L * 1000L;
    private static final int MOJANG_CACHE_MAX = 5000;

    private final ConfigManager configManager;
    private final ApiKeyManager apiKeyManager;
    private final HypixelApiClient hypixelApiClient;
    private final ScanCache scanCache;
    private final ScheduledExecutorService scheduler;
    private final Map<String, MojangCacheEntry> mojangCache = new ConcurrentHashMap<>();

    private ScheduledFuture<?> pending;
    private volatile boolean running;
    private volatile long lastScanAt;
    private volatile long autoPauseUntil;
    private volatile long nextPeriodicAt;
    private volatile boolean warnedAllKeys;

    public AutoLobbyScanService(ConfigManager configManager,
                                ApiKeyManager apiKeyManager,
                                HypixelApiClient hypixelApiClient,
                                ScanCache scanCache,
                                ScheduledExecutorService scheduler) {
        this.configManager = configManager;
        this.apiKeyManager = apiKeyManager;
        this.hypixelApiClient = hypixelApiClient;
        this.scanCache = scanCache;
        this.scheduler = scheduler;
    }

    public void onLobbySwitch(String reason) {
        // Trigger scan on lobby change when enabled.
        ExoScannerConfig cfg = configManager.get();
        if (!cfg.enableAutoLobbyScan || !cfg.autoScanOnLobbySwitch) {
            return;
        }
        scheduleScan("lobby:" + reason);
    }

    public void onTick(Minecraft client) {
        // Periodic scan timer (every 5 minutes) when enabled.
        ExoScannerConfig cfg = configManager.get();
        if (!cfg.enableAutoLobbyScan || !cfg.autoScanEvery5Minutes) {
            return;
        }
        long now = System.currentTimeMillis();
        if (nextPeriodicAt == 0L) {
            nextPeriodicAt = now + PERIODIC_INTERVAL_MS;
            return;
        }
        if (now >= nextPeriodicAt) {
            nextPeriodicAt = now + PERIODIC_INTERVAL_MS;
            scheduleScan("periodic");
        }
    }

    public AutoStatus getStatus() {
        ExoScannerConfig cfg = configManager.get();
        return new AutoStatus(cfg.enableAutoLobbyScan, cfg.autoScanOnLobbySwitch, cfg.autoScanEvery5Minutes,
            pending != null && !pending.isDone(), running, autoPauseUntil, nextPeriodicAt);
    }

    // Debounce and queue a scan on the scheduler thread.
    private void scheduleScan(String reason) {
        ExoScannerConfig cfg = configManager.get();
        long now = System.currentTimeMillis();
        long debounce = cfg.autoScanDebounceSeconds * 1000L;
        long jitter = cfg.autoScanJitterMillis > 0 ? (long) (Math.random() * cfg.autoScanJitterMillis) : 0L;
        long earliest = now + debounce + jitter;
        long minGapAt = lastScanAt + cfg.autoScanMinGapSeconds * 1000L;
        long runAt = Math.max(earliest, minGapAt);
        long delay = Math.max(0L, runAt - now);
        if (pending != null && !pending.isDone()) {
            pending.cancel(false);
        }
        if (cfg.debugLobbyScan) {
            ExoScannerClient.LOGGER.info(
                "AutoScan schedule reason={} debounceMs={} jitterMs={} minGapMs={} delayMs={}",
                reason, debounce, jitter, cfg.autoScanMinGapSeconds * 1000L, delay
            );
        }
        pending = scheduler.schedule(() -> runAutoScan(reason), delay, TimeUnit.MILLISECONDS);
    }

    private void runAutoScan(String reason) {
        if (running) {
            if (configManager.get().debugLobbyScan) {
                ExoScannerClient.LOGGER.info("AutoScan skip: already running. reason={}", reason);
            }
            return;
        }
        ExoScannerConfig cfg = configManager.get();
        if (!cfg.enableAutoLobbyScan) {
            if (cfg.debugLobbyScan) {
                ExoScannerClient.LOGGER.info("AutoScan skip: disabled. reason={}", reason);
            }
            return;
        }
        long now = System.currentTimeMillis();
        if (now < autoPauseUntil) {
            if (cfg.debugLobbyScan) {
                ExoScannerClient.LOGGER.info("AutoScan skip: paused until {}. reason={}", autoPauseUntil, reason);
            }
            return;
        }
        if (!isOnHypixelSkyblock()) {
            if (cfg.debugLobbyScan) {
                ExoScannerClient.LOGGER.info("AutoScan skip: not on Hypixel. reason={}", reason);
            }
            return;
        }
        ApiKeyManager.KeySelection selection = apiKeyManager.selectKeyForAuto(cfg);
        if (selection == null) {
            if (!warnedAllKeys) {
                warnedAllKeys = true;
                pauseAllKeys(cfg);
                sendClientMessage("ExoScanner: auto scan paused (no API keys available).");
            }
            if (cfg.debugLobbyScan) {
                ExoScannerClient.LOGGER.info("AutoScan skip: no keys available. reason={}", reason);
            }
            return;
        }
        if (cfg.debugLobbyScan) {
            ExoScannerClient.LOGGER.info("AutoScan start reason={} keySlot={}", reason, selection.slot);
        }
        sendClientMessage("ExoScanner: auto lobby scan starting (" + formatReason(reason) + ").");
        warnedAllKeys = false;
        running = true;
        try {
            performLobbyScan(selection, cfg, reason);
            lastScanAt = System.currentTimeMillis();
        } finally {
            running = false;
        }
    }

    private void performLobbyScan(ApiKeyManager.KeySelection selection, ExoScannerConfig cfg, String reason) {
        Minecraft client = Minecraft.getInstance();
        if (client == null) {
            return;
        }
        List<PlayerIdentity> players = getLobbyPlayers(client);
        if (players.isEmpty()) {
            if (cfg.debugLobbyScan) {
                ExoScannerClient.LOGGER.info("AutoScan abort: no players. reason={} keySlot={}", reason, selection.slot);
            }
            return;
        }
        int maxPlayers = Math.max(1, cfg.autoScanMaxPlayersPerScan);
        int maxRequests = Math.max(1, cfg.autoScanMaxRequestsPerScan);
        int cacheDays = cfg.lobbyCacheDays;
        boolean cacheEnabled = cfg.enablePlayerCache;
        int scanned = 0;
        int skipped = 0;
        int errors = 0;
        int found = 0;
        int requestsUsed = 0;
        int filtered = 0;
        pruneMojangCache();
        if (cfg.debugLobbyScan) {
            ExoScannerClient.LOGGER.info(
                "AutoScan run reason={} players={} maxPlayers={} maxRequests={} keySlot={}",
                reason, players.size(), maxPlayers, maxRequests, selection.slot
            );
        }
        for (PlayerIdentity player : players) {
            if (scanned >= maxPlayers) {
                break;
            }
            if (requestsUsed + 2 > maxRequests) {
                if (cfg.debugLobbyScan) {
                    ExoScannerClient.LOGGER.info(
                        "AutoScan stop: request budget reached. reason={} keySlot={} used={}",
                        reason, selection.slot, requestsUsed
                    );
                }
                break;
            }
            if (cacheEnabled && !scanCache.shouldScan(player.uuid, cacheDays)) {
                skipped++;
                continue;
            }
            if (!isMojangAccount(player, cfg)) {
                filtered++;
                continue;
            }
            try {
                scanned++;
                requestsUsed += 2;
                HypixelApiClient.ScanSummary summary =
                    hypixelApiClient.scanProfiles(player.uuid, player.name, selection.key, apiKeyManager, selection.slot);
                if (cacheEnabled) {
                    scanCache.markScanned(player.uuid);
                }
                if (summary.totalExotics > 0) {
                    found++;
                    sendScanSummary(player.name, player.uuid, summary);
                }
                if (apiKeyManager.isCooling(selection.slot)) {
                    if (cfg.debugLobbyScan) {
                        ExoScannerClient.LOGGER.info("AutoScan stop: key cooling. reason={} keySlot={}", reason, selection.slot);
                    }
                    break;
                }
            } catch (Exception e) {
                errors++;
                int status = extractStatus(e);
                if (status == 403) {
                    sendClientMessage("ExoScanner: API key slot " + selection.slot + " forbidden/invalid.");
                    if (cfg.debugLobbyScan) {
                        ExoScannerClient.LOGGER.info("AutoScan stop: key forbidden. reason={} keySlot={}", reason, selection.slot);
                    }
                    break;
                }
                if (status == 429 || status >= 500) {
                    if (cfg.debugLobbyScan) {
                        ExoScannerClient.LOGGER.info("AutoScan stop: api error status={} reason={} keySlot={}", status, reason, selection.slot);
                    }
                    break;
                }
            }
        }
        if (cfg.debugLobbyScan) {
            ExoScannerClient.LOGGER.info(
                "AutoScan done reason={} scanned={} cached={} filtered={} errors={} found={} keySlot={}",
                reason, scanned, skipped, filtered, errors, found, selection.slot
            );
        }
        sendClientMessage("ExoScanner: auto lobby scan complete. reason=" + reason
            + " scanned=" + scanned
            + " cached=" + skipped
            + " filtered=" + filtered
            + " errors=" + errors
            + " found=" + found
            + " keySlot=" + selection.slot);
    }

    private boolean isMojangAccount(PlayerIdentity player, ExoScannerConfig cfg) {
        if (player == null || player.name == null || player.name.isBlank()) {
            return false;
        }
        if (player.uuid == null) {
            return false;
        }
        if (player.uuid.version() != 4) {
            if (cfg.debugLobbyScan) {
                ExoScannerClient.LOGGER.info(
                    "AutoScan skip: non-v4 UUID name={} uuid={}", player.name, player.uuid);
            }
            return false;
        }
        String name = player.name.trim();
        if (!isValidUsername(name)) {
            if (cfg.debugLobbyScan) {
                ExoScannerClient.LOGGER.info(
                    "AutoScan skip: invalid username name={} uuid={}", player.name, player.uuid);
            }
            return false;
        }
        String key = name.toLowerCase(Locale.ROOT);
        long now = System.currentTimeMillis();
        MojangCacheEntry cached = mojangCache.get(key);
        if (cached != null && now - cached.checkedAt <= resolveMojangTtlMs(cfg, cached.valid)) {
            boolean ok = cached.valid && cached.uuid != null && cached.uuid.equals(player.uuid);
            if (!ok && cfg.debugLobbyScan) {
                ExoScannerClient.LOGGER.info(
                    "AutoScan skip: Mojang cache mismatch name={} cacheUuid={} serverUuid={}",
                    name, cached.uuid, player.uuid
                );
            }
            return ok;
        }
        UUID resolved = null;
        try {
            resolved = hypixelApiClient.resolveUuid(name);
        } catch (Exception e) {
            if (e instanceof InterruptedException) {
                Thread.currentThread().interrupt();
            }
            if (cfg.debugLobbyScan) {
                ExoScannerClient.LOGGER.info("AutoScan skip: Mojang lookup failed name={} err={}", name, e.toString());
            }
            mojangCache.put(key, new MojangCacheEntry(null, now, false));
            return false;
        }
        mojangCache.put(key, new MojangCacheEntry(resolved, now, resolved != null));
        if (resolved == null) {
            if (cfg.debugLobbyScan) {
                ExoScannerClient.LOGGER.info("AutoScan skip: Mojang lookup empty name={}", name);
            }
            return false;
        }
        if (!resolved.equals(player.uuid)) {
            if (cfg.debugLobbyScan) {
                ExoScannerClient.LOGGER.info(
                    "AutoScan skip: Mojang UUID mismatch name={} mojang={} server={}",
                    name, resolved, player.uuid
                );
            }
            return false;
        }
        if (cfg.debugLobbyScan) {
            ExoScannerClient.LOGGER.info(
                "AutoScan ok: Mojang verified name={} uuid={}",
                name, resolved
            );
        }
        return true;
    }

    private void pruneMojangCache() {
        if (mojangCache.size() <= MOJANG_CACHE_MAX) {
            return;
        }
        long now = System.currentTimeMillis();
        mojangCache.entrySet().removeIf(entry ->
            now - entry.getValue().checkedAt > resolveMojangTtlMs(configManager.get(), entry.getValue().valid));
    }

    // Shorter TTL for invalid name lookups to avoid stale negatives.
    private static long resolveMojangTtlMs(ExoScannerConfig cfg, boolean valid) {
        if (!valid) {
            return MOJANG_NEGATIVE_TTL_MS;
        }
        int days = cfg == null ? 0 : cfg.lobbyCacheDays;
        if (days < 1) {
            days = 1;
        }
        return java.time.Duration.ofDays(days).toMillis();
    }

    private static String formatReason(String reason) {
        if (reason == null || reason.isBlank()) {
            return "unknown";
        }
        if (reason.startsWith("lobby:")) {
            return "lobby switch";
        }
        if ("periodic".equalsIgnoreCase(reason)) {
            return "5m timer";
        }
        return reason;
    }

    private void pauseAllKeys(ExoScannerConfig cfg) {
        long now = System.currentTimeMillis();
        autoPauseUntil = now + (long) cfg.autoPauseMinutesOnAllKeysExhausted * 60_000L;
    }

    public void clearAutoPause() {
        autoPauseUntil = 0L;
        warnedAllKeys = false;
    }

    private static int extractStatus(Exception e) {
        if (e == null || e.getMessage() == null) {
            return -1;
        }
        String msg = e.getMessage();
        int idx = msg.lastIndexOf("status");
        if (idx < 0) {
            return -1;
        }
        String tail = msg.substring(idx).replaceAll("[^0-9]", "");
        try {
            return Integer.parseInt(tail);
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    private boolean isOnHypixelSkyblock() {
        Minecraft client = Minecraft.getInstance();
        if (client == null || client.getCurrentServer() == null) {
            return false;
        }
        String address = client.getCurrentServer().ip;
        return address != null && address.toLowerCase().contains("hypixel");
    }

    private static void sendClientMessage(String message) {
        Minecraft client = Minecraft.getInstance();
        if (client != null && client.player != null) {
            client.execute(() -> client.player.displayClientMessage(net.minecraft.network.chat.Component.literal(message), false));
        }
    }

    private static void sendScanSummary(String username, UUID uuid, HypixelApiClient.ScanSummary summary) {
        ExoScannerClient.sendScanSummaryStatic(username, uuid, summary);
    }

    private static List<PlayerIdentity> getLobbyPlayers(Minecraft client) {
        java.util.Map<UUID, PlayerIdentity> tabPlayers = new java.util.HashMap<>();
        if (client.getConnection() != null) {
            for (var info : client.getConnection().getOnlinePlayers()) {
                if (!isListed(info)) {
                    continue;
                }
                Object profile = info.getProfile();
                UUID uuid = extractProfileId(profile);
                if (uuid == null) {
                    continue;
                }
                String name = extractProfileName(profile);
                if (!isValidUsername(name)) {
                    continue;
                }
                tabPlayers.putIfAbsent(uuid, new PlayerIdentity(uuid, name));
            }
        }

        java.util.Map<UUID, PlayerIdentity> worldPlayers = new java.util.HashMap<>();
        if (client.level != null) {
            for (Player player : client.level.players()) {
                UUID uuid = player.getUUID();
                if (uuid != null) {
                    worldPlayers.putIfAbsent(uuid, new PlayerIdentity(uuid, player.getName().getString()));
                }
            }
        }

        if (!worldPlayers.isEmpty() && worldPlayers.size() <= 2 && tabPlayers.size() > worldPlayers.size() + 10) {
            return new ArrayList<>(worldPlayers.values());
        }
        if (!tabPlayers.isEmpty()) {
            return new ArrayList<>(tabPlayers.values());
        }
        return new ArrayList<>(worldPlayers.values());
    }

    private static boolean isListed(Object playerInfo) {
        if (playerInfo == null) {
            return false;
        }
        try {
            Object value = playerInfo.getClass().getMethod("isListed").invoke(playerInfo);
            if (value instanceof Boolean b) {
                return b;
            }
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        try {
            Object value = playerInfo.getClass().getMethod("listed").invoke(playerInfo);
            if (value instanceof Boolean b) {
                return b;
            }
        } catch (ReflectiveOperationException ignored) {
            return true;
        }
        return true;
    }

    private static boolean isValidUsername(String rawName) {
        if (rawName == null || rawName.isBlank()) {
            return false;
        }
        String name = stripFormatting(rawName).trim();
        if (name.isEmpty()) {
            return false;
        }
        return name.matches("^[A-Za-z0-9_]{1,16}$");
    }

    private static String stripFormatting(String text) {
        if (text == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(text.length());
        boolean skipNext = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (skipNext) {
                skipNext = false;
                continue;
            }
            if (c == '\u00A7') {
                skipNext = true;
                continue;
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private static UUID extractProfileId(Object profile) {
        if (profile == null) {
            return null;
        }
        try {
            Object value = profile.getClass().getMethod("getId").invoke(profile);
            if (value instanceof UUID uuid) {
                return uuid;
            }
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        try {
            Object value = profile.getClass().getMethod("id").invoke(profile);
            if (value instanceof UUID uuid) {
                return uuid;
            }
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        try {
            var field = profile.getClass().getDeclaredField("id");
            field.setAccessible(true);
            Object value = field.get(profile);
            if (value instanceof UUID uuid) {
                return uuid;
            }
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
        return null;
    }

    private static String extractProfileName(Object profile) {
        if (profile == null) {
            return null;
        }
        try {
            Object value = profile.getClass().getMethod("getName").invoke(profile);
            return value == null ? null : value.toString();
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        try {
            Object value = profile.getClass().getMethod("name").invoke(profile);
            return value == null ? null : value.toString();
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        try {
            var field = profile.getClass().getDeclaredField("name");
            field.setAccessible(true);
            Object value = field.get(profile);
            return value == null ? null : value.toString();
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    private record PlayerIdentity(UUID uuid, String name) {
    }

    private record MojangCacheEntry(UUID uuid, long checkedAt, boolean valid) {
    }

    public record AutoStatus(boolean enabled, boolean onSwitch, boolean periodic, boolean pending,
                             boolean running, long pauseUntil, long nextPeriodic) {
    }
}
