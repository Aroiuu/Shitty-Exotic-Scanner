package com.notdogshit.exoscanner;

import com.notdogshit.exoscanner.api.ApiKeyManager;
import com.notdogshit.exoscanner.api.HypixelApiClient;
import com.notdogshit.exoscanner.armor.SeymourKeys;
import com.notdogshit.exoscanner.cache.ScanCache;
import com.notdogshit.exoscanner.color.ColorReferenceManager;
import com.notdogshit.exoscanner.color.SeymourTierService;
import com.notdogshit.exoscanner.config.ConfigManager;
import com.notdogshit.exoscanner.config.ExoScannerConfig;
import com.notdogshit.exoscanner.config.InventoryHighlightStyle;
import com.notdogshit.exoscanner.db.ExoScanDatabase;
import com.notdogshit.exoscanner.db.ScanRecord;
import com.notdogshit.exoscanner.illegal.IllegalType;
import com.notdogshit.exoscanner.scan.ArmorScanner;
import com.notdogshit.exoscanner.scan.AutoLobbyScanService;
import com.notdogshit.exoscanner.scan.DisplayEntityTracker;
import com.notdogshit.exoscanner.scan.LobbyChangeDetector;
import com.notdogshit.exoscanner.screen.ExoScannerConfigScreen;
import com.notdogshit.exoscanner.util.CommandFlags;
import com.notdogshit.exoscanner.util.ColorUtils;
import com.notdogshit.exoscanner.util.XlsxExporter;
import com.notdogshit.exoscanner.whitelist.WhitelistManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientEntityEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.TextColor;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import org.joml.Vector3f;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import com.mojang.brigadier.CommandDispatcher;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;

public final class ExoScannerClient implements ClientModInitializer {
    public static final String MOD_ID = "exoscanner";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static ConfigManager configManager;
    private static WhitelistManager whitelistManager;
    private static ExoScanDatabase database;
    private static ArmorScanner scanner;
    private static HypixelApiClient hypixelApiClient;
    private static ScanCache scanCache;
    private static boolean openConfigRequested;
    private static DisplayEntityTracker displayTracker;
    private static ExecutorService backgroundExecutor;
    private static ApiKeyManager apiKeyManager;
    private static AutoLobbyScanService autoLobbyScanService;
    private static LobbyChangeDetector lobbyChangeDetector;
    private static String manualTraceTargetName;
    private static UUID manualTraceTargetUuid;
    private static long traceDebugLastAt;

    private static final SuggestionProvider<FabricClientCommandSource> ARMOR_SUGGEST = (ctx, builder) -> {
        Set<String> options = new LinkedHashSet<>();
        options.add("ANY");
        options.add("SEYMOUR");
        if (database != null) {
            options.addAll(database.getArmorKeySuggestions());
            options.addAll(database.getArmorSetSuggestions());
        }
        return suggestMatching(builder, options);
    };

    private static final SuggestionProvider<FabricClientCommandSource> COLOR_SUGGEST = (ctx, builder) -> {
        return suggestMatching(builder, ColorUtils.namedColorKeys());
    };

    private static final SuggestionProvider<FabricClientCommandSource> SEARCH_FLAG_SUGGEST =
        (ctx, builder) -> suggestFlags(builder, List.of("de=", "since=", "metric="));

    private static final SuggestionProvider<FabricClientCommandSource> SEYMOUR_PIECES_FLAG_SUGGEST =
        (ctx, builder) -> suggestFlags(builder, List.of("tier=", "count=", "since=", "fades="));

    private static final SuggestionProvider<FabricClientCommandSource> SEYMOUR_SETS_FLAG_SUGGEST =
        (ctx, builder) -> suggestFlags(builder, List.of("cross", "de=", "hex=", "since=", "metric="));

    private static final SuggestionProvider<FabricClientCommandSource> RECENT_FLAG_SUGGEST =
        (ctx, builder) -> suggestFlags(builder, List.of("since="));

    private static final SuggestionProvider<FabricClientCommandSource> EXPORT_FLAG_SUGGEST =
        (ctx, builder) -> suggestFlags(builder, List.of("since=", "type=", "armor="));

    private static final SuggestionProvider<FabricClientCommandSource> TYPE_SUGGEST =
        (ctx, builder) -> suggestMatching(builder, List.of("exotic", "fairy", "crystal", "seymour", "bleached", "glitched", "any"));

    private static final SuggestionProvider<FabricClientCommandSource> DEBUG_LOG_SUGGEST =
        (ctx, builder) -> suggestMatching(builder, List.of("armor", "api", "lobby", "all"));

    @Override
    public void onInitializeClient() {
        // Core client bootstrap: load config/state, wire subsystems, and register events/commands.
        configManager = new ConfigManager();
        ExoScannerConfig config = configManager.loadOrCreate();

        whitelistManager = new WhitelistManager();
        whitelistManager.loadOrCreate();

        database = new ExoScanDatabase(config);
        database.loadExisting();

        scanCache = new ScanCache();
        scanCache.loadOrCreate();

        hypixelApiClient = new HypixelApiClient(configManager, whitelistManager, database);

        scanner = new ArmorScanner(configManager, whitelistManager, database);
        displayTracker = new DisplayEntityTracker();
        apiKeyManager = new ApiKeyManager();
        backgroundExecutor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "ExoScanner-Worker");
            t.setDaemon(true);
            return t;
        });
        autoLobbyScanService = new AutoLobbyScanService(
            configManager,
            apiKeyManager,
            hypixelApiClient,
            scanCache,
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "ExoScanner-AutoScan");
                t.setDaemon(true);
                return t;
            })
        );
        lobbyChangeDetector = new LobbyChangeDetector(reason -> {
            autoLobbyScanService.onLobbySwitch(reason);
            sendClientMessage("ExoScanner: lobby change detected (" + reason + ").");
        });
        ColorReferenceManager.get().reload();

        // Event hooks for entity tracking, tick scanning, render overlays, and lobby transitions.
        ClientEntityEvents.ENTITY_LOAD.register((entity, world) -> displayTracker.onEntityLoad(world, entity));
        ClientEntityEvents.ENTITY_UNLOAD.register((entity, world) -> displayTracker.onEntityUnload(world, entity));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> displayTracker.clear());
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> displayTracker.clear());
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> lobbyChangeDetector.onJoin());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> lobbyChangeDetector.onDisconnect());
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> lobbyChangeDetector.onChatMessage(message.getString()));
        WorldRenderEvents.END_MAIN.register(ExoScannerClient::renderPlayerTrace);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Tick-driven tasks: scanning, lobby detection, auto-scans, and deferred UI open.
            scanner.onClientTick(client);
            lobbyChangeDetector.onTick(client);
            autoLobbyScanService.onTick(client);
            if (openConfigRequested) {
                openConfigRequested = false;
                LOGGER.info("Opening ExoScannerConfigScreen from tick. screen={}", client == null ? "null" : client.screen);
                if (client != null) {
                    client.setScreen(ExoScannerConfigScreen.create(configManager, whitelistManager, client.screen));
                }
            }
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> registerCommands(dispatcher));

        // Persist API usage/config on shutdown to avoid losing rate-limit state.
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                if (configManager != null && apiKeyManager != null) {
                    apiKeyManager.exportUsage(configManager.get());
                    configManager.save();
                }
            } catch (Exception e) {
                LOGGER.warn("Failed to persist API key usage on shutdown.", e);
            }
        }, "ExoScanner-Shutdown"));

        LOGGER.info("ExoScanner initialized.");
    }

    private static void registerCommands(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        // Client-side /exo commands (no server packets).
        dispatcher.register(literal("exo")
            .then(literal("scan")
                .then(literal("near").executes(ctx -> {
                    runNearScan();
                    return 1;
                }))
                .then(literal("island")
                    .executes(ctx -> {
                        Minecraft client = Minecraft.getInstance();
                        String owner = client != null && client.player != null
                            ? client.player.getName().getString()
                            : "PRIVATE_ISLAND";
                        runIslandScan(owner);
                        return 1;
                    })
                    .then(argument("owner", StringArgumentType.word())
                        .executes(ctx -> {
                            String owner = StringArgumentType.getString(ctx, "owner");
                            runIslandScan(owner);
                            return 1;
                        })))
                .then(literal("api")
                    .then(literal("lobby")
                        .executes(ctx -> {
                            runLobbyScan(false);
                            return 1;
                        })
                        .then(literal("force").executes(ctx -> {
                            runLobbyScan(true);
                            return 1;
                        })))
                    .then(argument("username", StringArgumentType.word())
                        .executes(ctx -> {
                            String username = StringArgumentType.getString(ctx, "username");
                            runPlayerScan(username);
                            return 1;
                        }))))
            .then(literal("search")
                .then(argument("armor", StringArgumentType.word()).suggests(ARMOR_SUGGEST)
                    .then(argument("color", StringArgumentType.string()).suggests(COLOR_SUGGEST)
                        .executes(ctx -> {
                            String armor = StringArgumentType.getString(ctx, "armor");
                            String color = StringArgumentType.getString(ctx, "color");
                            return runSearch(armor, color, null);
                        })
                        .then(argument("flags", StringArgumentType.greedyString()).suggests(SEARCH_FLAG_SUGGEST)
                            .executes(ctx -> {
                                String armor = StringArgumentType.getString(ctx, "armor");
                                String color = StringArgumentType.getString(ctx, "color");
                                String flags = StringArgumentType.getString(ctx, "flags");
                                return runSearch(armor, color, flags);
                            }))))
                .then(literal("player")
                    .then(argument("username", StringArgumentType.word())
                        .executes(ctx -> {
                            String username = StringArgumentType.getString(ctx, "username");
                            runPlayerSearch(username);
                            return 1;
                        }))))
            .then(literal("trace")
                .then(argument("player", StringArgumentType.word())
                    .executes(ctx -> {
                        String player = StringArgumentType.getString(ctx, "player");
                        setTraceTarget(player);
                        return 1;
                    })))
            .then(literal("seymour")
                .then(literal("pieces")
                    .executes(ctx -> runSeymourPieces(null))
                    .then(argument("flags", StringArgumentType.greedyString()).suggests(SEYMOUR_PIECES_FLAG_SUGGEST)
                        .executes(ctx -> {
                            String flags = StringArgumentType.getString(ctx, "flags");
                            return runSeymourPieces(flags);
                        })))
                .then(literal("sets")
                    .executes(ctx -> runSeymourSets(null))
                    .then(argument("flags", StringArgumentType.greedyString()).suggests(SEYMOUR_SETS_FLAG_SUGGEST)
                        .executes(ctx -> {
                            String flags = StringArgumentType.getString(ctx, "flags");
                            return runSeymourSets(flags);
                        }))))
            .then(literal("db")
                .then(literal("stats").executes(ctx -> {
                    sendDbStats();
                    return 1;
                }))
                .then(literal("recent")
                    .executes(ctx -> {
                        runDbRecent(null);
                        return 1;
                    })
                    .then(argument("flags", StringArgumentType.greedyString()).suggests(RECENT_FLAG_SUGGEST)
                        .executes(ctx -> {
                            String flags = StringArgumentType.getString(ctx, "flags");
                            return runDbRecent(flags);
                        })))
                .then(literal("rollback")
                    .executes(ctx -> runDbRollback(null))
                    .then(argument("flags", StringArgumentType.greedyString()).suggests(RECENT_FLAG_SUGGEST)
                        .executes(ctx -> {
                            String flags = StringArgumentType.getString(ctx, "flags");
                            return runDbRollback(flags);
                        })))
                .then(literal("update").executes(ctx -> runDbUpdate()))
                .then(literal("import")
                    .then(argument("path", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            String path = StringArgumentType.getString(ctx, "path");
                            return runDbImport(path);
                        })))
                .then(literal("count")
                    .then(argument("armorId", StringArgumentType.word()).suggests(ARMOR_SUGGEST)
                        .executes(ctx -> {
                            String armorId = StringArgumentType.getString(ctx, "armorId");
                            runDbCount(armorId, "ANY");
                            return 1;
                        })
                        .then(argument("type", StringArgumentType.word()).suggests(TYPE_SUGGEST)
                            .executes(ctx -> {
                                String armorId = StringArgumentType.getString(ctx, "armorId");
                                String type = StringArgumentType.getString(ctx, "type");
                                runDbCount(armorId, type);
                                return 1;
                            })))))
            .then(literal("export")
                .then(literal("csv")
                    .executes(ctx -> runExportCsv(null))
                    .then(argument("flags", StringArgumentType.greedyString()).suggests(EXPORT_FLAG_SUGGEST)
                        .executes(ctx -> {
                            String flags = StringArgumentType.getString(ctx, "flags");
                            return runExportCsv(flags);
                        })))
                .then(literal("xlsx")
                    .executes(ctx -> runExportXlsx(null))
                    .then(argument("flags", StringArgumentType.greedyString()).suggests(EXPORT_FLAG_SUGGEST)
                        .executes(ctx -> {
                            String flags = StringArgumentType.getString(ctx, "flags");
                            return runExportXlsx(flags);
                        }))))
            .then(literal("config").executes(ctx -> {
                openConfigRequested = true;
                return 1;
            }))
            .then(literal("whitelist")
                .then(literal("reload").executes(ctx -> {
                    whitelistManager.reload();
                    sendClientMessage("ExoScanner: whitelist reloaded.");
                    return 1;
                })))
            .then(literal("apikey")
                .then(argument("key", StringArgumentType.greedyString())
                    .executes(ctx -> {
                        String key = StringArgumentType.getString(ctx, "key");
                        String normalized = ConfigManager.normalizeApiKey(key);
                        if (normalized == null) {
                            sendClientMessage("ExoScanner: invalid API key format. Use /api new and paste the full UUID.");
                            return 1;
                        }
                        configManager.setApiKey(normalized);
                        sendClientMessage("ExoScanner API key saved.");
                        return 1;
                    })))
            .then(literal("api")
                .then(literal("status").executes(ctx -> {
                    sendApiStatus();
                    return 1;
                }))
                .then(literal("unpause").executes(ctx -> {
                    if (autoLobbyScanService != null) {
                        autoLobbyScanService.clearAutoPause();
                        if (apiKeyManager != null) {
                            apiKeyManager.clearPauses();
                        }
                        sendClientMessage("ExoScanner: auto scan unpaused.");
                    } else {
                        sendClientMessage("ExoScanner: auto scan service not ready.");
                    }
                    return 1;
                })))
            .then(literal("debug")
                .then(literal("scanall").executes(ctx -> {
                    boolean newValue = !configManager.get().debugScanAllLeather;
                    configManager.setDebugScanAllLeather(newValue);
                    sendClientMessage("ExoScanner debug all leather: " + (newValue ? "ON" : "OFF"));
                    return 1;
                }))
                .then(literal("log")
                    .executes(ctx -> {
                        boolean newValue = !(configManager.get().debugArmorScan
                            && configManager.get().debugApiScan
                            && configManager.get().debugLobbyScan);
                        configManager.setDebugAll(newValue);
                        sendClientMessage("ExoScanner debug logging (all): " + (newValue ? "ON" : "OFF"));
                        return 1;
                    })
                    .then(argument("target", StringArgumentType.word()).suggests(DEBUG_LOG_SUGGEST)
                        .executes(ctx -> {
                            String target = StringArgumentType.getString(ctx, "target");
                            if (target == null) {
                                sendClientMessage("ExoScanner: missing debug target. Use armor|api|lobby|all.");
                                return 1;
                            }
                            switch (target.toLowerCase(Locale.ROOT)) {
                                case "armor" -> {
                                    boolean newValue = !configManager.get().debugArmorScan;
                                    configManager.setDebugArmorScan(newValue);
                                    sendClientMessage("ExoScanner debug armor scan: " + (newValue ? "ON" : "OFF"));
                                    return 1;
                                }
                                case "api" -> {
                                    boolean newValue = !configManager.get().debugApiScan;
                                    configManager.setDebugApiScan(newValue);
                                    sendClientMessage("ExoScanner debug api scan: " + (newValue ? "ON" : "OFF"));
                                    return 1;
                                }
                                case "lobby" -> {
                                    boolean newValue = !configManager.get().debugLobbyScan;
                                    configManager.setDebugLobbyScan(newValue);
                                    sendClientMessage("ExoScanner debug lobby scan: " + (newValue ? "ON" : "OFF"));
                                    return 1;
                                }
                                case "all" -> {
                                    boolean newValue = !(configManager.get().debugArmorScan
                                        && configManager.get().debugApiScan
                                        && configManager.get().debugLobbyScan);
                                    configManager.setDebugAll(newValue);
                                    sendClientMessage("ExoScanner debug logging (all): " + (newValue ? "ON" : "OFF"));
                                    return 1;
                                }
                                default -> {
                                    sendClientMessage("ExoScanner: unknown debug target " + target + ". Use armor|api|lobby|all.");
                                    return 1;
                                }
                            }
                        })))
                .then(literal("db")
                    .then(literal("remove")
                        .then(argument("player", StringArgumentType.word())
                            .executes(ctx -> {
                                String player = StringArgumentType.getString(ctx, "player");
                                runDebugDbRemove(player);
                                return 1;
                            }))))
                .then(literal("displays").executes(ctx -> {
                    Minecraft client = Minecraft.getInstance();
                    ClientLevel world = client == null ? null : client.level;
                    DisplayEntityTracker.Stats stats = displayTracker.stats(world);
                    sendClientMessage("ExoScanner: tracked displays total=" + stats.total()
                        + " armorStands=" + stats.armorStands()
                        + " itemFrames=" + stats.itemFrames());
                    return 1;
                })))
            .then(literal("help").executes(ctx -> {
                sendExoHelp();
                return 1;
            })));

        // Legacy aliases
        dispatcher.register(literal("exoscanconfig").executes(ctx -> {
            openConfigRequested = true;
            return 1;
        }));
        dispatcher.register(literal("ecoscanconfig").executes(ctx -> {
            openConfigRequested = true;
            return 1;
        }));
        dispatcher.register(literal("exoapikey")
            .then(argument("key", StringArgumentType.greedyString())
                .executes(ctx -> {
                    String key = StringArgumentType.getString(ctx, "key");
                    String normalized = ConfigManager.normalizeApiKey(key);
                    if (normalized == null) {
                        sendClientMessage("ExoScanner: invalid API key format. Use /api new and paste the full UUID.");
                        return 1;
                    }
                    configManager.setApiKey(normalized);
                    sendClientMessage("ExoScanner API key saved.");
                    return 1;
                })));
        dispatcher.register(literal("exoplayerscan")
            .then(argument("username", StringArgumentType.word())
                .executes(ctx -> {
                    String username = StringArgumentType.getString(ctx, "username");
                    runPlayerScan(username);
                    return 1;
                })));
        dispatcher.register(literal("exolobbyscan")
            .executes(ctx -> {
                runLobbyScan(false);
                return 1;
            })
            .then(literal("force").executes(ctx -> {
                runLobbyScan(true);
                return 1;
            })));
        dispatcher.register(literal("exoislandscan")
            .executes(ctx -> {
                Minecraft client = Minecraft.getInstance();
                String owner = client != null && client.player != null ? client.player.getName().getString() : "PRIVATE_ISLAND";
                runIslandScan(owner);
                return 1;
            })
            .then(argument("owner", StringArgumentType.word()).executes(ctx -> {
                String owner = StringArgumentType.getString(ctx, "owner");
                runIslandScan(owner);
                return 1;
            })));
        dispatcher.register(literal("exoplayersearch")
            .then(argument("username", StringArgumentType.word())
                .executes(ctx -> {
                    String username = StringArgumentType.getString(ctx, "username");
                    runPlayerSearch(username);
                    return 1;
                })));
        dispatcher.register(literal("exoarmorsearch")
            .then(argument("armorId", StringArgumentType.word())
                .then(argument("hex", StringArgumentType.string())
                    .executes(ctx -> {
                        String armor = StringArgumentType.getString(ctx, "armorId");
                        String color = StringArgumentType.getString(ctx, "hex");
                        return runSearch(armor, color, null);
                    }))));
        dispatcher.register(literal("findsimilararmor")
            .then(argument("armorId", StringArgumentType.word())
                .then(argument("hex", StringArgumentType.string())
                    .executes(ctx -> {
                        String armor = StringArgumentType.getString(ctx, "armorId");
                        String color = StringArgumentType.getString(ctx, "hex");
                        String flags = "de=5.0";
                        return runSearch(armor, color, flags);
                    })
                    .then(argument("distance", DoubleArgumentType.doubleArg(0.0))
                        .executes(ctx -> {
                            String armor = StringArgumentType.getString(ctx, "armorId");
                            String color = StringArgumentType.getString(ctx, "hex");
                            double distance = DoubleArgumentType.getDouble(ctx, "distance");
                            String flags = "de=" + distance;
                            return runSearch(armor, color, flags);
                        })))));
        dispatcher.register(literal("findseymourset")
            .executes(ctx -> runSeymourSets(null))
            .then(argument("hex", StringArgumentType.string())
                .executes(ctx -> {
                    String hex = StringArgumentType.getString(ctx, "hex");
                    return runSeymourSets("hex=" + hex);
                })
                .then(argument("distance", DoubleArgumentType.doubleArg(0.0))
                    .executes(ctx -> {
                        String hex = StringArgumentType.getString(ctx, "hex");
                        double distance = DoubleArgumentType.getDouble(ctx, "distance");
                        return runSeymourSets("hex=" + hex + " de=" + distance);
                    })))
            .then(argument("distance", DoubleArgumentType.doubleArg(0.0))
                .executes(ctx -> {
                    double distance = DoubleArgumentType.getDouble(ctx, "distance");
                    return runSeymourSets("de=" + distance);
                }))
            .then(literal("cross")
                .executes(ctx -> runSeymourSets("cross"))
                .then(argument("hex", StringArgumentType.string())
                    .executes(ctx -> {
                        String hex = StringArgumentType.getString(ctx, "hex");
                        return runSeymourSets("cross hex=" + hex);
                    })
                    .then(argument("distance", DoubleArgumentType.doubleArg(0.0))
                        .executes(ctx -> {
                            String hex = StringArgumentType.getString(ctx, "hex");
                            double distance = DoubleArgumentType.getDouble(ctx, "distance");
                            return runSeymourSets("cross hex=" + hex + " de=" + distance);
                        })))
                .then(argument("distance", DoubleArgumentType.doubleArg(0.0))
                    .executes(ctx -> {
                        double distance = DoubleArgumentType.getDouble(ctx, "distance");
                        return runSeymourSets("cross de=" + distance);
                    }))));
        dispatcher.register(literal("findseymour")
            .then(argument("tier", IntegerArgumentType.integer(0, 3))
                .executes(ctx -> {
                    int tier = IntegerArgumentType.getInteger(ctx, "tier");
                    return runSeymourPieces("tier=" + tier);
                })
                .then(argument("count", IntegerArgumentType.integer(1, 200))
                    .executes(ctx -> {
                        int tier = IntegerArgumentType.getInteger(ctx, "tier");
                        int count = IntegerArgumentType.getInteger(ctx, "count");
                        return runSeymourPieces("tier=" + tier + " count=" + count);
                    }))));
        dispatcher.register(literal("exodbstats").executes(ctx -> {
            sendDbStats();
            return 1;
        }));
        dispatcher.register(literal("exodbrecent").executes(ctx -> {
            runDbRecent(null);
            return 1;
        }));
        dispatcher.register(literal("exodbupdate").executes(ctx -> {
            return runDbUpdate();
        }));
        dispatcher.register(literal("exodbbackfillillegal").executes(ctx -> {
            return runDbUpdate();
        }));
        dispatcher.register(literal("exoapistats").executes(ctx -> {
            sendApiStatusSummary();
            return 1;
        }));
        dispatcher.register(literal("exoscandebug").executes(ctx -> {
            boolean newValue = !configManager.get().debugScanAllLeather;
            configManager.setDebugScanAllLeather(newValue);
            sendClientMessage("ExoScanner debug all leather: " + (newValue ? "ON" : "OFF"));
            return 1;
        }));
        dispatcher.register(literal("exoscandebuglog").executes(ctx -> {
            boolean newValue = !(configManager.get().debugArmorScan
                && configManager.get().debugApiScan
                && configManager.get().debugLobbyScan);
            configManager.setDebugAll(newValue);
            sendClientMessage("ExoScanner debug logging (all): " + (newValue ? "ON" : "OFF"));
            return 1;
        }));
        dispatcher.register(literal("exoscandebugall").executes(ctx -> {
            boolean newValue = !(configManager.get().debugArmorScan
                && configManager.get().debugApiScan
                && configManager.get().debugLobbyScan);
            configManager.setDebugAll(newValue);
            sendClientMessage("ExoScanner debug logging (all): " + (newValue ? "ON" : "OFF"));
            return 1;
        }));
        dispatcher.register(literal("exohelp").executes(ctx -> {
            sendExoHelp();
            return 1;
        }));
    }

    private static java.util.concurrent.CompletableFuture<com.mojang.brigadier.suggestion.Suggestions> suggestMatching(
        SuggestionsBuilder builder,
        Iterable<String> options
    ) {
        String remaining = builder.getRemaining().toLowerCase(Locale.ROOT);
        for (String option : options) {
            if (option == null) {
                continue;
            }
            String normalized = option.toLowerCase(Locale.ROOT);
            if (remaining.isEmpty() || normalized.startsWith(remaining)) {
                builder.suggest(option);
            }
        }
        return builder.buildFuture();
    }

    private static java.util.concurrent.CompletableFuture<com.mojang.brigadier.suggestion.Suggestions> suggestFlags(
        SuggestionsBuilder builder,
        List<String> flags
    ) {
        String remaining = builder.getRemaining();
        String lower = remaining.toLowerCase(Locale.ROOT);
        String lastToken = lower;
        int lastSpace = lower.lastIndexOf(' ');
        if (lastSpace >= 0) {
            lastToken = lower.substring(lastSpace + 1);
        }
        if (lastToken.startsWith("metric=")) {
            return suggestKeyValues(builder, "metric=", List.of("76", "2000"));
        }
        if (lastToken.startsWith("fades=")) {
            return suggestKeyValues(builder, "fades=", List.of("high", "low", "off"));
        }
        if (lastToken.startsWith("type=")) {
            return suggestKeyValues(builder, "type=", List.of("exotic", "fairy", "crystal", "seymour", "bleached", "any"));
        }
        if (lastToken.startsWith("armor=")) {
            Set<String> options = new LinkedHashSet<>();
            options.addAll(database == null ? Set.of() : database.collectArmorKeys());
            options.addAll(database == null ? Set.of() : database.collectArmorSets());
            return suggestKeyValues(builder, "armor=", options);
        }
        if (lastToken.startsWith("since=")) {
            return suggestKeyValues(builder, "since=", List.of("5m", "2h", "7d", "30d"));
        }
        if (lastToken.startsWith("hex=")) {
            return suggestKeyValues(builder, "hex=", ColorUtils.namedColorKeys());
        }
        Set<String> options = new LinkedHashSet<>(flags);
        return suggestMatching(builder, options);
    }

    private static java.util.concurrent.CompletableFuture<com.mojang.brigadier.suggestion.Suggestions> suggestKeyValues(
        SuggestionsBuilder builder,
        String prefix,
        Iterable<String> options
    ) {
        String remaining = builder.getRemaining().toLowerCase(Locale.ROOT);
        for (String option : options) {
            if (option == null) {
                continue;
            }
            String suggestion = prefix + option;
            if (remaining.isEmpty() || suggestion.toLowerCase(Locale.ROOT).startsWith(remaining)) {
                builder.suggest(suggestion);
            }
        }
        return builder.buildFuture();
    }

    private static void runPlayerScan(String username) {
        String apiKey = configManager.get().apiKey;
        ApiKeyManager.KeySelection selection = apiKeyManager.selectKeyForManual(configManager.get());
        if (selection == null || selection.key == null || selection.key.isBlank()) {
            if (apiKey == null || apiKey.isBlank()) {
                sendClientMessage("ExoScanner: set your Hypixel API key with /exoapikey <key>.");
                return;
            }
            selection = ApiKeyManager.KeySelection.of(1, apiKey);
        }
        final ApiKeyManager.KeySelection finalSelection = selection;
        CompletableFuture.runAsync(() -> {
            try {
                UUID uuid = hypixelApiClient.resolveUuid(username);
                if (uuid == null) {
                    sendClientMessage("ExoScanner: failed to resolve username " + username + ".");
                    return;
                }
                HypixelApiClient.ScanSummary summary =
                    hypixelApiClient.scanProfiles(uuid, username, finalSelection.key, apiKeyManager, finalSelection.slot);
                sendScanSummary(username, uuid, summary);
                if (configManager.get().enablePlayerCache) {
                    scanCache.markScanned(uuid);
                }
            } catch (Exception e) {
                LOGGER.warn("Player scan failed.", e);
                sendClientMessage("ExoScanner: player scan failed. Check logs.");
            }
        });
    }

    private static void runLobbyScan(boolean ignoreCache) {
        Minecraft client = Minecraft.getInstance();
        if (client == null) {
            sendClientMessage("ExoScanner: not in a world.");
            return;
        }
        ApiKeyManager.KeySelection selection = apiKeyManager.selectKeyForManual(configManager.get());
        if (selection == null || selection.key == null || selection.key.isBlank()) {
            sendClientMessage("ExoScanner: set your Hypixel API key with /exoapikey <key>.");
            return;
        }
        List<PlayerIdentity> players = getLobbyPlayerIdentities(client);
        if (players.isEmpty()) {
            sendClientMessage("ExoScanner: lobby scan failed. No players found.");
            return;
        }
        ExoScannerConfig cfg = configManager.get();
        int cacheDays = cfg.lobbyCacheDays;
        boolean cacheEnabled = cfg.enablePlayerCache;
        boolean debug = configManager.get().debugApiScan;
        CompletableFuture.runAsync(() -> {
            int foundCount = 0;
            int scannedCount = 0;
            int skippedCount = 0;
            int errorCount = 0;
            for (PlayerIdentity player : players) {
                UUID uuid = player.uuid;
                if (!ignoreCache && cacheEnabled && !scanCache.shouldScan(uuid, cacheDays)) {
                    skippedCount++;
                    if (debug) {
                        LOGGER.info("Lobby scan skip cached: player={}, uuid={}", player.name, uuid);
                    }
                    continue;
                }
                try {
                    scannedCount++;
                    HypixelApiClient.ScanSummary summary =
                        hypixelApiClient.scanProfiles(uuid, player.name, selection.key, apiKeyManager, selection.slot);
                    if (cacheEnabled) {
                        scanCache.markScanned(uuid);
                    }
                    if (summary.totalExotics > 0) {
                        foundCount++;
                        sendScanSummary(player.name, uuid, summary);
                    }
                } catch (Exception e) {
                    errorCount++;
                    LOGGER.warn("Lobby scan failed for {}", player.name, e);
                }
            }
            if (foundCount == 0) {
                sendClientMessage("ExoScanner: lobby scan complete. No new exotics found."
                    + " scanned=" + scannedCount
                    + " cached=" + skippedCount
                    + " errors=" + errorCount
                    + (ignoreCache ? " mode=force" : ""));
            } else {
                sendClientMessage("ExoScanner: lobby scan complete."
                    + " scanned=" + scannedCount
                    + " cached=" + skippedCount
                    + " errors=" + errorCount
                    + (ignoreCache ? " mode=force" : ""));
            }
        });
    }

    private static void runIslandScan(String owner) {
        Minecraft client = Minecraft.getInstance();
        if (client == null) {
            sendClientMessage("ExoScanner: not in a world.");
            return;
        }
        String ownerName = owner == null || owner.isBlank() ? "PRIVATE_ISLAND" : owner;
        int scanned = scanIslandDisplays(client, ownerName);
        sendClientMessage("ExoScanner: island scan complete. owner=" + ownerName + " displays=" + scanned + ".");
    }

    private static void runNearScan() {
        Minecraft client = Minecraft.getInstance();
        if (client == null) {
            sendClientMessage("ExoScanner: not in a world.");
            return;
        }
        scanner.scanNow(client);
        sendClientMessage("ExoScanner: near scan complete.");
    }

    public static boolean shouldHighlightStack(ItemStack stack) {
        if (stack == null || stack.isEmpty() || scanner == null || configManager == null) {
            return false;
        }
        ExoScannerConfig cfg = configManager.get();
        if (cfg == null || !cfg.enableInventoryHighlight) {
            return false;
        }
        ArmorScanner.LiveScanResult result = scanner.evaluateItemStack(stack, "UNKNOWN");
        if (result == null) {
            return false;
        }
        return result.illegalType == null || !"SEYMOUR".equalsIgnoreCase(result.illegalType);
    }

    public static InventoryHighlightStyle getHighlightStyle() {
        if (configManager == null) {
            return InventoryHighlightStyle.TRANSLUCENT;
        }
        ExoScannerConfig cfg = configManager.get();
        if (cfg == null || cfg.inventoryHighlightStyle == null) {
            return InventoryHighlightStyle.TRANSLUCENT;
        }
        return cfg.inventoryHighlightStyle;
    }

    public static int getHighlightColor() {
        if (configManager == null) {
            return 0xFF5555;
        }
        ExoScannerConfig cfg = configManager.get();
        if (cfg == null) {
            return 0xFF5555;
        }
        return cfg.inventoryHighlightColor;
    }

    private static int runSearch(String armorInput, String colorInput, String flagsInput) {
        CommandFlags flags = CommandFlags.parse(flagsInput);
        Double distance = flags.getDouble("de");
        if (distance == null) {
            distance = 5.0;
        }
        Long sinceEpoch = resolveSinceEpoch(flags, false);
        if (sinceEpoch != null && sinceEpoch == Long.MIN_VALUE) {
            return 0;
        }
        int metric = resolveMetric(flags);
        boolean useCie76 = metric == 76;
        String colorHex = ColorUtils.normalizeHexInput(colorInput);
        try {
            ColorUtils.parseHex(colorHex);
        } catch (RuntimeException e) {
            sendClientMessage("ExoScanner: invalid color " + colorInput);
            return 0;
        }

        List<ScanRecord> results = new ArrayList<>();
        if ("ANY".equalsIgnoreCase(armorInput)) {
            List<ScanRecord> anyResults = new ArrayList<>();
            double maxDistance = distance;
            Integer targetRgb = null;
            if (maxDistance > 0.0) {
                try {
                    targetRgb = ColorUtils.parseHex(colorHex);
                } catch (RuntimeException e) {
                    sendClientMessage("ExoScanner: invalid color " + colorInput);
                    return 0;
                }
            }
            Integer finalTargetRgb = targetRgb;
            database.forEachRecord(record -> {
                if (record == null || record.colorHex == null) {
                    return;
                }
                if (sinceEpoch != null && record.timestamp < sinceEpoch) {
                    return;
                }
                if (maxDistance <= 0.0) {
                    if (record.colorHex.equalsIgnoreCase(colorHex)) {
                        anyResults.add(record);
                    }
                    return;
                }
                try {
                    int recordRgb = ColorUtils.parseHex(record.colorHex);
                    double d = useCie76 ? ColorUtils.cie76(finalTargetRgb, recordRgb) : ColorUtils.ciede2000(finalTargetRgb, recordRgb);
                    if (d <= maxDistance) {
                        record.matchDistance = d;
                        anyResults.add(record);
                    }
                } catch (RuntimeException ignored) {
                }
            });
            results = anyResults;
        } else if ("SEYMOUR".equalsIgnoreCase(armorInput)) {
            if (distance <= 0.0) {
                results = database.findByArmorKeysAndColor(SeymourKeys.KEYS, colorHex);
            } else {
                results = database.findByArmorKeysAndColorDistance(SeymourKeys.KEYS, colorHex, distance, useCie76);
            }
        } else {
            if (distance <= 0.0) {
                results = database.findByArmorAndColorDistance(armorInput, colorHex, 0.0, useCie76);
            } else {
                results = database.findByArmorAndColorDistance(armorInput, colorHex, distance, useCie76);
            }
        }

        results = filterBySince(results, sinceEpoch);
        sendSearchResults("Search", results);
        return 1;
    }

    private static int runSeymourPieces(String flagsInput) {
        CommandFlags flags = CommandFlags.parse(flagsInput);
        Integer tier = flags.getInt("tier");
        Integer count = flags.getInt("count");
        if (count == null) {
            count = 10;
        }
        SeymourTierService.Settings settings = resolveSeymourSettings(flags);
        Long sinceEpoch = resolveSinceEpoch(flags, false);
        if (sinceEpoch != null && sinceEpoch == Long.MIN_VALUE) {
            return 0;
        }
        final int limit = count;
        CompletableFuture.runAsync(() -> {
            List<SeymourMatch> matches = new ArrayList<>();
            database.forEachRecord(record -> {
                if (record == null || record.armorKey == null) {
                    return;
                }
                if (!SeymourKeys.isSeymourKey(record.armorKey)) {
                    return;
                }
                if (sinceEpoch != null && record.timestamp < sinceEpoch) {
                    return;
                }
                SeymourTierService.SeymourTierResult result = null;
                if (settings.includeFades && settings.showHighFades && settings.includeCustom
                    && record.seymourTier != null && record.seymourBestDeltaE != null
                    && record.seymourBestMatchName != null && record.seymourBestMatchHex != null) {
                    result = new SeymourTierService.SeymourTierResult(
                        record.seymourTier,
                        record.seymourBestDeltaE,
                        record.seymourBestMatchName,
                        record.seymourBestMatchHex
                    );
                } else {
                    result = SeymourTierService.computeTierForHex(record.colorHex, record.armorKey, settings);
                }
                if (result == null) {
                    return;
                }
                if (tier != null && result.tier != tier) {
                    return;
                }
                matches.add(new SeymourMatch(record, result));
            });

            matches.sort(Comparator.comparingDouble(r -> r.result.bestDeltaE));
            int shown = Math.min(limit, matches.size());
            List<Component> lines = new ArrayList<>();
            for (int i = 0; i < shown; i++) {
                SeymourMatch match = matches.get(i);
                ScanRecord record = match.record;
                String owner = safePlayer(record);
                String armorId = record.armorKey == null ? "UNKNOWN" : record.armorKey;
                String matchName = match.result.bestMatchName == null ? "UNKNOWN" : match.result.bestMatchName;
                double delta = match.result.bestDeltaE;
                int recordTier = match.result.tier;
                Component line = joinComponents(
                    Component.literal("Owner:" + owner + " " + armorId + " "),
                    coloredHexComponent(record.colorHex),
                    Component.literal(" match=" + matchName
                        + " dE=" + String.format(Locale.ROOT, "%.2f", delta)
                        + " tier=" + recordTier),
                    null
                );
                lines.add(line);
            }
            Minecraft client = Minecraft.getInstance();
            if (client != null) {
                client.execute(() -> {
                    sendClientMessage("ExoScanner: Seymour pieces matches=" + matches.size()
                        + (tier == null ? "" : " tier=" + tier));
                    for (Component line : lines) {
                        sendClientMessage(line);
                    }
                    if (matches.size() > shown) {
                        sendClientMessage("ExoScanner: " + (matches.size() - shown) + " more pieces not shown.");
                    }
                });
            }
        }, backgroundExecutor);
        return 1;
    }

    private static SeymourTierService.Settings resolveSeymourSettings(CommandFlags flags) {
        String fades = flags.getString("fades");
        boolean includeFades = true;
        boolean showHighFades = true;
        if (fades != null && !fades.isBlank()) {
            String normalized = fades.trim().toLowerCase(Locale.ROOT);
            switch (normalized) {
                case "off" -> includeFades = false;
                case "low" -> {
                    includeFades = true;
                    showHighFades = false;
                }
                case "high" -> {
                    includeFades = true;
                    showHighFades = true;
                }
                default -> {
                    // keep defaults
                }
            }
        }
        return new SeymourTierService.Settings(76, includeFades, showHighFades, true);
    }

    private static final class SeymourMatch {
        private final ScanRecord record;
        private final SeymourTierService.SeymourTierResult result;

        private SeymourMatch(ScanRecord record, SeymourTierService.SeymourTierResult result) {
            this.record = record;
            this.result = result;
        }
    }

    private static int runSeymourSets(String flagsInput) {
        CommandFlags flags = CommandFlags.parse(flagsInput);
        boolean cross = flags.has("cross");
        Double distance = flags.getDouble("de");
        String hex = flags.getString("hex");
        int metric = resolveMetric(flags);
        boolean useCie76 = metric == 76;
        Long sinceEpoch = resolveSinceEpoch(flags, false);
        if (sinceEpoch != null && sinceEpoch == Long.MIN_VALUE) {
            return 0;
        }
        findSeymourSet(hex, distance, cross, sinceEpoch, useCie76);
        return 1;
    }

    private static int runDbRecent(String flagsInput) {
        CommandFlags flags = CommandFlags.parse(flagsInput);
        Long sinceEpoch = resolveSinceEpoch(flags, true);
        if (sinceEpoch != null && sinceEpoch == Long.MIN_VALUE) {
            return 0;
        }
        List<ScanRecord> results = database.findRecentSince(sinceEpoch);
        sendRecentSummary(results, formatSinceLabel(sinceEpoch));
        return 1;
    }

    private static int runExportCsv(String flagsInput) {
        CommandFlags flags = CommandFlags.parse(flagsInput);
        Long sinceEpoch = resolveSinceEpoch(flags, false);
        if (sinceEpoch != null && sinceEpoch == Long.MIN_VALUE) {
            return 0;
        }
        String typeRaw = flags.getString("type");
        ExportTypeFilter typeFilter = parseExportTypeFilter(typeRaw);
        Set<String> armorFilter = parseArmorFilter(flags.getString("armor"));
        boolean exportSeymour = hasSeymourInExport(sinceEpoch, typeFilter, armorFilter);

        Path outPath = FabricLoader.getInstance().getConfigDir()
            .resolve("exo_export_" + System.currentTimeMillis() + ".csv");
        try (BufferedWriter writer = Files.newBufferedWriter(outPath, StandardOpenOption.CREATE_NEW)) {
            writer.write("timestamp,playerName,playerUuid,armorKey,armorSetKey,pieceType,illegalType,colorHex");
            if (exportSeymour) {
                writer.write(",seymourTier");
            }
            writer.newLine();
            final int[] count = {0};
            try {
                forEachExportRecord(sinceEpoch, typeFilter, armorFilter, record -> {
                    if (record == null) {
                        return;
                    }
                    String resolvedType = resolveIllegalType(record);
                    try {
                        String line = String.join(",",
                            String.valueOf(record.timestamp),
                            escapeCsv(record.playerName),
                            escapeCsv(record.playerUuid == null ? "" : record.playerUuid.toString()),
                            escapeCsv(record.armorKey),
                            escapeCsv(record.armorSetKey),
                            escapeCsv(record.pieceType),
                            escapeCsv(resolvedType),
                            escapeCsv(record.colorHex)
                        );
                        if (exportSeymour) {
                            Integer tier = resolveSeymourTier(record);
                            line = line + "," + escapeCsv(tier == null ? "" : String.valueOf(tier));
                        }
                        writer.write(line);
                        writer.newLine();
                        count[0]++;
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            } catch (RuntimeException e) {
                if (e.getCause() instanceof IOException io) {
                    throw io;
                }
                throw e;
            }
            sendClientMessage("ExoScanner: export complete records=" + count[0] + " file=" + outPath);
        } catch (IOException e) {
            sendClientMessage("ExoScanner: export failed: " + e.getMessage());
            return 0;
        }
        return 1;
    }

    private static int runExportXlsx(String flagsInput) {
        CommandFlags flags = CommandFlags.parse(flagsInput);
        Long sinceEpoch = resolveSinceEpoch(flags, false);
        if (sinceEpoch != null && sinceEpoch == Long.MIN_VALUE) {
            return 0;
        }
        String typeRaw = flags.getString("type");
        ExportTypeFilter typeFilter = parseExportTypeFilter(typeRaw);
        Set<String> armorFilter = parseArmorFilter(flags.getString("armor"));

        Path outPath = FabricLoader.getInstance().getConfigDir()
            .resolve("exo_export_" + System.currentTimeMillis() + ".xlsx");

        List<String> colorHexes = new ArrayList<>();
        boolean[] exportSeymour = {false};
        forEachExportRecord(sinceEpoch, typeFilter, armorFilter, record -> {
            if (record != null && record.colorHex != null && !record.colorHex.isBlank()) {
                colorHexes.add(record.colorHex);
            }
            if (!exportSeymour[0] && SeymourKeys.isSeymourKey(record == null ? null : record.armorKey)) {
                exportSeymour[0] = true;
            }
        });

        List<String> headers = new ArrayList<>(List.of(
            "timestamp",
            "playerName",
            "playerUuid",
            "armorKey",
            "armorSetKey",
            "pieceType",
            "illegalType",
            "colorHex"
        ));
        if (exportSeymour[0]) {
            headers.add("seymourTier");
        }
        headers.add("colorHexSwatch");

        try {
            XlsxExporter.write(outPath, headers, colorHexes, writer -> {
                forEachExportRecord(sinceEpoch, typeFilter, armorFilter, record -> {
                    if (record == null) {
                        return;
                    }
                    String resolvedType = resolveIllegalType(record);
                    List<String> values = new ArrayList<>(List.of(
                        String.valueOf(record.timestamp),
                        safeCsv(record.playerName),
                        safeCsv(record.playerUuid == null ? "" : record.playerUuid.toString()),
                        safeCsv(record.armorKey),
                        safeCsv(record.armorSetKey),
                        safeCsv(record.pieceType),
                        safeCsv(resolvedType),
                        safeCsv(record.colorHex)
                    ));
                    if (exportSeymour[0]) {
                        Integer tier = resolveSeymourTier(record);
                        values.add(tier == null ? "" : String.valueOf(tier));
                    }
                    values.add("");
                    try {
                        writer.writeRow(values, record.colorHex);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                });
            });
            sendClientMessage("ExoScanner: export complete file=" + outPath);
        } catch (IOException e) {
            sendClientMessage("ExoScanner: export failed: " + e.getMessage());
            return 0;
        }
        return 1;
    }

    private static void forEachExportRecord(Long sinceEpoch, ExportTypeFilter typeFilter, Set<String> armorFilter,
                                           java.util.function.Consumer<ScanRecord> consumer) {
        database.forEachRecord(record -> {
            if (record == null) {
                return;
            }
            if (sinceEpoch != null && record.timestamp < sinceEpoch) {
                return;
            }
            String resolvedType = resolveIllegalType(record);
            if (!typeFilter.matches(resolvedType)) {
                return;
            }
            if (!armorFilter.isEmpty()) {
                String armorKey = record.armorKey == null ? "" : record.armorKey.toUpperCase(Locale.ROOT);
                String armorSet = record.armorSetKey == null ? "" : record.armorSetKey.toUpperCase(Locale.ROOT);
                if (!armorFilter.contains(armorKey) && !armorFilter.contains(armorSet)) {
                    return;
                }
            }
            consumer.accept(record);
        });
    }

    private static String safeCsv(String value) {
        return value == null ? "" : value;
    }

    private static int runDbUpdate() {
        sendClientMessage("ExoScanner: db update started.");
        SeymourTierService.Settings settings = new SeymourTierService.Settings(
            76,
            true,
            true,
            true
        );
        CompletableFuture.runAsync(() -> {
            ExoScanDatabase.BackfillResult result =
                database.backfillIllegalTypesAndSeymourTiers(settings, scanned -> {
                    Minecraft client = Minecraft.getInstance();
                    if (client != null) {
                        client.execute(() -> sendClientMessage("ExoScanner: db update scanned=" + scanned));
                    }
                });
            Minecraft client = Minecraft.getInstance();
            if (client != null) {
                client.execute(() -> sendClientMessage(
                    "ExoScanner: db update complete. scanned=" + result.scanned
                        + " illegalUpdated=" + result.updatedIllegalTypes
                        + " seymourTierUpdated=" + result.updatedSeymourTiers
                        + " duplicatesRemoved=" + result.removedDuplicates
                        + " ignoredDyesRemoved=" + result.removedIgnoredDyes
                        + " softKeyDuplicatesRemoved=" + result.removedSoftKeyDuplicates
                ));
            }
        }, backgroundExecutor);
        return 1;
    }

    private static int runDbRollback(String flagsInput) {
        java.time.Duration duration = java.time.Duration.ofMinutes(5);
        if (flagsInput != null && !flagsInput.isBlank()) {
            CommandFlags flags = CommandFlags.parse(flagsInput);
            String sinceRaw = flags.getString("since");
            if (sinceRaw != null && !sinceRaw.isBlank()) {
                java.time.Duration parsed = CommandFlags.parseSince(sinceRaw);
                if (parsed == null) {
                    sendClientMessage("ExoScanner: invalid since value " + sinceRaw + ". Use 5m, 2h, 7d.");
                    return 0;
                }
                duration = parsed;
            }
        }
        long cutoff = System.currentTimeMillis() - duration.toMillis();
        sendClientMessage("ExoScanner: db rollback started (last " + formatSinceLabel(cutoff) + ").");
        CompletableFuture.runAsync(() -> {
            int removed = database.rollbackSince(cutoff, (processed, total) -> {
                Minecraft client = Minecraft.getInstance();
                if (client != null) {
                    client.execute(() -> sendClientMessage(
                        "ExoScanner: db rollback progress " + processed + "/" + total
                    ));
                }
            });
            Minecraft client = Minecraft.getInstance();
            if (client != null) {
                client.execute(() -> sendClientMessage(
                    "ExoScanner: db rollback complete. removed=" + removed
                ));
            }
        }, backgroundExecutor);
        return 1;
    }

    private static int runDbImport(String rawPath) {
        if (rawPath == null || rawPath.isBlank()) {
            sendClientMessage("ExoScanner: missing import path.");
            return 1;
        }
        Path path = resolveImportPath(rawPath);
        sendClientMessage("ExoScanner: db import started path=" + path);
        CompletableFuture.runAsync(() -> {
            ExoScanDatabase.ImportResult result = database.importFrom(path);
            Minecraft client = Minecraft.getInstance();
            if (client != null) {
                client.execute(() -> sendClientMessage(
                    "ExoScanner: db import complete. total=" + result.total
                        + " added=" + result.added
                        + " updated=" + result.updated
                        + " skipped=" + result.skipped
                        + " failed=" + result.failed
                ));
            }
        }, backgroundExecutor);
        return 1;
    }

    private static void runDbCount(String armorId, String typeRaw) {
        String armorFilter = armorId == null ? "" : armorId.trim().toUpperCase(Locale.ROOT);
        String typeFilter = typeRaw == null || typeRaw.isBlank()
            ? "ANY"
            : typeRaw.trim().toUpperCase(Locale.ROOT);
        CompletableFuture.runAsync(() -> {
            final int[] count = {0};
            database.forEachRecord(record -> {
                if (record == null) {
                    return;
                }
                String armorKey = record.armorKey == null ? "" : record.armorKey.toUpperCase(Locale.ROOT);
                String armorSet = record.armorSetKey == null ? "" : record.armorSetKey.toUpperCase(Locale.ROOT);
                if (!armorFilter.equals(armorKey) && !armorFilter.equals(armorSet)) {
                    return;
                }
                String resolvedType = resolveIllegalType(record).toUpperCase(Locale.ROOT);
                if (!"ANY".equals(typeFilter) && !resolvedType.equals(typeFilter)) {
                    return;
                }
                count[0]++;
            });
            Minecraft client = Minecraft.getInstance();
            if (client != null) {
                client.execute(() -> sendClientMessage(
                    "ExoScanner: db count armor=" + armorFilter + " type=" + typeFilter + " count=" + count[0]
                ));
            }
        }, backgroundExecutor);
    }

    private static void runDebugDbRemove(String player) {
        if (player == null || player.isBlank()) {
            sendClientMessage("ExoScanner: missing player name.");
            return;
        }
        String name = player.trim();
        sendClientMessage("ExoScanner: db remove started player=" + name);
        CompletableFuture.runAsync(() -> {
            int removed = database.clearByPlayerName(name);
            Minecraft client = Minecraft.getInstance();
            if (client != null) {
                client.execute(() -> sendClientMessage(
                    "ExoScanner: db remove complete player=" + name + " removed=" + removed
                ));
            }
        }, backgroundExecutor);
    }

    private static void runPlayerSearch(String username) {
        CompletableFuture.runAsync(() -> {
            List<ScanRecord> results = database.findByPlayerName(username);
            Minecraft client = Minecraft.getInstance();
            if (client != null) {
                client.execute(() -> sendSearchResults("Player search", results));
            }
        }, backgroundExecutor);
    }

    public static void sendScanSummaryStatic(String username, UUID uuid, HypixelApiClient.ScanSummary summary) {
        StringBuilder sets = new StringBuilder();
        for (var entry : summary.bySet.entrySet()) {
            if (sets.length() > 0) {
                sets.append(", ");
            }
            sets.append(entry.getKey()).append(": ").append(entry.getValue());
        }
        StringBuilder pieces = new StringBuilder();
        for (var entry : summary.byPiece.entrySet()) {
            if (pieces.length() > 0) {
                pieces.append(", ");
            }
            pieces.append(entry.getKey()).append(": ").append(entry.getValue());
        }
        StringBuilder types = new StringBuilder();
        for (var entry : summary.byType.entrySet()) {
            if (types.length() > 0) {
                types.append(", ");
            }
            types.append(entry.getKey()).append(": ").append(entry.getValue());
        }
        sendClientMessage("ExoScanner: " + username + " (" + uuid + ") exotics=" + summary.totalExotics);
        if (sets.length() > 0) {
            sendClientMessage("By set: " + sets);
        }
        if (pieces.length() > 0) {
            sendClientMessage("By piece: " + pieces);
        }
        if (types.length() > 0) {
            sendClientMessage("By type: " + types);
        }
    }

    private static void sendScanSummary(String username, UUID uuid, HypixelApiClient.ScanSummary summary) {
        sendScanSummaryStatic(username, uuid, summary);
    }

    private static void sendApiStatusSummary() {
        ExoScannerConfig cfg = configManager.get();
        List<ApiKeyManager.KeyStatus> statuses = apiKeyManager.getStatuses(cfg);
        int total5 = 0;
        int total24 = 0;
        for (ApiKeyManager.KeyStatus status : statuses) {
            total5 += status.count5m;
            total24 += status.count24h;
        }
        sendClientMessage("ExoScanner: Hypixel API requests last 5m=" + total5 + ", last 24h=" + total24);
    }

    private static void sendApiStatus() {
        ExoScannerConfig cfg = configManager.get();
        AutoLobbyScanService.AutoStatus auto = autoLobbyScanService.getStatus();
        boolean badKey = true;
        if (cfg.apiKeys != null && cfg.apiKeys.length > 0) {
            String key = cfg.apiKeys[0];
            badKey = ConfigManager.normalizeApiKey(key) == null;
        } else if (cfg.apiKey != null) {
            badKey = ConfigManager.normalizeApiKey(cfg.apiKey) == null;
        }
        sendClientMessage("ExoScanner API status:"
            + " autoEnabled=" + auto.enabled()
            + " onSwitch=" + auto.onSwitch()
            + " periodic=" + auto.periodic()
            + " pending=" + auto.pending()
            + " running=" + auto.running());
        if (auto.pauseUntil() > System.currentTimeMillis()) {
            long remaining = (auto.pauseUntil() - System.currentTimeMillis()) / 1000L;
            sendClientMessage("Auto scan paused: " + remaining + "s remaining.");
        }
        if (auto.nextPeriodic() > 0L) {
            long remaining = (auto.nextPeriodic() - System.currentTimeMillis()) / 1000L;
            if (remaining > 0) {
                sendClientMessage("Next periodic scan in " + remaining + "s.");
            }
        }
        for (ApiKeyManager.KeyStatus status : apiKeyManager.getStatuses(cfg)) {
            sendClientMessage("Key slot " + status.slot
                + ": present=" + status.present
                + " state=" + status.state
                + " 5m=" + status.count5m
                + " 24h=" + status.count24h);
        }
        if (badKey) {
            sendClientMessage("ExoScanner: API key appears invalid (expected full UUID).");
        }
    }

    private static void sendDbStats() {
        int total = database.countAllRecords();
        Map<String, Integer> byType = database.countByIllegalType();
        int seymour = database.countByArmorKeys(SeymourKeys.KEYS);
        int exotic = byType.getOrDefault("EXOTIC", 0);
        int crystal = byType.getOrDefault("CRYSTAL", 0);
        int fairy = byType.getOrDefault("FAIRY", 0);
        int ogFairy = byType.getOrDefault("OG_FAIRY", 0);
        int bleached = byType.getOrDefault("BLEACHED", 0);
        int glitched = byType.getOrDefault("GLITCHED", 0);
        int seymourType = byType.getOrDefault("SEYMOUR", 0);
        sendClientMessage("ExoScanner: db total=" + total
            + " exotic=" + exotic
            + " crystal=" + crystal
            + " fairy=" + fairy
            + " og_fairy=" + ogFairy
            + " bleached=" + bleached
            + " glitched=" + glitched
            + " seymour=" + seymourType
            + " seymour_keys=" + seymour);
    }

    private static void sendExoHelp() {
        sendClientMessage("/exo scan near - scan nearby players now");
        sendClientMessage("/exo scan island [owner] - scan armor stands/item frames on a private island");
        sendClientMessage("/exo scan api <username> - scan one player via Hypixel API");
        sendClientMessage("/exo scan api lobby [force] - scan lobby players via Hypixel API");
        sendClientMessage("/exo search player <username> - search local database by player name");
        sendClientMessage("/exo search <armor|ANY> <color> [dE=<distance>] [since=<time>] [metric=76|2000] (default dE=5.0)");
        sendClientMessage("/exo trace <player> - draw a tracer to a selected player (client-side)");
        sendClientMessage("/exo seymour pieces [tier=<0-3>] [count=<n>] [since=<time>] [fades=high|low|off]");
        sendClientMessage("/exo seymour sets [cross] [dE=<distance>] [hex=<color>] [since=<time>] [metric=76|2000]");
        sendClientMessage("/exo db stats | recent [since=<time>] | rollback [since=<time>] | update | import <path> | count <armorId> <type>");
        sendClientMessage("/exo export csv [since=<time>] [type=exotic|fairy|crystal|seymour|bleached|glitched|any|!<type[,type]>] [armor=<id[,id]>]");
        sendClientMessage("/exo export xlsx [since=<time>] [type=exotic|fairy|crystal|seymour|bleached|glitched|any|!<type[,type]>] [armor=<id[,id]>]");
        sendClientMessage("/exo api status - show API key usage and auto scan status");
        sendClientMessage("/exo config - open settings");
        sendClientMessage("/exo whitelist reload - reload the whitelist file");
        sendClientMessage("/exo debug log [armor|api|lobby|all] - toggle specific debug logs");
        sendClientMessage("/exo debug scanall - toggle scanning all leather");
        sendClientMessage("/exo debug displays - show tracked armor stands/item frames");
    }

    private static void setTraceTarget(String playerName) {
        if (playerName == null || playerName.isBlank()) {
            sendClientMessage("ExoScanner: missing player name for trace.");
            return;
        }
        manualTraceTargetName = playerName.trim();
        manualTraceTargetUuid = null;
        if (configManager != null && configManager.get().debugTrace) {
            LOGGER.info("Trace command set target name={}", manualTraceTargetName);
        }
        Minecraft client = Minecraft.getInstance();
        Player target = findTraceTarget(client == null ? null : client.level, manualTraceTargetName, manualTraceTargetUuid);
        if (target != null) {
            manualTraceTargetUuid = target.getUUID();
            if (configManager != null && configManager.get().debugTrace) {
                LOGGER.info("Trace command resolved target uuid={}", manualTraceTargetUuid);
            }
        }
        if (configManager != null && !configManager.get().enablePlayerTracking) {
            sendClientMessage("ExoScanner: trace target set to " + manualTraceTargetName
                + " (enable Player Tracking in config).");
            return;
        }
        if (target == null) {
            sendClientMessage("ExoScanner: trace target not found: " + manualTraceTargetName + ".");
            manualTraceTargetName = null;
            manualTraceTargetUuid = null;
            return;
        }
        sendClientMessage("ExoScanner: tracing player " + manualTraceTargetName + ".");
    }

    private static void renderPlayerTrace(WorldRenderContext context) {
        // Draw client-side tracer lines to manual/auto-selected players.
        if (configManager == null || !configManager.get().enablePlayerTracking) {
            return;
        }
        Minecraft client = Minecraft.getInstance();
        if (client == null || client.level == null || client.player == null) {
            return;
        }
        boolean debugTrace = configManager.get().debugTrace;
        boolean manualActive = manualTraceTargetName != null && !manualTraceTargetName.isBlank();
        List<Player> targets = new ArrayList<>();
        if (manualActive) {
            Player manualTarget = findTraceTarget(client.level, manualTraceTargetName, manualTraceTargetUuid);
            if (manualTarget == null) {
                if (debugTrace) {
                    LOGGER.info("Trace render: manual target not found name={}", manualTraceTargetName);
                }
                sendClientMessage("ExoScanner: trace target not found: " + manualTraceTargetName + ".");
                manualTraceTargetName = null;
                manualTraceTargetUuid = null;
                return;
            }
            if (shouldDisableManualTrace(client.player, manualTarget)) {
                if (debugTrace) {
                    LOGGER.info("Trace render: auto-disabled manual trace name={} distanceSqr={}",
                        manualTraceTargetName,
                        client.player.distanceToSqr(manualTarget));
                }
                manualTraceTargetName = null;
                manualTraceTargetUuid = null;
                sendClientMessage("ExoScanner: trace disabled (within radius).");
                return;
            }
            manualTraceTargetUuid = manualTarget.getUUID();
            targets.add(manualTarget);
        } else if (configManager.get().enableAutoTrace) {
            int limit = configManager.get().autoTraceMaxTargets;
            targets.addAll(findAutoTraceTargets(client.level, Math.max(1, Math.min(5, limit))));
            if (debugTrace) {
                LOGGER.info("Trace render: auto targets count={} limit={}", targets.size(), limit);
            }
        }
        if (targets.isEmpty()) {
            if (debugTrace) {
                LOGGER.info("Trace render: no targets to draw.");
            }
            return;
        }
        PoseStack matrices = context.matrices();
        MultiBufferSource consumers = context.consumers();
        var camera = client.gameRenderer.getMainCamera();
        Vec3 camPos = camera.getPosition();
        float tickDelta = client.getDeltaTracker().getGameTimeDeltaPartialTick(false);
        matrices.pushPose();
        double width = configManager.get().tracerLineWidth;
        if (debugTrace) {
            long now = System.currentTimeMillis();
            if (now - traceDebugLastAt > 1000L) {
                var poseMatrix = matrices.last().pose();
                LOGGER.info(
                    "Trace debug: width={} color={} camPos={} tickDelta={} poseTrans=({}, {}, {})",
                    width,
                    String.format("#%06X", configManager.get().tracerLineColor & 0xFFFFFF),
                    camPos,
                    tickDelta,
                    poseMatrix.m30(),
                    poseMatrix.m31(),
                    poseMatrix.m32()
                );
                traceDebugLastAt = now;
            }
        }
        GlStateManager._disableDepthTest();
        GlStateManager._depthMask(false);
        RenderSystem.lineWidth((float) Math.max(0.5, Math.min(8.0, width)));
        VertexConsumer consumer = consumers.getBuffer(RenderType.LINES);
        var pose = matrices.last();
        int rgb = configManager.get().tracerLineColor & 0xFFFFFF;
        float r = ((rgb >> 16) & 0xFF) / 255.0f;
        float g = ((rgb >> 8) & 0xFF) / 255.0f;
        float b = (rgb & 0xFF) / 255.0f;
        float a = 1.0f;
        double yOffset = configManager.get().tracerLineOffset;
        for (Player target : targets) {
            Vec3 targetPos = target.getPosition(tickDelta);
            Vec3 selfPos = client.player.getPosition(tickDelta);
            double targetEyeY = targetPos.y + target.getEyeHeight(Pose.STANDING);
            double selfEyeY = selfPos.y + client.player.getEyeHeight(Pose.STANDING);
            Vec3 end = new Vec3(targetPos.x, targetEyeY - yOffset, targetPos.z);
            Vec3 head = new Vec3(selfPos.x, selfEyeY - yOffset, selfPos.z);
            if (debugTrace) {
                LOGGER.info("Trace render: target={} end={} head={}", target.getName().getString(), end, head);
            }
            consumer.addVertex(pose,
                    (float) (head.x - camPos.x),
                    (float) (head.y - camPos.y),
                    (float) (head.z - camPos.z))
                .setColor(r, g, b, a)
                .setNormal(pose, 0.0f, 1.0f, 0.0f);
            consumer.addVertex(pose,
                    (float) (end.x - camPos.x),
                    (float) (end.y - camPos.y),
                    (float) (end.z - camPos.z))
                .setColor(r, g, b, a)
                .setNormal(pose, 0.0f, 1.0f, 0.0f);
        }
        if (consumers instanceof MultiBufferSource.BufferSource bufferSource) {
            bufferSource.endBatch(RenderType.LINES);
        }
        RenderSystem.lineWidth(1.0f);
        GlStateManager._depthMask(true);
        GlStateManager._enableDepthTest();
        matrices.popPose();
    }

    private static boolean shouldDisableManualTrace(Player self, Player target) {
        if (self == null || target == null || configManager == null) {
            return false;
        }
        double radius = configManager.get().tracerAutoDisableRadius;
        if (radius <= 0.0) {
            return false;
        }
        double max = radius * radius;
        return self.distanceToSqr(target) <= max;
    }

    private static Player findTraceTarget(ClientLevel level, String name, UUID uuid) {
        if (level == null || name == null || name.isBlank()) {
            return null;
        }
        if (uuid != null) {
            for (Player player : level.players()) {
                if (uuid.equals(player.getUUID())) {
                    return player;
                }
            }
        }
        String needle = name.toLowerCase(Locale.ROOT);
        for (Player player : level.players()) {
            String playerName = player.getName().getString();
            if (playerName != null && playerName.toLowerCase(Locale.ROOT).equals(needle)) {
                return player;
            }
        }
        return null;
    }

    private static List<Player> findAutoTraceTargets(ClientLevel level, int limit) {
        if (configManager == null || !configManager.get().enableAutoTrace) {
            return List.of();
        }
        ExoScannerConfig cfg = configManager.get();
        List<String> candidates = cfg.autoTracePlayers;
        if (candidates == null || candidates.isEmpty() || level == null || limit < 1) {
            return List.of();
        }
        List<Player> matches = new ArrayList<>();
        for (String raw : candidates) {
            if (raw == null || raw.isBlank()) {
                continue;
            }
            String needle = raw.trim().toLowerCase(Locale.ROOT);
            for (Player player : level.players()) {
                String name = player.getName().getString();
                if (name != null && name.toLowerCase(Locale.ROOT).equals(needle)) {
                    matches.add(player);
                    break;
                }
            }
            if (matches.size() >= limit) {
                break;
            }
        }
        return matches;
    }

    private static Long resolveSinceEpoch(CommandFlags flags, boolean useDefaultRetention) {
        String sinceRaw = flags.getString("since");
        if (sinceRaw == null || sinceRaw.isBlank()) {
            if (!useDefaultRetention) {
                return null;
            }
            int days = configManager.get().defaultRetentionDays;
            if (days < 1) {
                days = 30;
            }
            return System.currentTimeMillis() - java.time.Duration.ofDays(days).toMillis();
        }
        java.time.Duration duration = CommandFlags.parseSince(sinceRaw);
        if (duration == null) {
            sendClientMessage("ExoScanner: invalid since value " + sinceRaw + ". Use 5m, 2h, 7d.");
            return Long.MIN_VALUE;
        }
        return System.currentTimeMillis() - duration.toMillis();
    }

    private static int resolveMetric(CommandFlags flags) {
        String raw = flags.getString("metric");
        int fallback = configManager.get().defaultMetric;
        if (raw == null || raw.isBlank()) {
            return fallback;
        }
        String normalized = raw.trim().toLowerCase(Locale.ROOT);
        if ("76".equals(normalized) || "cie76".equals(normalized)) {
            return 76;
        }
        if ("2000".equals(normalized) || "ciede2000".equals(normalized)) {
            return 2000;
        }
        sendClientMessage("ExoScanner: invalid metric " + raw + ". Use 76 or 2000.");
        return fallback;
    }

    private static List<ScanRecord> filterBySince(List<ScanRecord> records, Long sinceEpoch) {
        if (sinceEpoch == null) {
            return records;
        }
        List<ScanRecord> filtered = new ArrayList<>();
        for (ScanRecord record : records) {
            if (record != null && record.timestamp >= sinceEpoch) {
                filtered.add(record);
            }
        }
        return filtered;
    }

    private static String formatSinceLabel(Long sinceEpoch) {
        if (sinceEpoch == null) {
            return "all";
        }
        long millis = System.currentTimeMillis() - sinceEpoch;
        long minutes = millis / 60000L;
        if (minutes < 60) {
            return minutes + "m";
        }
        long hours = minutes / 60;
        if (hours < 48) {
            return hours + "h";
        }
        long days = hours / 24;
        return days + "d";
    }

    private static String resolveIllegalType(ScanRecord record) {
        if (record == null) {
            return "EXOTIC";
        }
        if (record.illegalType != null && !record.illegalType.isBlank()) {
            return record.illegalType;
        }
        if (SeymourKeys.isSeymourKey(record.armorKey)) {
            return "SEYMOUR";
        }
        return IllegalType.classify(record.colorHex, record.armorKey).name();
    }

    private static Path resolveImportPath(String rawPath) {
        String trimmed = rawPath == null ? "" : rawPath.trim();
        Path path = Path.of(trimmed);
        if (!path.isAbsolute()) {
            path = FabricLoader.getInstance().getConfigDir().resolve(path);
        }
        return path.normalize();
    }

    private static void renderInventoryHighlights(net.minecraft.client.gui.screens.Screen screen, GuiGraphics graphics) {
        if (screen == null || graphics == null || scanner == null || configManager == null) {
            return;
        }
        ExoScannerConfig cfg = configManager.get();
        if (cfg == null || !cfg.enableInventoryHighlight) {
            return;
        }
        if (!(screen instanceof AbstractContainerScreen<?> container)) {
            return;
        }
        AbstractContainerMenu menu = getMenu(container);
        if (menu == null) {
            return;
        }
        List<Slot> slots = getSlots(menu);
        if (slots == null || slots.isEmpty()) {
            return;
        }
        int left = getLeft(container);
        int top = getTop(container);
        Integer screenWidthObj = readIntField(container, net.minecraft.client.gui.screens.Screen.class, "width", "field_22789");
        Integer screenHeightObj = readIntField(container, net.minecraft.client.gui.screens.Screen.class, "height", "field_22790");
        int screenWidth = screenWidthObj == null ? 0 : screenWidthObj;
        int screenHeight = screenHeightObj == null ? 0 : screenHeightObj;
        if (screenWidth <= 0 || screenHeight <= 0) {
            Minecraft client = Minecraft.getInstance();
            if (client != null && client.getWindow() != null) {
                if (screenWidth <= 0) {
                    screenWidth = client.getWindow().getGuiScaledWidth();
                }
                if (screenHeight <= 0) {
                    screenHeight = client.getWindow().getGuiScaledHeight();
                }
            }
        }
        Integer imageWidthObj = readIntField(container, AbstractContainerScreen.class, "imageWidth", "field_2798");
        Integer imageHeightObj = readIntField(container, AbstractContainerScreen.class, "imageHeight", "field_2799");
        int imageWidth = imageWidthObj == null ? 0 : imageWidthObj;
        int imageHeight = imageHeightObj == null ? 0 : imageHeightObj;
        if (imageWidth <= 0) {
            imageWidth = 176;
        }
        if (imageHeight <= 0) {
            imageHeight = 166;
        }
        int[] slotBounds = computeSlotBounds(slots);
        int minX = slotBounds[0];
        int minY = slotBounds[1];
        int maxX = slotBounds[2];
        int maxY = slotBounds[3];
        boolean absoluteCoords =
            minX >= left - 1 && maxX <= left + imageWidth + 1
                && minY >= top - 1 && maxY <= top + imageHeight + 1;
        int offsetX = absoluteCoords ? 0 : left;
        int offsetY = absoluteCoords ? 0 : top;
        InventoryHighlightStyle style = cfg.inventoryHighlightStyle == null
            ? InventoryHighlightStyle.TRANSLUCENT
            : cfg.inventoryHighlightStyle;
        for (Slot slot : slots) {
            if (slot == null) {
                continue;
            }
            ItemStack stack = slot.getItem();
            if (stack == null || stack.isEmpty()) {
                continue;
            }
            ArmorScanner.LiveScanResult result = scanner.evaluateItemStack(stack, "UNKNOWN");
            if (result == null) {
                continue;
            }
            int slotX = getSlotX(slot);
            int slotY = getSlotY(slot);
            int x = slotX + offsetX;
            int y = slotY + offsetY + getScreenYOffset(screen);
            drawSlotHighlight(graphics, x, y, style);
        }
    }

    private static void drawSlotHighlight(GuiGraphics graphics, int x, int y, InventoryHighlightStyle style) {
        int x2 = x + 16;
        int y2 = y + 16;
        int rgb = configManager.get().inventoryHighlightColor & 0xFFFFFF;
        int fill = (0x55 << 24) | rgb;
        int border = (0xFF << 24) | rgb;
        if (style == InventoryHighlightStyle.TRANSLUCENT || style == InventoryHighlightStyle.BOTH) {
            graphics.fill(x, y, x2, y2, fill);
        }
        if (style == InventoryHighlightStyle.BORDER || style == InventoryHighlightStyle.BOTH) {
            graphics.fill(x, y, x2, y + 1, border);
            graphics.fill(x, y2 - 1, x2, y2, border);
            graphics.fill(x, y, x + 1, y2, border);
            graphics.fill(x2 - 1, y, x2, y2, border);
        }
    }

    private static AbstractContainerMenu getMenu(AbstractContainerScreen<?> container) {
        try {
            return container.getMenu();
        } catch (RuntimeException ignored) {
            // fall through
        }
        try {
            var field = AbstractContainerScreen.class.getDeclaredField("menu");
            field.setAccessible(true);
            Object value = field.get(container);
            if (value instanceof AbstractContainerMenu menu) {
                return menu;
            }
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
        return null;
    }

    @SuppressWarnings("unchecked")
    private static List<Slot> getSlots(AbstractContainerMenu menu) {
        for (String fieldName : new String[] { "slots", "field_7761" }) {
            try {
                var field = AbstractContainerMenu.class.getDeclaredField(fieldName);
                field.setAccessible(true);
                Object value = field.get(menu);
                if (value instanceof List<?> list) {
                    return (List<Slot>) list;
                }
            } catch (ReflectiveOperationException ignored) {
                // try next
            }
        }
        try {
            var method = menu.getClass().getMethod("getSlots");
            Object value = method.invoke(menu);
            if (value instanceof List<?> list) {
                return (List<Slot>) list;
            }
        } catch (ReflectiveOperationException ignored) {
            return List.of();
        }
        return List.of();
    }

    private static int getLeft(AbstractContainerScreen<?> container) {
        try {
            var method = container.getClass().getMethod("getGuiLeft");
            Object value = method.invoke(container);
            if (value instanceof Integer i) {
                return i;
            }
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        Integer fromField = readIntField(container, AbstractContainerScreen.class,
            "leftPos", "field_2888", "backgroundLeft", "x");
        if (fromField != null) {
            return fromField;
        }
        return fallbackLeft(container);
    }

    private static int getTop(AbstractContainerScreen<?> container) {
        try {
            var method = container.getClass().getMethod("getGuiTop");
            Object value = method.invoke(container);
            if (value instanceof Integer i) {
                return i;
            }
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        Integer fromField = readIntField(container, AbstractContainerScreen.class,
            "topPos", "field_2890", "backgroundTop", "y");
        if (fromField != null) {
            return fromField;
        }
        return fallbackTop(container);
    }

    private static int getSlotX(Slot slot) {
        Integer value = readIntField(slot, Slot.class, "x", "field_7873");
        return value == null ? 0 : value;
    }

    private static int getSlotY(Slot slot) {
        Integer value = readIntField(slot, Slot.class, "y", "field_7872");
        return value == null ? 0 : value;
    }

    private static Integer readIntField(Object target, Class<?> owner, String... fieldNames) {
        if (target == null || fieldNames == null) {
            return null;
        }
        for (String fieldName : fieldNames) {
            if (fieldName == null || fieldName.isBlank()) {
                continue;
            }
            try {
                var field = owner.getDeclaredField(fieldName);
                field.setAccessible(true);
                Object value = field.get(target);
                if (value instanceof Integer i) {
                    return i;
                }
            } catch (ReflectiveOperationException ignored) {
                // try next
            }
        }
        return null;
    }

    private static int fallbackLeft(AbstractContainerScreen<?> container) {
        Integer width = readIntField(container, net.minecraft.client.gui.screens.Screen.class, "width", "field_22789");
        Integer imageWidth = readIntField(container, AbstractContainerScreen.class, "imageWidth", "field_2798");
        int w = width == null ? 0 : width;
        if (w <= 0) {
            Minecraft client = Minecraft.getInstance();
            if (client != null && client.getWindow() != null) {
                w = client.getWindow().getGuiScaledWidth();
            }
        }
        int iw = imageWidth == null ? 176 : imageWidth;
        return (w - iw) / 2;
    }

    private static int fallbackTop(AbstractContainerScreen<?> container) {
        Integer height = readIntField(container, net.minecraft.client.gui.screens.Screen.class, "height", "field_22790");
        Integer imageHeight = readIntField(container, AbstractContainerScreen.class, "imageHeight", "field_2799");
        int h = height == null ? 0 : height;
        if (h <= 0) {
            Minecraft client = Minecraft.getInstance();
            if (client != null && client.getWindow() != null) {
                h = client.getWindow().getGuiScaledHeight();
            }
        }
        int ih = imageHeight == null ? 166 : imageHeight;
        return (h - ih) / 2;
    }

    private static int[] computeSlotBounds(List<Slot> slots) {
        int minX = Integer.MAX_VALUE;
        int minY = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE;
        int maxY = Integer.MIN_VALUE;
        for (Slot slot : slots) {
            if (slot == null) {
                continue;
            }
            int x = getSlotX(slot);
            int y = getSlotY(slot);
            if (x < minX) {
                minX = x;
            }
            if (y < minY) {
                minY = y;
            }
            if (x > maxX) {
                maxX = x;
            }
            if (y > maxY) {
                maxY = y;
            }
        }
        if (minX == Integer.MAX_VALUE) {
            minX = 0;
            maxX = 0;
        }
        if (minY == Integer.MAX_VALUE) {
            minY = 0;
            maxY = 0;
        }
        return new int[] { minX, minY, maxX, maxY };
    }

    private static int getScreenYOffset(net.minecraft.client.gui.screens.Screen screen) {
        if (screen == null) {
            return 0;
        }
        String title = "";
        try {
            title = screen.getTitle().getString();
        } catch (Exception ignored) {
            // fall through
        }
        if (title != null) {
            String normalized = title.toLowerCase(Locale.ROOT);
            if (normalized.contains("skyblock menu")) {
                return -27;
            }
            if (normalized.contains("co-op auction house")) {
                return 16;
            }
            if (normalized.contains("auctions browser")) {
                return -2;
            }
            if (normalized.contains("wardrobe")) {
                return -27;
            }
            if (normalized.contains("auction")) {
                return -27;
            }
            if (normalized.contains("large chest")) {
                return -27;
            }
            if (normalized.contains("armor stand")) {
                return -27;
            }
            if (normalized.contains("minion")) {
                return -27;
            }
        }
        String className = screen.getClass().getSimpleName().toLowerCase(Locale.ROOT);
        if (className.contains("skyblockmenu")) {
            return -27;
        }
        if (className.contains("auction") && className.contains("coop")) {
            return 16;
        }
        if (className.contains("auction") && className.contains("browser")) {
            return -2;
        }
        if (className.contains("wardrobe")) {
            return -27;
        }
        if (className.contains("auction")) {
            return -27;
        }
        if (className.contains("large") && className.contains("chest")) {
            return -27;
        }
        if (className.contains("armor") && className.contains("stand")) {
            return -27;
        }
        if (className.contains("minion")) {
            return -27;
        }
        return 0;
    }

    // Slot bounds helpers

    private static boolean hasSeymourInExport(Long sinceEpoch, ExportTypeFilter typeFilter, Set<String> armorFilter) {
        boolean[] found = {false};
        forEachExportRecord(sinceEpoch, typeFilter, armorFilter, record -> {
            if (!found[0] && SeymourKeys.isSeymourKey(record == null ? null : record.armorKey)) {
                found[0] = true;
            }
        });
        return found[0];
    }

    private static Integer resolveSeymourTier(ScanRecord record) {
        if (record == null || !SeymourKeys.isSeymourKey(record.armorKey)) {
            return null;
        }
        if (record.seymourTier != null) {
            return record.seymourTier;
        }
        if (record.colorHex == null || record.colorHex.isBlank()) {
            return null;
        }
        SeymourTierService.Settings settings = new SeymourTierService.Settings(76, true, true, true);
        SeymourTierService.SeymourTierResult result =
            SeymourTierService.computeTierForHex(record.colorHex, record.armorKey, settings);
        return result == null ? null : result.tier;
    }

    private static String escapeCsv(String value) {
        if (value == null) {
            return "";
        }
        boolean needsQuotes = value.contains(",") || value.contains("\"") || value.contains("\n");
        String escaped = value.replace("\"", "\"\"");
        return needsQuotes ? "\"" + escaped + "\"" : escaped;
    }

    private static Set<String> parseArmorFilter(String raw) {
        if (raw == null || raw.isBlank()) {
            return Set.of();
        }
        Set<String> out = new LinkedHashSet<>();
        String[] tokens = raw.split(",");
        for (String token : tokens) {
            if (token == null) {
                continue;
            }
            String trimmed = token.trim();
            if (trimmed.isEmpty()) {
                continue;
            }
            out.add(trimmed.toUpperCase(Locale.ROOT));
        }
        return out;
    }

    private static ExportTypeFilter parseExportTypeFilter(String raw) {
        if (raw == null || raw.isBlank()) {
            return new ExportTypeFilter("ANY", Set.of());
        }
        String trimmed = raw.trim();
        if (trimmed.startsWith("!")) {
            String list = trimmed.substring(1);
            Set<String> excluded = parseTypeList(list);
            return new ExportTypeFilter("ANY", excluded);
        }
        return new ExportTypeFilter(trimmed.toUpperCase(Locale.ROOT), Set.of());
    }

    private static Set<String> parseTypeList(String raw) {
        if (raw == null || raw.isBlank()) {
            return Set.of();
        }
        Set<String> out = new LinkedHashSet<>();
        String[] tokens = raw.split(",");
        for (String token : tokens) {
            if (token == null) {
                continue;
            }
            String trimmed = token.trim();
            if (trimmed.isEmpty()) {
                continue;
            }
            out.add(trimmed.toUpperCase(Locale.ROOT));
        }
        return out;
    }

    private static final class ExportTypeFilter {
        private final String includeType;
        private final Set<String> excludedTypes;

        private ExportTypeFilter(String includeType, Set<String> excludedTypes) {
            this.includeType = includeType == null ? "ANY" : includeType;
            this.excludedTypes = excludedTypes == null ? Set.of() : excludedTypes;
        }

        private boolean matches(String resolvedType) {
            if (resolvedType == null || resolvedType.isBlank()) {
                return false;
            }
            String normalized = resolvedType.trim().toUpperCase(Locale.ROOT);
            if (!excludedTypes.isEmpty() && excludedTypes.contains(normalized)) {
                return false;
            }
            if ("ANY".equalsIgnoreCase(includeType)) {
                return true;
            }
            return normalized.equalsIgnoreCase(includeType);
        }
    }

    private static void sendSearchResults(String label, List<ScanRecord> results) {
        sendClientMessage(Component.literal(label + " results: " + results.size()));
        for (ScanRecord record : results) {
            String type = record.illegalType == null ? "EXOTIC" : record.illegalType;
            String head = record.playerName + ", " + record.playerUuid + ", " + record.armorKey + ", ";
            Component seymourTier = null;
            if (SeymourKeys.isSeymourKey(record.armorKey)) {
                int tier = -1;
                if (record.seymourTier != null) {
                    tier = record.seymourTier;
                } else if (record.colorHex != null) {
                    SeymourTierService.Settings settings = new SeymourTierService.Settings(76, true, true, true);
                    SeymourTierService.SeymourTierResult result =
                        SeymourTierService.computeTierForHex(record.colorHex, record.armorKey, settings);
                    if (result != null) {
                        tier = result.tier;
                    }
                }
                if (tier >= 0) {
                    seymourTier = Component.literal(", seymourTier=" + tier);
                }
            }
            Component line = joinComponents(
                Component.literal(head),
                coloredHexComponent(record.colorHex),
                Component.literal(", type=" + type),
                seymourTier
            );
            line = joinComponents(
                line,
                record.matchDistance == null
                    ? null
                    : Component.literal(", distance=" + String.format(Locale.ROOT, "%.2f", record.matchDistance))
            );
            sendClientMessage(line);
        }
    }

    private static void sendRecentSummary(List<ScanRecord> results, String windowLabel) {
        Map<String, Integer> bySet = new java.util.HashMap<>();
        Map<String, Integer> byPiece = new java.util.HashMap<>();
        Map<String, Integer> byType = new java.util.HashMap<>();
        int seymourCount = 0;
        for (ScanRecord record : results) {
            String setKey = record.armorSetKey == null ? "UNKNOWN" : record.armorSetKey;
            String pieceKey = record.armorKey == null ? "UNKNOWN" : record.armorKey;
            bySet.merge(setKey, 1, Integer::sum);
            byPiece.merge(pieceKey, 1, Integer::sum);
            String typeKey = record.illegalType == null ? "EXOTIC" : record.illegalType;
            byType.merge(typeKey, 1, Integer::sum);
            if (SeymourKeys.isSeymourKey(record.armorKey)) {
                seymourCount++;
            }
        }
        if (seymourCount > 0) {
            byType.merge("SEYMOUR", seymourCount, Integer::sum);
        }
        sendClientMessage("ExoScanner: recent records (" + windowLabel + ") = " + results.size());
        if (!bySet.isEmpty()) {
            StringBuilder sets = new StringBuilder();
            for (var entry : bySet.entrySet()) {
                if (sets.length() > 0) {
                    sets.append(", ");
                }
                sets.append(entry.getKey()).append(": ").append(entry.getValue());
            }
            sendClientMessage("By set: " + sets);
        }
        if (!byPiece.isEmpty()) {
            StringBuilder pieces = new StringBuilder();
            for (var entry : byPiece.entrySet()) {
                if (pieces.length() > 0) {
                    pieces.append(", ");
                }
                pieces.append(entry.getKey()).append(": ").append(entry.getValue());
            }
            sendClientMessage("By piece: " + pieces);
        }
        if (!byType.isEmpty()) {
            StringBuilder types = new StringBuilder();
            for (var entry : byType.entrySet()) {
                if (types.length() > 0) {
                    types.append(", ");
                }
                types.append(entry.getKey()).append(": ").append(entry.getValue());
            }
            sendClientMessage("By type: " + types);
        }
    }

    private static void findSeymourSet(String hexInput, Double maxDistance, boolean crossPlayers,
                                       Long sinceEpoch, boolean useCie76) {
        Double resolvedDistance = maxDistance;
        String targetHexInput = hexInput;
        if (resolvedDistance == null && isNumeric(hexInput)) {
            resolvedDistance = parseDoubleSafe(hexInput);
            targetHexInput = null;
        }
        double setDistance = resolvedDistance == null ? 2.0 : resolvedDistance;
        String targetHex = targetHexInput == null ? null : ColorUtils.normalizeHexInput(targetHexInput);
        Integer targetRgb = null;
        if (targetHex != null && !targetHex.isBlank()) {
            try {
                targetRgb = com.notdogshit.exoscanner.util.ColorUtils.parseHex(targetHex);
            } catch (RuntimeException e) {
                sendClientMessage("ExoScanner: invalid hex color " + targetHexInput);
                return;
            }
        }
        List<ScanRecord> records = database.findByArmorKeys(SeymourKeys.KEYS);
        java.util.Map<String, java.util.Map<String, ScanRecord>> byPlayer = new java.util.HashMap<>();
        for (ScanRecord record : records) {
            if (record == null || record.armorKey == null) {
                continue;
            }
            if (sinceEpoch != null && record.timestamp < sinceEpoch) {
                continue;
            }
            String playerKey = record.playerUuid != null ? record.playerUuid.toString()
                : (record.playerName == null ? "UNKNOWN" : record.playerName);
            java.util.Map<String, ScanRecord> pieces = byPlayer.computeIfAbsent(playerKey, k -> new java.util.HashMap<>());
            ScanRecord existing = pieces.get(record.armorKey);
            if (existing == null || record.timestamp > existing.timestamp) {
                pieces.put(record.armorKey, record);
            }
        }

        java.util.List<Component> matches = new java.util.ArrayList<>();
        if (!crossPlayers) {
            for (var entry : byPlayer.entrySet()) {
            java.util.Map<String, ScanRecord> pieces = entry.getValue();
            if (!pieces.keySet().containsAll(SeymourKeys.KEYS)) {
                continue;
            }
            java.util.List<ScanRecord> set = new java.util.ArrayList<>(4);
            for (String key : SeymourKeys.KEYS) {
                ScanRecord record = pieces.get(key);
                if (record == null || record.colorHex == null || record.colorHex.isBlank()) {
                    set.clear();
                    break;
                }
                set.add(record);
            }
            if (set.isEmpty()) {
                continue;
            }

            if (targetRgb != null) {
                boolean ok = true;
                for (ScanRecord record : set) {
                    int rgb = com.notdogshit.exoscanner.util.ColorUtils.parseHex(record.colorHex);
                    double distance = useCie76
                        ? com.notdogshit.exoscanner.util.ColorUtils.cie76(targetRgb, rgb)
                        : com.notdogshit.exoscanner.util.ColorUtils.ciede2000(targetRgb, rgb);
                    if (distance > 5.0) {
                        ok = false;
                        break;
                    }
                }
                if (!ok) {
                    continue;
                }
            }

            boolean close = true;
            for (int i = 0; i < set.size(); i++) {
                int rgb1 = com.notdogshit.exoscanner.util.ColorUtils.parseHex(set.get(i).colorHex);
                for (int j = i + 1; j < set.size(); j++) {
                    int rgb2 = com.notdogshit.exoscanner.util.ColorUtils.parseHex(set.get(j).colorHex);
                    double distance = useCie76
                        ? com.notdogshit.exoscanner.util.ColorUtils.cie76(rgb1, rgb2)
                        : com.notdogshit.exoscanner.util.ColorUtils.ciede2000(rgb1, rgb2);
                    if (distance > setDistance) {
                        close = false;
                        break;
                    }
                }
                if (!close) {
                    break;
                }
            }
            if (!close) {
                continue;
            }

            String playerName = set.get(0).playerName == null ? "UNKNOWN" : set.get(0).playerName;
            addSeymourSetOutput(
                matches,
                "Seymour set - Average Color:",
                pieces.get("VELVET_TOP_HAT"),
                pieces.get("CASHMERE_JACKET"),
                pieces.get("SATIN_TROUSERS"),
                pieces.get("OXFORD_SHOES"),
                playerName
            );
        }
        } else {
            java.util.List<com.notdogshit.exoscanner.db.ExoScanDatabase.SeymourSet> sets =
                database.findSeymourCrossSets(setDistance, targetRgb, 5.0, 10, useCie76);
            for (var set : sets) {
                if (sinceEpoch != null) {
                    if (set.hat.timestamp < sinceEpoch
                        || set.jacket.timestamp < sinceEpoch
                        || set.trousers.timestamp < sinceEpoch
                        || set.shoes.timestamp < sinceEpoch) {
                        continue;
                    }
                }
                addSeymourSetOutput(
                    matches,
                    "Seymour set (cross) - Average Color:",
                    set.hat,
                    set.jacket,
                    set.trousers,
                    set.shoes,
                    null
                );
            }
        }

        String summary = "ExoScanner: Seymour sets found=" + matches.size()
            + " maxDistance=" + String.format(Locale.ROOT, "%.2f", setDistance)
            + (targetHex == null ? "" : " target=" + targetHex + " targetMax=5.00")
            + (sinceEpoch == null ? "" : " since=" + formatSinceLabel(sinceEpoch))
            + " metric=" + (useCie76 ? "76" : "2000")
            + (crossPlayers ? " mode=cross" : "");
        sendClientMessage(summary);
        int limit = Math.min(10, matches.size());
        for (int i = 0; i < limit; i++) {
            sendClientMessage(matches.get(i));
        }
        if (matches.size() > limit) {
            sendClientMessage("ExoScanner: " + (matches.size() - limit) + " more sets not shown.");
        }
    }

    private static String safePlayer(ScanRecord record) {
        if (record.playerName != null && !record.playerName.isBlank()) {
            return record.playerName;
        }
        if (record.playerUuid != null) {
            return record.playerUuid.toString();
        }
        return "UNKNOWN";
    }

    private static boolean isNumeric(String value) {
        if (value == null) {
            return false;
        }
        return value.trim().matches("^[0-9]+(\\.[0-9]+)?$");
    }

    private static Double parseDoubleSafe(String value) {
        try {
            return Double.parseDouble(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static void sendClientMessage(String message) {
        Minecraft client = Minecraft.getInstance();
        if (client != null && client.player != null) {
            client.execute(() -> client.player.displayClientMessage(Component.literal(message), false));
        }
    }

    private static void sendClientMessage(Component message) {
        Minecraft client = Minecraft.getInstance();
        if (client != null && client.player != null) {
            client.execute(() -> client.player.displayClientMessage(message, false));
        }
    }

    public static void notifyOwnerTransfer(String armorKey, String armorUuid, String oldOwner, String newOwner) {
        String key = armorKey == null || armorKey.isBlank() ? "UNKNOWN" : armorKey;
        String uuid = armorUuid == null || armorUuid.isBlank() ? "UNKNOWN" : armorUuid;
        String from = oldOwner == null || oldOwner.isBlank() ? "UNKNOWN" : oldOwner;
        String to = newOwner == null || newOwner.isBlank() ? "UNKNOWN" : newOwner;
        sendClientMessage("ExoScanner: owner update " + key + " uuid=" + uuid + " " + from + " -> " + to);
    }

    private static void addSeymourSetOutput(
        java.util.List<Component> out,
        String header,
        ScanRecord hat,
        ScanRecord jacket,
        ScanRecord trousers,
        ScanRecord shoes,
        String singleOwner
    ) {
        String average = averageColorHex(hat, jacket, trousers, shoes);
        if (average == null) {
            average = "UNKNOWN";
        }
        Component headerLine = joinComponents(
            Component.literal(header + " "),
            coloredHexComponent(average)
        );
        out.add(headerLine);
        out.add(pieceLine(hat, singleOwner));
        out.add(pieceLine(jacket, singleOwner));
        out.add(pieceLine(trousers, singleOwner));
        out.add(pieceLine(shoes, singleOwner));
    }

    private static Component pieceLine(ScanRecord record, String singleOwner) {
        String owner = singleOwner == null ? safePlayer(record) : singleOwner;
        String armorId = record == null || record.armorKey == null ? "UNKNOWN" : record.armorKey;
        Component base = Component.literal("Owner:" + owner + " " + armorId + " ");
        return joinComponents(base, coloredHexComponent(record == null ? null : record.colorHex));
    }

    private static Component coloredHexComponent(String hex) {
        String safe = hex == null ? "UNKNOWN" : hex;
        if (safe.startsWith("#") && safe.length() == 7) {
            try {
                int rgb = Integer.parseInt(safe.substring(1), 16);
                return Component.literal(safe).withStyle(style -> style.withColor(TextColor.fromRgb(rgb)));
            } catch (NumberFormatException ignored) {
                return Component.literal(safe);
            }
        }
        return Component.literal(safe);
    }

    private static Component joinComponents(Component first, Component second, Component third, Component fourth) {
        Component result = first;
        if (second != null) {
            result = result.copy().append(second);
        }
        if (third != null) {
            result = result.copy().append(third);
        }
        if (fourth != null) {
            result = result.copy().append(fourth);
        }
        return result;
    }

    private static Component joinComponents(Component first, Component second) {
        return joinComponents(first, second, null, null);
    }

    private static String averageColorHex(ScanRecord hat, ScanRecord jacket, ScanRecord trousers, ScanRecord shoes) {
        int[][] rgbs = new int[][] {
            parseRgbSafe(hat),
            parseRgbSafe(jacket),
            parseRgbSafe(trousers),
            parseRgbSafe(shoes)
        };
        int count = 0;
        int sumR = 0;
        int sumG = 0;
        int sumB = 0;
        for (int[] rgb : rgbs) {
            if (rgb == null) {
                continue;
            }
            sumR += rgb[0];
            sumG += rgb[1];
            sumB += rgb[2];
            count++;
        }
        if (count == 0) {
            return null;
        }
        int r = sumR / count;
        int g = sumG / count;
        int b = sumB / count;
        return String.format("#%02X%02X%02X", r, g, b);
    }

    private static int[] parseRgbSafe(ScanRecord record) {
        if (record == null || record.colorHex == null || record.colorHex.length() != 7) {
            return null;
        }
        String hex = record.colorHex;
        if (!hex.startsWith("#")) {
            return null;
        }
        try {
            int value = Integer.parseInt(hex.substring(1), 16);
            return new int[] { (value >> 16) & 0xFF, (value >> 8) & 0xFF, value & 0xFF };
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static List<PlayerIdentity> getLobbyPlayerIdentities(Minecraft client) {
        Map<UUID, PlayerIdentity> players = new java.util.HashMap<>();
        boolean usedConnection = false;
        if (client.getConnection() != null) {
            usedConnection = true;
            for (var info : client.getConnection().getOnlinePlayers()) {
                if (!isListed(info)) {
                    continue;
                }
                Object profile = info.getProfile();
                UUID uuid = extractProfileId(profile);
                if (uuid != null) {
                    String name = extractProfileName(profile);
                    if (isValidUsername(name)) {
                        players.putIfAbsent(uuid, new PlayerIdentity(uuid, name));
                    } else if (configManager.get().debugLobbyScan) {
                        LOGGER.info("Lobby scan skip invalid name: raw={}", name);
                    }
                }
            }
        }
        if (!usedConnection && client.level != null) {
            for (Player player : client.level.players()) {
                UUID uuid = player.getUUID();
                if (uuid != null) {
                    String name = player.getName().getString();
                    if (isValidUsername(name)) {
                        players.putIfAbsent(uuid, new PlayerIdentity(uuid, name));
                    } else if (configManager.get().debugLobbyScan) {
                        LOGGER.info("Lobby scan skip invalid name: raw={}", name);
                    }
                }
            }
        }
        return new ArrayList<>(players.values());
    }

    private static boolean isListed(Object playerInfo) {
        if (playerInfo == null) {
            return false;
        }
        try {
            Object value = playerInfo.getClass().getMethod("isListed").invoke(playerInfo);
            if (value instanceof Boolean b) {
                return b;
            }
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        try {
            Object value = playerInfo.getClass().getMethod("listed").invoke(playerInfo);
            if (value instanceof Boolean b) {
                return b;
            }
        } catch (ReflectiveOperationException ignored) {
            return true;
        }
        return true;
    }

    private static boolean isValidUsername(String rawName) {
        if (rawName == null || rawName.isBlank()) {
            return false;
        }
        String name = stripFormatting(rawName).trim();
        if (name.isEmpty()) {
            return false;
        }
        return name.matches("^[A-Za-z0-9_]{1,16}$");
    }

    private static int scanIslandDisplays(Minecraft client, String islandOwner) {
        if (client == null || client.level == null) {
            return 0;
        }
        int scanned = 0;
        boolean debug = configManager.get().debugArmorScan;
        String ownerName = islandOwner == null || islandOwner.isBlank() ? "PRIVATE_ISLAND" : islandOwner;
        int armorStands = 0;
        int itemFrames = 0;
        int handSlots = 0;
        int loggedEntities = 0;
        List<Entity> entities = displayTracker.snapshot(client.level);
        for (Entity entity : entities) {
            if (debug && loggedEntities < 10) {
                String typeName = String.valueOf(entity.getType());
                LOGGER.info("Island display[{}]: class={}, type={}", loggedEntities, entity.getClass().getName(), typeName);
                loggedEntities++;
            }
            if (entity instanceof ArmorStand stand) {
                armorStands++;
                for (EquipmentSlot slot : new EquipmentSlot[]{
                    EquipmentSlot.HEAD,
                    EquipmentSlot.CHEST,
                    EquipmentSlot.LEGS,
                    EquipmentSlot.FEET
                }) {
                    ItemStack stack = stand.getItemBySlot(slot);
                    if (stack.isEmpty()) {
                        continue;
                    }
                    scanned++;
                    scanner.scanItemStack(ownerName, null, stack, toPieceType(slot), "armor_stand");
                }
                ItemStack mainHand = stand.getItemBySlot(EquipmentSlot.MAINHAND);
                if (!mainHand.isEmpty()) {
                    scanned++;
                    handSlots++;
                    scanner.scanItemStack(ownerName, null, mainHand, "UNKNOWN", "armor_stand_hand");
                }
                ItemStack offHand = stand.getItemBySlot(EquipmentSlot.OFFHAND);
                if (!offHand.isEmpty()) {
                    scanned++;
                    handSlots++;
                    scanner.scanItemStack(ownerName, null, offHand, "UNKNOWN", "armor_stand_hand");
                }
            } else if (entity instanceof ItemFrame frame) {
                itemFrames++;
                ItemStack stack = frame.getItem();
                if (stack.isEmpty()) {
                    continue;
                }
                scanned++;
                scanner.scanItemStack(ownerName, null, stack, "UNKNOWN", "item_frame");
            }
        }
        if (debug) {
            LOGGER.info(
                "Private island scan complete. owner={}, trackedDisplays={}, armorStands={}, itemFrames={}, handSlots={}, scannedItemStacks={}",
                ownerName,
                entities.size(),
                armorStands,
                itemFrames,
                handSlots,
                scanned
            );
        }
        return scanned;
    }


    private static String toPieceType(EquipmentSlot slot) {
        return switch (slot) {
            case HEAD -> "HELMET";
            case CHEST -> "CHESTPLATE";
            case LEGS -> "LEGGINGS";
            case FEET -> "BOOTS";
            default -> "UNKNOWN";
        };
    }

    private static String stripFormatting(String text) {
        if (text == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(text.length());
        boolean skipNext = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (skipNext) {
                skipNext = false;
                continue;
            }
            if (c == '\u00A7') {
                skipNext = true;
                continue;
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private static boolean isValidApiKey(String key) {
        return ConfigManager.normalizeApiKey(key) != null;
    }

    private static final class PlayerIdentity {
        private final UUID uuid;
        private final String name;

        private PlayerIdentity(UUID uuid, String name) {
            this.uuid = uuid;
            this.name = name == null ? uuid.toString() : name;
        }
    }

    private static UUID extractProfileId(Object profile) {
        if (profile == null) {
            return null;
        }
        try {
            Object value = profile.getClass().getMethod("getId").invoke(profile);
            if (value instanceof UUID uuid) {
                return uuid;
            }
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        try {
            Object value = profile.getClass().getMethod("id").invoke(profile);
            if (value instanceof UUID uuid) {
                return uuid;
            }
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        try {
            var field = profile.getClass().getDeclaredField("id");
            field.setAccessible(true);
            Object value = field.get(profile);
            if (value instanceof UUID uuid) {
                return uuid;
            }
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
        return null;
    }

    private static String extractProfileName(Object profile) {
        if (profile == null) {
            return null;
        }
        try {
            Object value = profile.getClass().getMethod("getName").invoke(profile);
            return value == null ? null : value.toString();
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        try {
            Object value = profile.getClass().getMethod("name").invoke(profile);
            return value == null ? null : value.toString();
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        try {
            var field = profile.getClass().getDeclaredField("name");
            field.setAccessible(true);
            Object value = field.get(profile);
            return value == null ? null : value.toString();
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    private static String normalizeHex(String value) {
        return com.notdogshit.exoscanner.util.ColorUtils.normalizeHexInput(value);
    }
}

