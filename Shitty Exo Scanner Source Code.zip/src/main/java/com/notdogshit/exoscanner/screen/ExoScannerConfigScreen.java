package com.notdogshit.exoscanner.screen;

import com.notdogshit.exoscanner.config.ConfigManager;
import com.notdogshit.exoscanner.config.ExoScannerConfig;
import com.notdogshit.exoscanner.config.InventoryHighlightStyle;
import com.notdogshit.exoscanner.whitelist.WhitelistManager;
import me.shedaniel.clothconfig2.api.ConfigBuilder;
import me.shedaniel.clothconfig2.api.ConfigCategory;
import me.shedaniel.clothconfig2.api.ConfigEntryBuilder;
import me.shedaniel.clothconfig2.gui.entries.StringListListEntry;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;

public final class ExoScannerConfigScreen {
    // Cloth-config UI for ExoScanner settings.
    private static String lastHelpQuery = "";
    private static final List<HelpEntry> HELP_ENTRIES = buildHelpEntries();

    private ExoScannerConfigScreen() {
    }

    public static Screen create(ConfigManager configManager, WhitelistManager whitelistManager, Screen parent) {
        // Build the config screen with grouped categories and save hooks.
        ExoScannerConfig config = configManager.get();
        ConfigBuilder builder = ConfigBuilder.create()
            .setParentScreen(parent)
            .setTitle(Component.literal("ExoScanner Settings"));

        ConfigEntryBuilder entryBuilder = builder.entryBuilder();

        ConfigCategory general = builder.getOrCreateCategory(Component.literal("General"));
        general.addEntry(entryBuilder.startBooleanToggle(
                Component.literal("Enable Scanning"),
                config.enableScanning)
            .setDefaultValue(true)
            .setTooltip(Component.literal("Enable local armor scanning."))
            .setSaveConsumer(configManager::setScanningEnabled)
            .build());

        general.addEntry(entryBuilder.startBooleanToggle(
                Component.literal("Notify on Exotic"),
                config.notifyOnExotic)
            .setDefaultValue(false)
            .setTooltip(Component.literal("Show chat notifications when an exotic is found."))
            .setSaveConsumer(configManager::setNotifyOnExotic)
            .build());
        general.addEntry(entryBuilder.startBooleanToggle(
                Component.literal("Notify on Owner Transfer"),
                config.notifyOnOwnerTransfer)
            .setDefaultValue(false)
            .setTooltip(Component.literal("Notify when a scanned piece is found on a different player."))
            .setSaveConsumer(configManager::setNotifyOnOwnerTransfer)
            .build());

        general.addEntry(entryBuilder.startIntField(
                Component.literal("Scan Interval (seconds)"),
                config.scanInterval)
            .setDefaultValue(5)
            .setMin(1)
            .setMax(600)
            .setTooltip(Component.literal("Seconds between automatic scans."))
            .setSaveConsumer(configManager::setScanIntervalSeconds)
            .build());

        general.addEntry(entryBuilder.startIntField(
                Component.literal("Lobby Cache Days"),
                config.lobbyCacheDays)
            .setDefaultValue(30)
            .setMin(0)
            .setMax(365)
            .setTooltip(Component.literal("Days to keep lobby scan cache."))
            .setSaveConsumer(configManager::setLobbyCacheDays)
            .build());

        general.addEntry(entryBuilder.startBooleanToggle(
                Component.literal("Enable Player Cache"),
                config.enablePlayerCache)
            .setDefaultValue(true)
            .setTooltip(Component.literal("Skip players already scanned recently."))
            .setSaveConsumer(configManager::setPlayerCacheEnabled)
            .build());

        ConfigCategory highlights = builder.getOrCreateCategory(Component.literal("Inventory Highlight"));
        highlights.addEntry(entryBuilder.startBooleanToggle(
                Component.literal("Enable Inventory Highlight"),
                config.enableInventoryHighlight)
            .setDefaultValue(true)
            .setTooltip(Component.literal("Highlight illegal pieces in inventory screens."))
            .setSaveConsumer(configManager::setInventoryHighlightEnabled)
            .build());
        highlights.addEntry(entryBuilder.startEnumSelector(
                Component.literal("Highlight Style"),
                InventoryHighlightStyle.class,
                config.inventoryHighlightStyle)
            .setDefaultValue(InventoryHighlightStyle.TRANSLUCENT)
            .setTooltip(Component.literal("Translucent, Border, or Both."))
            .setSaveConsumer(configManager::setInventoryHighlightStyle)
            .build());
        highlights.addEntry(entryBuilder.startColorField(
                Component.literal("Highlight Color"),
                config.inventoryHighlightColor)
            .setDefaultValue(0xFF5555)
            .setAlphaMode(false)
            .setTooltip(Component.literal("RGB color used for inventory highlight."))
            .setSaveConsumer(configManager::setInventoryHighlightColor)
            .build());

        ConfigCategory armor = builder.getOrCreateCategory(Component.literal("Armor Filters"));
        Set<String> enabledPieces = config.enabledPieceTypes == null ? Set.of() : config.enabledPieceTypes;
        boolean helmet = enabledPieces.isEmpty() || enabledPieces.contains("HELMET");
        boolean chest = enabledPieces.isEmpty() || enabledPieces.contains("CHESTPLATE");
        boolean legs = enabledPieces.isEmpty() || enabledPieces.contains("LEGGINGS");
        boolean boots = enabledPieces.isEmpty() || enabledPieces.contains("BOOTS");

        armor.addEntry(entryBuilder.startBooleanToggle(Component.literal("Helmet"), helmet)
            .setDefaultValue(true)
            .setSaveConsumer(value -> setPieceEnabled(configManager, "HELMET", value))
            .build());
        armor.addEntry(entryBuilder.startBooleanToggle(Component.literal("Chestplate"), chest)
            .setDefaultValue(true)
            .setSaveConsumer(value -> setPieceEnabled(configManager, "CHESTPLATE", value))
            .build());
        armor.addEntry(entryBuilder.startBooleanToggle(Component.literal("Leggings"), legs)
            .setDefaultValue(true)
            .setSaveConsumer(value -> setPieceEnabled(configManager, "LEGGINGS", value))
            .build());
        armor.addEntry(entryBuilder.startBooleanToggle(Component.literal("Boots"), boots)
            .setDefaultValue(true)
            .setSaveConsumer(value -> setPieceEnabled(configManager, "BOOTS", value))
            .build());

        List<String> armorSets = new ArrayList<>(config.enabledArmorSets == null ? List.of() : config.enabledArmorSets);
        armor.addEntry(entryBuilder.startTextDescription(Component.literal("Click + to add rows. Leave empty to allow all.")).build());
        armor.addEntry(entryBuilder.startStrList(
                Component.literal("Enabled Armor Sets"),
                armorSets)
            .setInsertButtonEnabled(true)
            .setDeleteButtonEnabled(true)
            .setInsertInFront(true)
            .setAddButtonTooltip(Component.literal("Add armor set"))
            .setRemoveButtonTooltip(Component.literal("Remove armor set"))
            .setExpanded(true)
            .setTooltip(Component.literal("Only scan these armor sets. Leave empty to allow all."))
            .setSaveConsumer(value -> configManager.setEnabledArmorSets(parseUpperSet(value)))
            .build());

        ConfigCategory tracking = builder.getOrCreateCategory(Component.literal("Player Tracking"));
        tracking.addEntry(entryBuilder.startBooleanToggle(
                Component.literal("Enable Player Tracking"),
                config.enablePlayerTracking)
            .setDefaultValue(false)
            .setTooltip(Component.literal("Allow /exo trace to draw a tracer to a selected player."))
            .setSaveConsumer(configManager::setPlayerTrackingEnabled)
            .build());
        tracking.addEntry(entryBuilder.startDoubleField(
                Component.literal("Tracer Line Width"),
                config.tracerLineWidth)
            .setDefaultValue(2.0)
            .setMin(0.5)
            .setMax(8.0)
            .setTooltip(Component.literal("Line width for the tracer (may be limited by GPU)."))
            .setSaveConsumer(configManager::setTracerLineWidth)
            .build());
        tracking.addEntry(entryBuilder.startColorField(
                Component.literal("Tracer Line Color"),
                config.tracerLineColor)
            .setDefaultValue(0xFF3333)
            .setAlphaMode(false)
            .setTooltip(Component.literal("RGB color used for the tracer line."))
            .setSaveConsumer(configManager::setTracerLineColor)
            .build());
        tracking.addEntry(entryBuilder.startDoubleField(
                Component.literal("Trace Auto-Disable Radius"),
                config.tracerAutoDisableRadius)
            .setDefaultValue(5.0)
            .setMin(0.5)
            .setMax(50.0)
            .setTooltip(Component.literal("Disable manual trace when within this many blocks."))
            .setSaveConsumer(configManager::setTracerAutoDisableRadius)
            .build());
        tracking.addEntry(entryBuilder.startDoubleField(
                Component.literal("Tracer Line Offset"),
                config.tracerLineOffset)
            .setDefaultValue(0.1)
            .setMin(0.0)
            .setMax(1.0)
            .setTooltip(Component.literal("Vertical offset below eye level for the tracer line."))
            .setSaveConsumer(configManager::setTracerLineOffset)
            .build());
        tracking.addEntry(entryBuilder.startBooleanToggle(
                Component.literal("Enable Auto Trace"),
                config.enableAutoTrace)
            .setDefaultValue(false)
            .setTooltip(Component.literal("Automatically trace players from the list when found in a lobby."))
            .setSaveConsumer(configManager::setAutoTraceEnabled)
            .build());
        tracking.addEntry(entryBuilder.startIntField(
                Component.literal("Auto Trace Max Targets"),
                config.autoTraceMaxTargets)
            .setDefaultValue(3)
            .setMin(1)
            .setMax(5)
            .setTooltip(Component.literal("Maximum number of auto-trace targets to draw."))
            .setSaveConsumer(configManager::setAutoTraceMaxTargets)
            .build());
        List<String> autoTracePlayers = new ArrayList<>(config.autoTracePlayers == null ? List.of() : config.autoTracePlayers);
        tracking.addEntry(entryBuilder.startTextDescription(Component.literal("Auto Trace Players:")).build());
        tracking.addEntry(entryBuilder.startStrList(
                Component.literal("Auto Trace List"),
                autoTracePlayers)
            .setInsertButtonEnabled(true)
            .setDeleteButtonEnabled(true)
            .setInsertInFront(true)
            .setAddButtonTooltip(Component.literal("Add player"))
            .setRemoveButtonTooltip(Component.literal("Remove player"))
            .setExpanded(true)
            .setTooltip(Component.literal("Usernames to auto-trace when found in the lobby."))
            .setSaveConsumer(configManager::setAutoTracePlayers)
            .build());

        ConfigCategory auto = builder.getOrCreateCategory(Component.literal("Auto Lobby Scan"));
        auto.addEntry(entryBuilder.startBooleanToggle(
                Component.literal("Enable Auto Lobby Scan"),
                config.enableAutoLobbyScan)
            .setDefaultValue(false)
            .setSaveConsumer(value -> {
                config.enableAutoLobbyScan = value;
            })
            .build());
        auto.addEntry(entryBuilder.startBooleanToggle(
                Component.literal("Scan On Lobby Switch"),
                config.autoScanOnLobbySwitch)
            .setDefaultValue(true)
            .setSaveConsumer(value -> {
                config.autoScanOnLobbySwitch = value;
            })
            .build());
        auto.addEntry(entryBuilder.startBooleanToggle(
                Component.literal("Scan Every 5 Minutes"),
                config.autoScanEvery5Minutes)
            .setDefaultValue(false)
            .setSaveConsumer(value -> {
                config.autoScanEvery5Minutes = value;
            })
            .build());

        ConfigCategory limits = builder.getOrCreateCategory(Component.literal("Auto Scan Limits"));
        limits.addEntry(entryBuilder.startIntField(
                Component.literal("Debounce Seconds"),
                config.autoScanDebounceSeconds)
            .setDefaultValue(6)
            .setMin(3)
            .setMax(12)
            .setSaveConsumer(value -> config.autoScanDebounceSeconds = value)
            .build());
        limits.addEntry(entryBuilder.startIntField(
                Component.literal("Min Gap Seconds"),
                config.autoScanMinGapSeconds)
            .setDefaultValue(75)
            .setMin(10)
            .setMax(300)
            .setSaveConsumer(value -> config.autoScanMinGapSeconds = value)
            .build());
        limits.addEntry(entryBuilder.startIntField(
                Component.literal("Jitter Millis"),
                config.autoScanJitterMillis)
            .setDefaultValue(750)
            .setMin(0)
            .setMax(5000)
            .setSaveConsumer(value -> config.autoScanJitterMillis = value)
            .build());
        limits.addEntry(entryBuilder.startIntField(
                Component.literal("Max Requests Per Scan"),
                config.autoScanMaxRequestsPerScan)
            .setDefaultValue(300)
            .setMin(50)
            .setMax(1000)
            .setSaveConsumer(value -> config.autoScanMaxRequestsPerScan = value)
            .build());
        limits.addEntry(entryBuilder.startIntField(
                Component.literal("Max Players Per Scan"),
                config.autoScanMaxPlayersPerScan)
            .setDefaultValue(200)
            .setMin(10)
            .setMax(500)
            .setSaveConsumer(value -> config.autoScanMaxPlayersPerScan = value)
            .build());
        limits.addEntry(entryBuilder.startIntField(
                Component.literal("Burst Threshold (5m)"),
                config.keyBurstThreshold)
            .setDefaultValue(300)
            .setMin(50)
            .setMax(1000)
            .setSaveConsumer(value -> config.keyBurstThreshold = value)
            .build());
        limits.addEntry(entryBuilder.startIntField(
                Component.literal("Daily Cap (24h)"),
                config.keyDailyCap)
            .setDefaultValue(5000)
            .setMin(1000)
            .setMax(10000)
            .setSaveConsumer(value -> config.keyDailyCap = value)
            .build());
        limits.addEntry(entryBuilder.startIntField(
                Component.literal("Burst Window (minutes)"),
                config.keyBurstWindowMinutes)
            .setDefaultValue(5)
            .setMin(1)
            .setMax(60)
            .setSaveConsumer(value -> config.keyBurstWindowMinutes = value)
            .build());
        limits.addEntry(entryBuilder.startIntField(
                Component.literal("Cooldown Minutes"),
                config.keyCooldownMinutes)
            .setDefaultValue(10)
            .setMin(1)
            .setMax(60)
            .setSaveConsumer(value -> config.keyCooldownMinutes = value)
            .build());
        limits.addEntry(entryBuilder.startIntField(
                Component.literal("Auto Pause Minutes"),
                config.autoPauseMinutesOnAllKeysExhausted)
            .setDefaultValue(30)
            .setMin(1)
            .setMax(120)
            .setSaveConsumer(value -> config.autoPauseMinutesOnAllKeysExhausted = value)
            .build());

        ConfigCategory api = builder.getOrCreateCategory(Component.literal("API Keys"));
        api.addEntry(entryBuilder.startStrField(Component.literal("API Key Slot 1"), safeKey(config, 0))
            .setDefaultValue("")
            .setSaveConsumer(value -> setApiKey(config, 0, value))
            .build());
        api.addEntry(entryBuilder.startStrField(Component.literal("API Key Slot 2"), safeKey(config, 1))
            .setDefaultValue("")
            .setSaveConsumer(value -> setApiKey(config, 1, value))
            .build());
        api.addEntry(entryBuilder.startStrField(Component.literal("API Key Slot 3"), safeKey(config, 2))
            .setDefaultValue("")
            .setSaveConsumer(value -> setApiKey(config, 2, value))
            .build());

        ConfigCategory debug = builder.getOrCreateCategory(Component.literal("Debug"));
        debug.addEntry(entryBuilder.startBooleanToggle(Component.literal("Armor Scan Logs"), config.debugArmorScan)
            .setDefaultValue(false)
            .setSaveConsumer(configManager::setDebugArmorScan)
            .build());
        debug.addEntry(entryBuilder.startBooleanToggle(Component.literal("API Scan Logs"), config.debugApiScan)
            .setDefaultValue(false)
            .setSaveConsumer(configManager::setDebugApiScan)
            .build());
        debug.addEntry(entryBuilder.startBooleanToggle(Component.literal("Auto Lobby Logs"), config.debugLobbyScan)
            .setDefaultValue(false)
            .setSaveConsumer(configManager::setDebugLobbyScan)
            .build());
        debug.addEntry(entryBuilder.startBooleanToggle(Component.literal("Trace Logs"), config.debugTrace)
            .setDefaultValue(false)
            .setSaveConsumer(configManager::setDebugTrace)
            .build());
        debug.addEntry(entryBuilder.startBooleanToggle(
                Component.literal("Notify Missing Armor UUID"),
                config.notifyOnMissingArmorUuid)
            .setDefaultValue(false)
            .setTooltip(Component.literal("Chat message when an illegal piece has no armor UUID."))
            .setSaveConsumer(configManager::setNotifyOnMissingArmorUuid)
            .build());
        debug.addEntry(entryBuilder.startBooleanToggle(Component.literal("Scan All Leather (Debug)"), config.debugScanAllLeather)
            .setDefaultValue(false)
            .setSaveConsumer(configManager::setDebugScanAllLeather)
            .build());

        ConfigCategory tools = builder.getOrCreateCategory(Component.literal("Tools"));
        tools.addEntry(entryBuilder.startTextDescription(Component.literal("Whitelist reloads when you save/close this screen.")).build());

        ConfigCategory help = builder.getOrCreateCategory(Component.literal("Help"));
        help.addEntry(entryBuilder.startTextDescription(Component.literal("Search: type a keyword and hover the field to see matches.")).build());
        help.addEntry(entryBuilder.startTextField(Component.literal("Help Search"), lastHelpQuery)
            .setDefaultValue("")
            .setTooltipSupplier(value -> Optional.of(buildHelpTooltip(value)))
            .setSaveConsumer(value -> lastHelpQuery = value == null ? "" : value.trim())
            .build());
        help.addEntry(entryBuilder.startTextDescription(Component.literal("Help Index:")).build());
        for (HelpEntry entry : HELP_ENTRIES) {
            help.addEntry(entryBuilder.startTextDescription(Component.literal(formatHelpEntry(entry))).build());
        }

        builder.setSavingRunnable(() -> {
            configManager.save();
            whitelistManager.reload();
        });
        return builder.build();
    }

    private static void setPieceEnabled(ConfigManager configManager, String piece, boolean enabled) {
        ExoScannerConfig config = configManager.get();
        Set<String> pieces = config.enabledPieceTypes == null ? new java.util.HashSet<>() : new java.util.HashSet<>(config.enabledPieceTypes);
        if (enabled) {
            pieces.add(piece);
        } else {
            pieces.remove(piece);
        }
        if (pieces.size() == 4) {
            pieces.clear();
        }
        configManager.setEnabledPieceTypes(pieces);
    }

    private static Set<String> parseUpperSet(List<String> values) {
        Set<String> out = new java.util.HashSet<>();
        if (values == null) {
            return out;
        }
        for (String value : values) {
            if (value == null) {
                continue;
            }
            String trimmed = value.trim();
            if (trimmed.isEmpty()) {
                continue;
            }
            if ("SET_NAME".equalsIgnoreCase(trimmed)) {
                continue;
            }
            out.add(trimmed.toUpperCase(Locale.ROOT));
        }
        return out;
    }

    private static String safeKey(ExoScannerConfig config, int index) {
        if (config.apiKeys == null || index < 0 || index >= config.apiKeys.length) {
            return "";
        }
        return config.apiKeys[index] == null ? "" : config.apiKeys[index];
    }

    private static void setApiKey(ExoScannerConfig config, int index, String raw) {
        if (config.apiKeys == null || config.apiKeys.length < 3) {
            config.apiKeys = new String[] {"", "", ""};
        }
        String normalized = ConfigManager.normalizeApiKey(raw == null ? "" : raw.trim());
        if (normalized == null) {
            normalized = "";
        }
        config.apiKeys[index] = normalized;
        config.apiKey = config.apiKeys[0];
    }

    private static String formatHelpEntry(HelpEntry entry) {
        return entry.title + " - " + entry.description;
    }

    private static Component[] buildHelpTooltip(String query) {
        String needle = query == null ? "" : query.trim().toLowerCase(Locale.ROOT);
        List<Component> lines = new ArrayList<>();
        if (needle.isEmpty()) {
            lines.add(Component.literal("Type to search commands or settings."));
            lines.add(Component.literal("Examples: scan, seymour, cache, export, api."));
            return lines.toArray(new Component[0]);
        }
        int matches = 0;
        for (HelpEntry entry : HELP_ENTRIES) {
            String haystack = (entry.title + " " + entry.description).toLowerCase(Locale.ROOT);
            if (haystack.contains(needle)) {
                lines.add(Component.literal(formatHelpEntry(entry)));
                matches++;
                if (matches >= 12) {
                    break;
                }
            }
        }
        if (matches == 0) {
            lines.add(Component.literal("No matches."));
        }
        return lines.toArray(new Component[0]);
    }

    // Static help content displayed in the Help tab.
    private static List<HelpEntry> buildHelpEntries() {
        List<HelpEntry> entries = new ArrayList<>();
        entries.add(new HelpEntry("Section: Commands", "Main chat commands. See /exo help for short form."));
        entries.add(new HelpEntry("Command: /exo scan near", "Scan nearby players now."));
        entries.add(new HelpEntry("Command: /exo scan island [owner]", "Scan armor stands and item frames on a private island."));
        entries.add(new HelpEntry("Command: /exo scan api <username>", "Scan a single player via Hypixel API."));
        entries.add(new HelpEntry("Command: /exo scan api lobby [force]", "Scan lobby players via Hypixel API. Use force to ignore cache."));
        entries.add(new HelpEntry("Command: /exo search player <username>", "Search the local database by player name."));
        entries.add(new HelpEntry("Command: /exo search <armor|ANY> <color>", "Search by armor key or set plus color, with optional dE and since."));
        entries.add(new HelpEntry("Command: /exo trace <player>", "Draw a tracer to a selected player (client-side)."));
        entries.add(new HelpEntry("Command: /exo seymour pieces", "Find Seymour piece matches by tier or fade settings."));
        entries.add(new HelpEntry("Command: /exo seymour sets", "Find Seymour sets with distance and color filters."));
        entries.add(new HelpEntry("Command: /exo db stats", "Show database totals by type."));
        entries.add(new HelpEntry("Command: /exo db recent [since=<time>]", "List recent database entries within a time window."));
        entries.add(new HelpEntry("Command: /exo db rollback [since=<time>]", "Remove database entries created within the specified time window (default 5m)."));
        entries.add(new HelpEntry("Command: /exo db update", "Recompute illegal types and Seymour tiers for the database."));
        entries.add(new HelpEntry("Command: /exo db import <path>", "Merge another database file or folder into this one."));
        entries.add(new HelpEntry("Command: /exo db count <armorId> <type>", "Count records by armor id or set and type."));
        entries.add(new HelpEntry("Command: /exo export csv|xlsx", "Export the database with optional filters."));
        entries.add(new HelpEntry("Type: glitched", "Wither armor pieces dyed to another wither set color."));
        entries.add(new HelpEntry("Command: /exo api status", "Show API key usage and auto scan status."));
        entries.add(new HelpEntry("Command: /exo config", "Open this settings screen."));
        entries.add(new HelpEntry("Command: /exo whitelist reload", "Reload the whitelist from disk."));
        entries.add(new HelpEntry("Command: /exo debug log <armor|api|lobby|all>", "Toggle debug logging per feature."));
        entries.add(new HelpEntry("Command: /exo debug scanall", "Debug-only: scan all leather items."));
        entries.add(new HelpEntry("Command: /exo debug displays", "Show tracked armor stands and item frames."));

        entries.add(new HelpEntry("Section: General Settings", "Core behavior controls."));
        entries.add(new HelpEntry("Setting: Enable Scanning", "Master toggle for armor scanning."));
        entries.add(new HelpEntry("Setting: Notify On Exotic", "Show chat notifications when an exotic is found."));
        entries.add(new HelpEntry("Setting: Notify On Owner Transfer", "Notify when an already scanned piece is found on a different player."));
        entries.add(new HelpEntry("Setting: Scan Interval (seconds)", "Delay between automatic scans."));
        entries.add(new HelpEntry("Setting: Lobby Cache Days", "How long to keep lobby scan cache entries."));
        entries.add(new HelpEntry("Setting: Enable Player Cache", "Skip players recently scanned if enabled."));
        entries.add(new HelpEntry("Setting: Enable Inventory Highlight", "Highlight illegal pieces in inventory screens."));
        entries.add(new HelpEntry("Setting: Highlight Style", "Choose Translucent, Border, or Both."));
        entries.add(new HelpEntry("Setting: Highlight Color", "RGB color used for inventory highlight."));

        entries.add(new HelpEntry("Section: Armor Filters", "Which pieces or sets are scanned."));
        entries.add(new HelpEntry("Setting: Helmet/Chestplate/Leggings/Boots", "Enable or disable each armor piece type."));
        entries.add(new HelpEntry("Setting: Enabled Armor Sets", "Only scan the listed armor sets (empty means all)."));

        entries.add(new HelpEntry("Section: Player Tracking", "Client-side tracer to a selected player."));
        entries.add(new HelpEntry("Setting: Enable Player Tracking", "Allow /exo trace to draw a tracer line."));
        entries.add(new HelpEntry("Setting: Tracer Line Width", "Adjust the width of the tracer line."));
        entries.add(new HelpEntry("Setting: Tracer Line Color", "Adjust the color of the tracer line."));
        entries.add(new HelpEntry("Setting: Trace Auto-Disable Radius", "Disable manual trace within this distance."));
        entries.add(new HelpEntry("Setting: Tracer Line Offset", "Vertical offset below eye level for the tracer line."));
        entries.add(new HelpEntry("Setting: Enable Auto Trace", "Automatically trace players from a configured list."));
        entries.add(new HelpEntry("Setting: Auto Trace Max Targets", "Maximum auto-trace lines to draw."));
        entries.add(new HelpEntry("Setting: Auto Trace List", "Usernames to auto-trace when found in a lobby."));

        entries.add(new HelpEntry("Section: Auto Lobby Scan", "Automatic API scans."));
        entries.add(new HelpEntry("Setting: Enable Auto Lobby Scan", "Enable automatic lobby scanning."));
        entries.add(new HelpEntry("Setting: Scan On Lobby Switch", "Run an auto scan when the lobby changes."));
        entries.add(new HelpEntry("Setting: Scan Every 5 Minutes", "Run periodic auto scans."));

        entries.add(new HelpEntry("Section: Auto Scan Limits", "Rate limits and pacing."));
        entries.add(new HelpEntry("Setting: Debounce Seconds", "Minimum delay after a lobby change before scanning."));
        entries.add(new HelpEntry("Setting: Min Gap Seconds", "Minimum time between auto scans."));
        entries.add(new HelpEntry("Setting: Jitter Millis", "Random jitter to avoid synchronized scans."));
        entries.add(new HelpEntry("Setting: Max Requests Per Scan", "API request budget for each scan run."));
        entries.add(new HelpEntry("Setting: Max Players Per Scan", "Limit number of players per scan run."));
        entries.add(new HelpEntry("Setting: Key Burst Threshold", "Requests in a short window before cooldown."));
        entries.add(new HelpEntry("Setting: Burst Window Minutes", "Window size for burst detection."));
        entries.add(new HelpEntry("Setting: Cooldown Minutes", "Cooldown time after a burst."));
        entries.add(new HelpEntry("Setting: Auto Pause Minutes", "Pause time when all keys are exhausted."));

        entries.add(new HelpEntry("Section: API Keys", "Keys used for Hypixel API requests."));
        entries.add(new HelpEntry("Setting: API Key Slot 1/2/3", "Add up to three API keys for rotation."));

        entries.add(new HelpEntry("Section: Debug", "Verbose logging and diagnostics."));
        entries.add(new HelpEntry("Setting: Armor Scan Logs", "Enable debug logs for armor scanning."));
        entries.add(new HelpEntry("Setting: API Scan Logs", "Enable debug logs for API scanning."));
        entries.add(new HelpEntry("Setting: Auto Lobby Logs", "Enable debug logs for auto lobby scan."));
        entries.add(new HelpEntry("Setting: Trace Logs", "Enable debug logs for player tracing."));
        entries.add(new HelpEntry("Setting: Notify Missing Armor UUID", "Chat message when an illegal piece has no armor UUID."));
        entries.add(new HelpEntry("Setting: Scan All Leather (Debug)", "Ignore filters and scan all leather items."));

        entries.add(new HelpEntry("Section: Tools", "Utility actions."));
        entries.add(new HelpEntry("Tool: Whitelist reload on save", "Saving this screen reloads the whitelist file."));
        return entries;
    }

    private record HelpEntry(String title, String description) {
    }
}
