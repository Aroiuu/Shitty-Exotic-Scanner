package com.notdogshit.exoscanner.mixin;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GuiGraphics.class)
public abstract class GuiGraphicsRenderItemMixin {
    @Inject(
        method = "renderItem(Lnet/minecraft/world/item/ItemStack;II)V",
        at = @At("HEAD"),
        require = 0
    )
    private void exoscanner$renderItemHead(
        ItemStack itemStack,
        int x,
        int y,
        CallbackInfo ci
    ) {
        drawHighlight(itemStack, x, y, false);
    }

    @Inject(
        method = "renderItem(Lnet/minecraft/world/item/ItemStack;II)V",
        at = @At("TAIL"),
        require = 0
    )
    private void exoscanner$renderItemTail(
        ItemStack itemStack,
        int x,
        int y,
        CallbackInfo ci
    ) {
        drawHighlight(itemStack, x, y, true);
    }

    private void drawHighlight(ItemStack itemStack, int x, int y, boolean drawBorder) {
        if (itemStack == null || itemStack.isEmpty()) {
            return;
        }
        Minecraft client = Minecraft.getInstance();
        if (client == null || client.screen == null) {
            return;
        }
        if (client.screen instanceof AbstractContainerScreen) {
            return;
        }
        if (!com.notdogshit.exoscanner.ExoScannerClient.shouldHighlightStack(itemStack)) {
            return;
        }
        com.notdogshit.exoscanner.config.InventoryHighlightStyle style =
            com.notdogshit.exoscanner.ExoScannerClient.getHighlightStyle();
        int rgb = com.notdogshit.exoscanner.ExoScannerClient.getHighlightColor() & 0xFFFFFF;
        int fill = (0x66 << 24) | rgb;
        int border = (0xFF << 24) | rgb;
        GuiGraphics guiGraphics = (GuiGraphics) (Object) this;
        if (!drawBorder) {
            if (style == com.notdogshit.exoscanner.config.InventoryHighlightStyle.TRANSLUCENT
                || style == com.notdogshit.exoscanner.config.InventoryHighlightStyle.BOTH) {
                guiGraphics.fill(x, y, x + 16, y + 16, fill);
            }
        } else {
            if (style == com.notdogshit.exoscanner.config.InventoryHighlightStyle.BORDER
                || style == com.notdogshit.exoscanner.config.InventoryHighlightStyle.BOTH) {
                guiGraphics.fill(x, y, x + 16, y + 1, border);
                guiGraphics.fill(x, y + 15, x + 16, y + 16, border);
                guiGraphics.fill(x, y, x + 1, y + 16, border);
                guiGraphics.fill(x + 15, y, x + 16, y + 16, border);
            }
        }
    }
}
