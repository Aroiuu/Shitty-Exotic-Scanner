package com.notdogshit.exoscanner.mixin;

import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(Slot.class)
public interface SlotAccessor {
    @Accessor("x")
    int exoscanner$getX();

    @Accessor("y")
    int exoscanner$getY();
}
