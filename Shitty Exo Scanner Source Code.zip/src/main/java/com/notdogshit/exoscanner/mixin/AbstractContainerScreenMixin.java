package com.notdogshit.exoscanner.mixin;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mixin(AbstractContainerScreen.class)
public abstract class AbstractContainerScreenMixin {
    private static final Logger LOGGER = LoggerFactory.getLogger("ExoScanner-Highlight");
    private static boolean loggedOnce;

    @Inject(method = "renderSlot(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/world/inventory/Slot;)V",
            at = @At("HEAD"), require = 0)
    private void exoscanner$renderSlotHighlight0(GuiGraphics guiGraphics, Slot slot, CallbackInfo ci) {
        renderHighlight(guiGraphics, slot, false);
    }

    @Inject(method = "renderSlot(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/world/inventory/Slot;)V",
            at = @At("TAIL"), require = 0)
    private void exoscanner$renderSlotHighlight1(GuiGraphics guiGraphics, Slot slot, CallbackInfo ci) {
        renderHighlight(guiGraphics, slot, true);
    }

    private void renderHighlight(GuiGraphics guiGraphics, Slot slot, boolean drawBorder) {
        if (guiGraphics == null || slot == null) {
            return;
        }
        ItemStack stack = slot.getItem();
        if (stack == null || stack.isEmpty()) {
            return;
        }
        if (!com.notdogshit.exoscanner.ExoScannerClient.shouldHighlightStack(stack)) {
            return;
        }
        int leftPos = ((AbstractContainerScreenAccessor) this).exoscanner$getLeftPos();
        int topPos = ((AbstractContainerScreenAccessor) this).exoscanner$getTopPos();
        int x = ((SlotAccessor) slot).exoscanner$getX();
        int y = ((SlotAccessor) slot).exoscanner$getY();
        com.notdogshit.exoscanner.config.InventoryHighlightStyle style =
            com.notdogshit.exoscanner.ExoScannerClient.getHighlightStyle();
        int rgb = com.notdogshit.exoscanner.ExoScannerClient.getHighlightColor() & 0xFFFFFF;
        int fill = (0x66 << 24) | rgb;
        int border = (0xFF << 24) | rgb;
        if (!drawBorder) {
            if (style == com.notdogshit.exoscanner.config.InventoryHighlightStyle.TRANSLUCENT
                || style == com.notdogshit.exoscanner.config.InventoryHighlightStyle.BOTH) {
                guiGraphics.fill(x, y, x + 16, y + 16, fill);
            }
        } else {
            if (style == com.notdogshit.exoscanner.config.InventoryHighlightStyle.BORDER
                || style == com.notdogshit.exoscanner.config.InventoryHighlightStyle.BOTH) {
                guiGraphics.fill(x, y, x + 16, y + 1, border);
                guiGraphics.fill(x, y + 15, x + 16, y + 16, border);
                guiGraphics.fill(x, y, x + 1, y + 16, border);
                guiGraphics.fill(x + 15, y, x + 16, y + 16, border);
            }
        }
        if (!loggedOnce) {
            loggedOnce = true;
            LOGGER.info("Highlight mixin active. leftPos={}, topPos={}, slot=({},{}), item={}",
                leftPos, topPos, x, y,
                stack.getHoverName().getString());
        }
    }
}
