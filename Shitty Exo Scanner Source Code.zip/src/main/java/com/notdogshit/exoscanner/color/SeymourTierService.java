package com.notdogshit.exoscanner.color;

import com.notdogshit.exoscanner.util.ColorUtils;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public final class SeymourTierService {
    public static final class Settings {
        public final int metric;
        public final boolean includeFades;
        public final boolean showHighFades;
        public final boolean includeCustom;

        public Settings(int metric, boolean includeFades, boolean showHighFades, boolean includeCustom) {
            this.metric = metric;
            this.includeFades = includeFades;
            this.showHighFades = showHighFades;
            this.includeCustom = includeCustom;
        }
    }

    public static final class SeymourTierResult {
        public final int tier;
        public final double bestDeltaE;
        public final String bestMatchName;
        public final String bestMatchHex;

        public SeymourTierResult(int tier, double bestDeltaE, String bestMatchName, String bestMatchHex) {
            this.tier = tier;
            this.bestDeltaE = bestDeltaE;
            this.bestMatchName = bestMatchName;
            this.bestMatchHex = bestMatchHex;
        }
    }

    private static final Map<String, SeymourTierResult> CACHE = new ConcurrentHashMap<>();

    private SeymourTierService() {
    }

    public static SeymourTierResult computeTierForHex(String hex, String armorKey, Settings settings) {
        if (hex == null || hex.isBlank()) {
            return null;
        }
        ColorReferenceManager.PieceType pieceType = resolveSeymourPieceType(armorKey);
        String key = buildCacheKey(hex, settings, pieceType);
        SeymourTierResult cached = CACHE.get(key);
        if (cached != null) {
            return cached;
        }
        String normalized = normalizeHex(hex);
        double[] lab = ColorMath.hexToLab(normalized);
        ColorReferenceManager refs = ColorReferenceManager.get();
        List<ColorReferenceManager.RefColor> refColors =
            refs.getSeymourReferences(settings.includeFades, settings.includeCustom);

        double best = Double.MAX_VALUE;
        String bestName = null;
        String bestHex = null;
        for (ColorReferenceManager.RefColor ref : refColors) {
            if (pieceType != null && ref.allowedPieces != null && !ref.allowedPieces.contains(pieceType)) {
                continue;
            }
            double delta = settings.metric == 76
                ? ColorMath.deltaE76(lab, new double[]{ref.l, ref.a, ref.b})
                : ColorUtils.ciede2000Lab(lab[0], lab[1], lab[2], ref.l, ref.a, ref.b);
            if (ref.type == ColorReferenceManager.SourceType.FADE && !settings.showHighFades && delta > 2.0) {
                continue;
            }
            if (delta < best) {
                best = delta;
                bestName = ref.name;
                bestHex = ref.hex;
            }
        }

        if (best == Double.MAX_VALUE) {
            return null;
        }

        int tier;
        if (best <= 1.0) {
            tier = 0;
        } else if (best <= 2.0) {
            tier = 1;
        } else if (best <= 5.0) {
            tier = 2;
        } else {
            tier = 3;
        }

        SeymourTierResult result = new SeymourTierResult(tier, best, bestName, bestHex);
        CACHE.put(key, result);
        return result;
    }

    public static SeymourTierResult computeTierForHex(String hex, Settings settings) {
        return computeTierForHex(hex, null, settings);
    }

    public static void clearCache() {
        CACHE.clear();
    }

    private static String buildCacheKey(String hex, Settings settings, ColorReferenceManager.PieceType pieceType) {
        String piece = pieceType == null ? "ANY" : pieceType.name();
        return normalizeHex(hex) + "|" + piece + "|" + settings.metric + "|" + settings.includeFades
            + "|" + settings.showHighFades + "|" + settings.includeCustom;
    }

    private static String normalizeHex(String hex) {
        String cleaned = hex.trim().toUpperCase(Locale.ROOT);
        if (!cleaned.startsWith("#")) {
            cleaned = "#" + cleaned;
        }
        return cleaned;
    }

    private static ColorReferenceManager.PieceType resolveSeymourPieceType(String armorKey) {
        if (armorKey == null) {
            return null;
        }
        return switch (armorKey) {
            case "VELVET_TOP_HAT" -> ColorReferenceManager.PieceType.HELMET;
            case "CASHMERE_JACKET" -> ColorReferenceManager.PieceType.CHESTPLATE;
            case "SATIN_TROUSERS" -> ColorReferenceManager.PieceType.LEGGINGS;
            case "OXFORD_SHOES" -> ColorReferenceManager.PieceType.BOOTS;
            default -> null;
        };
    }
}
