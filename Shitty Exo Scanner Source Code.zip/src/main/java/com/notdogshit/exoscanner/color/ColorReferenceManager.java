package com.notdogshit.exoscanner.color;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ColorReferenceManager {
    public enum SourceType {
        TARGET,
        FADE,
        CHECKLIST,
        CUSTOM
    }

    public enum PieceType {
        HELMET,
        CHESTPLATE,
        LEGGINGS,
        BOOTS
    }

    public static final class RefColor {
        public final String name;
        public final String hex;
        public final double l;
        public final double a;
        public final double b;
        public final SourceType type;
        public final java.util.EnumSet<PieceType> allowedPieces;

        public RefColor(String name, String hex, double l, double a, double b, SourceType type,
                        java.util.EnumSet<PieceType> allowedPieces) {
            this.name = name;
            this.hex = hex;
            this.l = l;
            this.a = a;
            this.b = b;
            this.type = type;
            this.allowedPieces = allowedPieces;
        }
    }

    private static final ColorReferenceManager INSTANCE = new ColorReferenceManager();

    private volatile List<RefColor> targetRefs = List.of();
    private volatile List<RefColor> fadeRefs = List.of();
    private volatile List<RefColor> checklistRefs = List.of();
    private volatile List<RefColor> customRefs = List.of();

    private ColorReferenceManager() {
    }

    public static ColorReferenceManager get() {
        return INSTANCE;
    }

    public synchronized void reload() {
        Path configDir = FabricLoader.getInstance().getConfigDir();
        Path colorsPath = configDir.resolve("colors.json");
        Path checklistPath = configDir.resolve("checklistdata.json");
        Path customPath = configDir.resolve("custom_colors.json");

        List<RefColor> targets = List.of();
        List<RefColor> fades = List.of();
        List<RefColor> checklist = List.of();
        List<RefColor> custom = List.of();

        if (Files.exists(colorsPath)) {
            try {
                Map<String, String> targetColors = ColorLoader.loadNamedColors(colorsPath, "TARGET_COLORS");
                Map<String, String> fadeColors = ColorLoader.loadNamedColors(colorsPath, "FADE_DYES");
                if (targetColors.isEmpty() && fadeColors.isEmpty()) {
                    targetColors = ColorLoader.loadNamedColors(colorsPath);
                }
                targets = toRefList(targetColors, SourceType.TARGET);
                fades = toRefList(fadeColors, SourceType.FADE);
            } catch (IOException ignored) {
                // keep previous cache
            }
        }

        if (Files.exists(checklistPath)) {
            try {
                Map<String, String> checklistColors = ColorLoader.loadChecklistColors(checklistPath);
                checklist = toRefList(checklistColors, SourceType.CHECKLIST);
            } catch (IOException ignored) {
                // keep previous cache
            }
        }

        if (Files.exists(customPath)) {
            try {
                Map<String, String> customColors = ColorLoader.loadNamedColors(customPath);
                custom = toRefList(customColors, SourceType.CUSTOM);
            } catch (IOException ignored) {
                // keep previous cache
            }
        }

        targetRefs = targets;
        fadeRefs = fades;
        checklistRefs = checklist;
        customRefs = custom;
    }

    public List<RefColor> getSeymourReferences(boolean includeFades, boolean includeCustom) {
        List<RefColor> merged = new ArrayList<>();
        merged.addAll(targetRefs);
        merged.addAll(checklistRefs);
        if (includeCustom) {
            merged.addAll(customRefs);
        }
        if (includeFades) {
            merged.addAll(fadeRefs);
        }
        return merged;
    }

    public List<RefColor> getFadeReferences() {
        return fadeRefs;
    }

    public List<RefColor> getTargetReferences() {
        return targetRefs;
    }

    public List<RefColor> getChecklistReferences() {
        return checklistRefs;
    }

    public List<RefColor> getCustomReferences() {
        return customRefs;
    }

    private static List<RefColor> toRefList(Map<String, String> colors, SourceType type) {
        if (colors == null || colors.isEmpty()) {
            return Collections.emptyList();
        }
        List<RefColor> out = new ArrayList<>(colors.size());
        for (Map.Entry<String, String> entry : colors.entrySet()) {
            if (entry.getKey() == null || entry.getValue() == null) {
                continue;
            }
            String hex = normalizeHex(entry.getValue());
            double[] lab = ColorMath.hexToLab(hex);
            java.util.EnumSet<PieceType> allowed = resolveAllowedPieces(entry.getKey());
            out.add(new RefColor(entry.getKey(), hex, lab[0], lab[1], lab[2], type, allowed));
        }
        return out;
    }

    private static String normalizeHex(String hex) {
        String cleaned = hex.trim().toUpperCase(Locale.ROOT);
        if (!cleaned.startsWith("#")) {
            cleaned = "#" + cleaned;
        }
        return cleaned;
    }

    private static java.util.EnumSet<PieceType> resolveAllowedPieces(String name) {
        if (name == null || name.isBlank()) {
            return null;
        }
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.contains("3p") || lower.contains("3-piece") || lower.contains("3 piece")) {
            return java.util.EnumSet.of(PieceType.CHESTPLATE, PieceType.LEGGINGS, PieceType.BOOTS);
        }
        boolean helmet = lower.contains("helmet") || lower.contains("helm") || lower.contains("hat");
        boolean chestplate = lower.contains("chestplate");
        boolean leggings = lower.contains("leggings") || lower.contains("pants") || lower.contains("trousers");
        boolean boots = lower.contains("boots") || lower.contains("shoes") || lower.contains("sneakers");
        if (!helmet && !chestplate && !leggings && !boots) {
            return null;
        }
        java.util.EnumSet<PieceType> out = java.util.EnumSet.noneOf(PieceType.class);
        if (helmet) {
            out.add(PieceType.HELMET);
        }
        if (chestplate) {
            out.add(PieceType.CHESTPLATE);
        }
        if (leggings) {
            out.add(PieceType.LEGGINGS);
        }
        if (boots) {
            out.add(PieceType.BOOTS);
        }
        return out.isEmpty() ? null : out;
    }
}
