package com.notdogshit.exoscanner.color;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public final class ColorLoader {
    private ColorLoader() {
    }

    public static Map<String, String> loadNamedColors(Path path) throws IOException {
        try (Reader reader = Files.newBufferedReader(path)) {
            JsonElement root = JsonParser.parseReader(reader);
            Map<String, String> out = new HashMap<>();
            collectColors(root, out);
            return out;
        }
    }

    public static Map<String, String> loadNamedColors(Path path, String key) throws IOException {
        try (Reader reader = Files.newBufferedReader(path)) {
            JsonElement root = JsonParser.parseReader(reader);
            if (root == null || !root.isJsonObject()) {
                return Map.of();
            }
            JsonObject obj = root.getAsJsonObject();
            JsonElement target = obj.get(key);
            if (target == null) {
                return Map.of();
            }
            Map<String, String> out = new HashMap<>();
            collectColors(target, out);
            return out;
        }
    }

    public static Map<String, String> loadChecklistColors(Path path) throws IOException {
        try (Reader reader = Files.newBufferedReader(path)) {
            JsonElement root = JsonParser.parseReader(reader);
            if (root == null || !root.isJsonObject()) {
                return Map.of();
            }
            JsonObject obj = root.getAsJsonObject();
            JsonElement categories = obj.get("categories");
            if (categories == null || !categories.isJsonObject()) {
                return Map.of();
            }
            Map<String, String> out = new HashMap<>();
            for (Map.Entry<String, JsonElement> entry : categories.getAsJsonObject().entrySet()) {
                String category = entry.getKey();
                JsonElement value = entry.getValue();
                if (value == null || !value.isJsonArray()) {
                    continue;
                }
                for (JsonElement item : value.getAsJsonArray()) {
                    if (item == null || !item.isJsonObject()) {
                        continue;
                    }
                    JsonObject itemObj = item.getAsJsonObject();
                    if (!itemObj.has("hex") || !itemObj.has("name")) {
                        continue;
                    }
                    String name = itemObj.get("name").getAsString();
                    String hex = itemObj.get("hex").getAsString();
                    String key = category + " - " + name;
                    out.put(key, normalizeHex(hex));
                }
            }
            return out;
        }
    }

    private static void collectColors(JsonElement element, Map<String, String> out) {
        if (element == null || element.isJsonNull()) {
            return;
        }
        if (element.isJsonObject()) {
            JsonObject obj = element.getAsJsonObject();
            if (obj.has("name") && obj.has("hex")) {
                String name = obj.get("name").getAsString();
                String hex = obj.get("hex").getAsString();
                out.put(name, normalizeHex(hex));
                return;
            }
            for (Map.Entry<String, JsonElement> entry : obj.entrySet()) {
                JsonElement value = entry.getValue();
                if (value != null && value.isJsonPrimitive()) {
                    out.put(entry.getKey(), normalizeHex(value.getAsString()));
                    continue;
                }
                collectColors(value, out);
            }
            return;
        }
        if (element.isJsonArray()) {
            JsonArray array = element.getAsJsonArray();
            for (JsonElement entry : array) {
                collectColors(entry, out);
            }
        }
    }

    private static String normalizeHex(String hex) {
        String cleaned = hex.trim().toUpperCase();
        if (!cleaned.startsWith("#")) {
            cleaned = "#" + cleaned;
        }
        return cleaned;
    }
}
