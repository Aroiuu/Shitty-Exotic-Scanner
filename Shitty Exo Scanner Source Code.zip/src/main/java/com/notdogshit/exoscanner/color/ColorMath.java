package com.notdogshit.exoscanner.color;

public final class ColorMath {
    private ColorMath() {
    }

    public static int[] hexToRgb(String hex) {
        String cleaned = hex.trim();
        if (cleaned.startsWith("#")) {
            cleaned = cleaned.substring(1);
        }
        if (cleaned.length() != 6) {
            throw new IllegalArgumentException("Invalid hex color: " + hex);
        }
        int value = Integer.parseInt(cleaned, 16);
        return new int[] { (value >> 16) & 0xFF, (value >> 8) & 0xFF, value & 0xFF };
    }

    public static double[] rgbToXyzD65(int r, int g, int b) {
        double rLin = linearize(r / 255.0);
        double gLin = linearize(g / 255.0);
        double bLin = linearize(b / 255.0);

        double x = (rLin * 0.4124 + gLin * 0.3576 + bLin * 0.1805) * 100.0;
        double y = (rLin * 0.2126 + gLin * 0.7152 + bLin * 0.0722) * 100.0;
        double z = (rLin * 0.0193 + gLin * 0.1192 + bLin * 0.9505) * 100.0;
        return new double[] { x, y, z };
    }

    public static double[] xyzToLabD65(double x, double y, double z) {
        double xr = x / 95.047;
        double yr = y / 100.000;
        double zr = z / 108.883;

        double fx = pivotLab(xr);
        double fy = pivotLab(yr);
        double fz = pivotLab(zr);

        double l = (116.0 * fy) - 16.0;
        double a = 500.0 * (fx - fy);
        double b = 200.0 * (fy - fz);
        return new double[] { l, a, b };
    }

    public static double[] hexToLab(String hex) {
        int[] rgb = hexToRgb(hex);
        double[] xyz = rgbToXyzD65(rgb[0], rgb[1], rgb[2]);
        return xyzToLabD65(xyz[0], xyz[1], xyz[2]);
    }

    public static double deltaE76(double[] lab1, double[] lab2) {
        double dl = lab1[0] - lab2[0];
        double da = lab1[1] - lab2[1];
        double db = lab1[2] - lab2[2];
        return Math.sqrt(dl * dl + da * da + db * db);
    }

    private static double linearize(double c) {
        return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4);
    }

    private static double pivotLab(double t) {
        return t > 0.008856 ? Math.cbrt(t) : (7.787 * t) + (16.0 / 116.0);
    }
}
