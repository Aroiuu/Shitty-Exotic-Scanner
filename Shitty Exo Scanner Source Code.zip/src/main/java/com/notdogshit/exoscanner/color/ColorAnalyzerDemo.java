package com.notdogshit.exoscanner.color;

import java.nio.file.Path;
import java.util.Map;

public final class ColorAnalyzerDemo {
    public static void main(String[] args) throws Exception {
        if (args.length < 3) {
            System.out.println("Usage: ColorAnalyzerDemo <armorName> <observedHex> <colors.json> [custom.json]");
            System.out.println("Example: ColorAnalyzerDemo \"Strong Dragon Chestplate\" #9F3F3F C:\\\\Users\\\\Owner\\\\Downloads\\\\colors.json");
            return;
        }
        String armorName = args[0];
        String observedHex = args[1];
        Path colorsPath = Path.of(args[2]);
        Path customPath = args.length >= 4 ? Path.of(args[3]) : null;

        Map<String, String> targetColors = ColorLoader.loadNamedColors(colorsPath, "TARGET_COLORS");
        Map<String, String> fadeColors = ColorLoader.loadNamedColors(colorsPath, "FADE_DYES");
        Map<String, String> customColors = customPath == null ? Map.of() : ColorLoader.loadNamedColors(customPath);

        ColorAnalyzer.Config cfg = new ColorAnalyzer.Config();
        cfg.enableFadeDyes = true;
        cfg.enableCustomColors = customPath != null;
        cfg.showHighFades = true;
        cfg.targetColors = targetColors;
        cfg.fadeColors = fadeColors;
        cfg.customColors = customColors;

        ColorAnalyzer.AnalysisResult result = ColorAnalyzer.analyzeArmorColor(armorName, observedHex, cfg);

        System.out.println("Observed: " + result.observedHex);
        System.out.println("Best tier: " + result.bestTier);
        System.out.println("Top matches:");
        for (ColorAnalyzer.MatchResult match : result.matches) {
            System.out.printf("  %s (%s) ΔE=%.3f tier=%d source=%s exact=%s%n",
                match.name, match.hex, match.deltaE, match.tier, match.sourceType, match.exact);
        }
        System.out.println("Debug candidates:");
        for (ColorAnalyzer.MatchResult match : result.debugCandidates) {
            System.out.printf("  %s (%s) ΔE=%.3f tier=%d source=%s exact=%s%n",
                match.name, match.hex, match.deltaE, match.tier, match.sourceType, match.exact);
        }
        System.out.println("Piece type: " + ColorAnalyzer.classifyPieceType(armorName));
    }
}
