package com.notdogshit.exoscanner.color;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ColorAnalyzer {
    public enum SourceType {
        CUSTOM,
        TARGET,
        FADE
    }

    public static final class Config {
        public boolean enableCustomColors = false;
        public boolean enableFadeDyes = true;
        public boolean showHighFades = true;
        public List<String> priorityOrder = List.of("EXACT", "CUSTOM", "FADE", "TARGET");
        public Map<String, String> targetColors = Map.of();
        public Map<String, String> fadeColors = Map.of();
        public Map<String, String> customColors = Map.of();
    }

    public static final class MatchResult {
        public final String name;
        public final String hex;
        public final double deltaE;
        public final int tier;
        public final SourceType sourceType;
        public final boolean exact;

        public MatchResult(String name, String hex, double deltaE, int tier, SourceType sourceType, boolean exact) {
            this.name = name;
            this.hex = hex;
            this.deltaE = deltaE;
            this.tier = tier;
            this.sourceType = sourceType;
            this.exact = exact;
        }
    }

    public static final class AnalysisResult {
        public final String observedHex;
        public final double[] observedLab;
        public final int bestTier;
        public final List<MatchResult> matches;
        public final List<MatchResult> debugCandidates;

        public AnalysisResult(String observedHex, double[] observedLab, int bestTier,
                              List<MatchResult> matches, List<MatchResult> debugCandidates) {
            this.observedHex = observedHex;
            this.observedLab = observedLab;
            this.bestTier = bestTier;
            this.matches = matches;
            this.debugCandidates = debugCandidates;
        }
    }

    private ColorAnalyzer() {
    }

    public static AnalysisResult analyzeArmorColor(String armorName, String observedHex, Config cfg) {
        String normalizedHex = normalizeHex(observedHex);
        double[] observedLab = ColorMath.hexToLab(normalizedHex);

        List<MatchResult> target = scoreGroup(cfg.targetColors, SourceType.TARGET, observedLab, cfg);
        List<MatchResult> fade = cfg.enableFadeDyes
            ? scoreGroup(cfg.fadeColors, SourceType.FADE, observedLab, cfg)
            : List.of();
        List<MatchResult> custom = cfg.enableCustomColors
            ? scoreGroup(cfg.customColors, SourceType.CUSTOM, observedLab, cfg)
            : List.of();

        List<MatchResult> combined = new ArrayList<>();
        combined.addAll(target.subList(0, Math.min(5, target.size())));
        combined.addAll(fade.subList(0, Math.min(5, fade.size())));
        combined.addAll(custom.subList(0, Math.min(5, custom.size())));

        combined.sort(buildComparator(cfg));
        List<MatchResult> debugCandidates = combined.subList(0, Math.min(10, combined.size()));
        List<MatchResult> matches = debugCandidates.subList(0, Math.min(3, debugCandidates.size()));
        int bestTier = matches.isEmpty() ? -1 : matches.get(0).tier;

        return new AnalysisResult(normalizedHex, observedLab, bestTier,
            List.copyOf(matches), List.copyOf(debugCandidates));
    }

    public static String classifyPieceType(String armorName) {
        if (armorName == null) {
            return "UNKNOWN";
        }
        String lower = armorName.toLowerCase(Locale.ROOT);
        if (lower.contains("helmet") || lower.contains("cap")) {
            return "HELMET";
        }
        if (lower.contains("chestplate") || lower.contains("tunic")) {
            return "CHEST";
        }
        if (lower.contains("leggings") || lower.contains("pants")) {
            return "LEGS";
        }
        if (lower.contains("boots") || lower.contains("shoes")) {
            return "BOOTS";
        }
        return "UNKNOWN";
    }

    private static List<MatchResult> scoreGroup(Map<String, String> colors, SourceType source, double[] observedLab, Config cfg) {
        List<MatchResult> results = new ArrayList<>();
        for (Map.Entry<String, String> entry : colors.entrySet()) {
            String hex = normalizeHex(entry.getValue());
            double[] lab = ColorMath.hexToLab(hex);
            double delta = ColorMath.deltaE76(observedLab, lab);
            if (source == SourceType.FADE && !cfg.showHighFades && delta > 2.0) {
                continue;
            }
            boolean exact = delta < 0.01;
            int tier = calculateTier(delta, source);
            results.add(new MatchResult(entry.getKey(), hex, delta, tier, source, exact));
        }
        results.sort(Comparator.comparingDouble(r -> r.deltaE));
        return results;
    }

    public static int calculateTier(double deltaE, SourceType sourceType) {
        if (sourceType == SourceType.CUSTOM) {
            if (deltaE <= 2.0) {
                return 1;
            }
            if (deltaE <= 5.0) {
                return 2;
            }
            return 3;
        }
        if (deltaE <= 1.0) {
            return 0;
        }
        if (deltaE <= 2.0) {
            return 1;
        }
        if (deltaE <= 5.0) {
            return 2;
        }
        return 3;
    }

    private static Comparator<MatchResult> buildComparator(Config cfg) {
        Map<String, Integer> rankMap = new java.util.HashMap<>();
        for (int i = 0; i < cfg.priorityOrder.size(); i++) {
            rankMap.put(cfg.priorityOrder.get(i).toUpperCase(Locale.ROOT), i);
        }
        return (a, b) -> {
            if (a.exact != b.exact) {
                return a.exact ? -1 : 1;
            }
            if (a.tier != b.tier) {
                return Integer.compare(a.tier, b.tier);
            }
            int pa = rankMap.getOrDefault(a.sourceType.name(), 99);
            int pb = rankMap.getOrDefault(b.sourceType.name(), 99);
            if (pa != pb) {
                return Integer.compare(pa, pb);
            }
            return Double.compare(a.deltaE, b.deltaE);
        };
    }

    private static String normalizeHex(String hex) {
        String cleaned = hex == null ? "" : hex.trim().toUpperCase(Locale.ROOT);
        if (!cleaned.startsWith("#")) {
            cleaned = "#" + cleaned;
        }
        return cleaned;
    }
}
