package com.notdogshit.exoscanner.util;

public final class ColorUtils {
    private static final java.util.Map<String, String> NAMED_COLORS = java.util.Map.ofEntries(
        java.util.Map.entry("red", "#993333"),
        java.util.Map.entry("orange", "#D87F33"),
        java.util.Map.entry("yellow", "#E5E533"),
        java.util.Map.entry("lime", "#7FCC19"),
        java.util.Map.entry("darkgreen", "#667F33"),
        java.util.Map.entry("dark_green", "#667F33"),
        java.util.Map.entry("lightblue", "#6699D8"),
        java.util.Map.entry("light_blue", "#6699D8"),
        java.util.Map.entry("cyan", "#4C7F99"),
        java.util.Map.entry("darkblue", "#334CB2"),
        java.util.Map.entry("dark_blue", "#334CB2"),
        java.util.Map.entry("pink", "#F27FA5"),
        java.util.Map.entry("purple", "#7F3FB2"),
        java.util.Map.entry("magenta", "#B24CD8"),
        java.util.Map.entry("brown", "#664C33"),
        java.util.Map.entry("white", "#FFFFFF"),
        java.util.Map.entry("lightgray", "#999999"),
        java.util.Map.entry("lightgrey", "#999999"),
        java.util.Map.entry("light_gray", "#999999"),
        java.util.Map.entry("light_grey", "#999999"),
        java.util.Map.entry("darkgray", "#4C4C4C"),
        java.util.Map.entry("darkgrey", "#4C4C4C"),
        java.util.Map.entry("dark_gray", "#4C4C4C"),
        java.util.Map.entry("dark_grey", "#4C4C4C"),
        java.util.Map.entry("black", "#191919")
    );

    private ColorUtils() {
    }

    public static java.util.Set<String> namedColorKeys() {
        return NAMED_COLORS.keySet();
    }

    public static double ciede2000(int rgb1, int rgb2) {
        double[] lab1 = rgbToLab(rgb1);
        double[] lab2 = rgbToLab(rgb2);
        return ciede2000Lab(lab1[0], lab1[1], lab1[2], lab2[0], lab2[1], lab2[2]);
    }

    public static double cie76(int rgb1, int rgb2) {
        double[] lab1 = rgbToLab(rgb1);
        double[] lab2 = rgbToLab(rgb2);
        double dl = lab1[0] - lab2[0];
        double da = lab1[1] - lab2[1];
        double db = lab1[2] - lab2[2];
        return Math.sqrt(dl * dl + da * da + db * db);
    }

    public static int parseHex(String hex) {
        String cleaned = hex.trim();
        if (cleaned.startsWith("#")) {
            cleaned = cleaned.substring(1);
        }
        return Integer.parseInt(cleaned, 16) & 0xFFFFFF;
    }

    public static String normalizeHexInput(String input) {
        if (input == null) {
            return "#000000";
        }
        String cleaned = input.trim();
        if (cleaned.isEmpty()) {
            return "#000000";
        }
        String lowered = cleaned.toLowerCase(java.util.Locale.ROOT).replace(" ", "").replace("-", "");
        String named = NAMED_COLORS.get(lowered);
        if (named != null) {
            return named;
        }
        if (lowered.startsWith("#")) {
            return "#" + lowered.substring(1).toUpperCase(java.util.Locale.ROOT);
        }
        if (lowered.matches("^[0-9a-f]{6}$")) {
            return "#" + lowered.toUpperCase(java.util.Locale.ROOT);
        }
        return "#" + cleaned.toUpperCase(java.util.Locale.ROOT).replace("#", "");
    }

    public static double[] rgbToLab(int rgb) {
        double r = ((rgb >> 16) & 0xFF) / 255.0;
        double g = ((rgb >> 8) & 0xFF) / 255.0;
        double b = (rgb & 0xFF) / 255.0;

        r = r <= 0.04045 ? r / 12.92 : Math.pow((r + 0.055) / 1.055, 2.4);
        g = g <= 0.04045 ? g / 12.92 : Math.pow((g + 0.055) / 1.055, 2.4);
        b = b <= 0.04045 ? b / 12.92 : Math.pow((b + 0.055) / 1.055, 2.4);

        double x = (r * 0.4124 + g * 0.3576 + b * 0.1805) / 0.95047;
        double y = (r * 0.2126 + g * 0.7152 + b * 0.0722) / 1.00000;
        double z = (r * 0.0193 + g * 0.1192 + b * 0.9505) / 1.08883;

        x = x > 0.008856 ? Math.cbrt(x) : (7.787 * x) + (16.0 / 116.0);
        y = y > 0.008856 ? Math.cbrt(y) : (7.787 * y) + (16.0 / 116.0);
        z = z > 0.008856 ? Math.cbrt(z) : (7.787 * z) + (16.0 / 116.0);

        double l = (116.0 * y) - 16.0;
        double a = 500.0 * (x - y);
        double bLab = 200.0 * (y - z);
        return new double[] { l, a, bLab };
    }

    public static double ciede2000Lab(double l1, double a1, double b1, double l2, double a2, double b2) {
        double avgLp = (l1 + l2) / 2.0;
        double c1 = Math.hypot(a1, b1);
        double c2 = Math.hypot(a2, b2);
        double avgC = (c1 + c2) / 2.0;

        double g = 0.5 * (1 - Math.sqrt(Math.pow(avgC, 7.0) / (Math.pow(avgC, 7.0) + Math.pow(25.0, 7.0))));
        double a1p = (1 + g) * a1;
        double a2p = (1 + g) * a2;
        double c1p = Math.hypot(a1p, b1);
        double c2p = Math.hypot(a2p, b2);
        double avgCp = (c1p + c2p) / 2.0;

        double h1p = Math.atan2(b1, a1p);
        if (h1p < 0) {
            h1p += 2 * Math.PI;
        }
        double h2p = Math.atan2(b2, a2p);
        if (h2p < 0) {
            h2p += 2 * Math.PI;
        }

        double deltahp;
        if (Math.abs(h1p - h2p) <= Math.PI) {
            deltahp = h2p - h1p;
        } else if (h2p <= h1p) {
            deltahp = h2p - h1p + 2 * Math.PI;
        } else {
            deltahp = h2p - h1p - 2 * Math.PI;
        }

        double deltaLp = l2 - l1;
        double deltaCp = c2p - c1p;
        double deltaHp = 2 * Math.sqrt(c1p * c2p) * Math.sin(deltahp / 2.0);

        double avgHp;
        if (Math.abs(h1p - h2p) > Math.PI) {
            avgHp = (h1p + h2p + 2 * Math.PI) / 2.0;
        } else {
            avgHp = (h1p + h2p) / 2.0;
        }

        double t = 1
            - 0.17 * Math.cos(avgHp - Math.toRadians(30))
            + 0.24 * Math.cos(2 * avgHp)
            + 0.32 * Math.cos(3 * avgHp + Math.toRadians(6))
            - 0.20 * Math.cos(4 * avgHp - Math.toRadians(63));

        double deltaTheta = Math.toRadians(30) * Math.exp(-Math.pow((Math.toDegrees(avgHp) - 275) / 25.0, 2.0));
        double rc = 2 * Math.sqrt(Math.pow(avgCp, 7.0) / (Math.pow(avgCp, 7.0) + Math.pow(25.0, 7.0)));
        double sl = 1 + ((0.015 * Math.pow(avgLp - 50, 2)) / Math.sqrt(20 + Math.pow(avgLp - 50, 2)));
        double sc = 1 + 0.045 * avgCp;
        double sh = 1 + 0.015 * avgCp * t;
        double rt = -Math.sin(2 * deltaTheta) * rc;

        double kl = 1;
        double kc = 1;
        double kh = 1;

        double termL = deltaLp / (kl * sl);
        double termC = deltaCp / (kc * sc);
        double termH = deltaHp / (kh * sh);
        return Math.sqrt(termL * termL + termC * termC + termH * termH + rt * termC * termH);
    }
}
