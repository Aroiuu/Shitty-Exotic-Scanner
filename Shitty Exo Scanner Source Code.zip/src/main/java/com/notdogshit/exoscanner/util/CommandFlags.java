package com.notdogshit.exoscanner.util;

import java.time.Duration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class CommandFlags {
    private final Map<String, String> values;

    private CommandFlags(Map<String, String> values) {
        this.values = values;
    }

    public static CommandFlags parse(String input) {
        Map<String, String> out = new HashMap<>();
        if (input == null || input.isBlank()) {
            return new CommandFlags(out);
        }
        String[] tokens = input.trim().split("\\s+");
        for (int i = 0; i < tokens.length; i++) {
            String token = tokens[i];
            String raw = token;
            if (raw.startsWith("--")) {
                raw = raw.substring(2);
            }
            String key;
            String value = null;
            int eq = raw.indexOf('=');
            if (eq >= 0) {
                key = raw.substring(0, eq);
                value = raw.substring(eq + 1);
            } else {
                key = raw;
                if (i + 1 < tokens.length && !tokens[i + 1].startsWith("--") && !tokens[i + 1].contains("=")) {
                    value = tokens[i + 1];
                    i++;
                }
            }
            if (key == null || key.isBlank()) {
                continue;
            }
            out.put(key.toLowerCase(Locale.ROOT), value == null ? "" : value);
        }
        return new CommandFlags(out);
    }

    public boolean has(String key) {
        if (key == null) {
            return false;
        }
        return values.containsKey(key.toLowerCase(Locale.ROOT));
    }

    public String getString(String key) {
        if (key == null) {
            return null;
        }
        return values.get(key.toLowerCase(Locale.ROOT));
    }

    public Integer getInt(String key) {
        String value = getString(key);
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return Integer.parseInt(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public Double getDouble(String key) {
        String value = getString(key);
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return Double.parseDouble(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static Duration parseSince(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        String trimmed = input.trim().toLowerCase(Locale.ROOT);
        if (!trimmed.matches("^[0-9]+[mhd]$")) {
            return null;
        }
        long value = Long.parseLong(trimmed.substring(0, trimmed.length() - 1));
        char unit = trimmed.charAt(trimmed.length() - 1);
        return switch (unit) {
            case 'm' -> Duration.ofMinutes(value);
            case 'h' -> Duration.ofHours(value);
            case 'd' -> Duration.ofDays(value);
            default -> null;
        };
    }
}
