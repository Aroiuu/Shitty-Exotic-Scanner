package com.notdogshit.exoscanner.util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class XlsxExporter {
    private XlsxExporter() {
    }

    public interface RowWriter {
        void writeRows(SheetWriter writer) throws IOException;
    }

    public interface SheetWriter {
        void writeRow(List<String> values, String swatchHex) throws IOException;
    }

    public static void write(Path path, List<String> headers, List<String> swatchHexes, RowWriter rows)
        throws IOException {
        Map<String, Integer> styleByHex = buildStyleMap(swatchHexes);
        try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(path))) {
            writeEntry(zip, "[Content_Types].xml", contentTypes());
            writeEntry(zip, "_rels/.rels", rootRels());
            writeEntry(zip, "xl/workbook.xml", workbookXml());
            writeEntry(zip, "xl/_rels/workbook.xml.rels", workbookRels());
            writeEntry(zip, "xl/styles.xml", stylesXml(styleByHex));
            writeSheet(zip, headers, rows, styleByHex);
        }
    }

    private static void writeSheet(ZipOutputStream zip, List<String> headers, RowWriter rows,
                                   Map<String, Integer> styleByHex) throws IOException {
        ZipEntry entry = new ZipEntry("xl/worksheets/sheet1.xml");
        zip.putNextEntry(entry);
        BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(zip, StandardCharsets.UTF_8));
        writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        writer.write("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        writer.write("<sheetData>");

        SheetWriter sheetWriter = new SheetWriter() {
            private int rowIndex = 0;

            @Override
            public void writeRow(List<String> values, String swatchHex) throws IOException {
                rowIndex++;
                writer.write("<row r=\"" + rowIndex + "\">");
                if (swatchHex == null) {
                    for (int i = 0; i < values.size(); i++) {
                        String cellRef = cellRef(i, rowIndex);
                        writer.write("<c r=\"" + cellRef + "\" t=\"inlineStr\">");
                        writer.write("<is><t>");
                        writer.write(escapeXml(values.get(i)));
                        writer.write("</t></is></c>");
                    }
                } else {
                    int lastIndex = Math.max(0, values.size() - 1);
                    for (int i = 0; i < lastIndex; i++) {
                        String cellRef = cellRef(i, rowIndex);
                        writer.write("<c r=\"" + cellRef + "\" t=\"inlineStr\">");
                        writer.write("<is><t>");
                        writer.write(escapeXml(values.get(i)));
                        writer.write("</t></is></c>");
                    }
                    String swatchRef = cellRef(lastIndex, rowIndex);
                    int styleId = styleByHex.getOrDefault(normalizeHex(swatchHex), 0);
                    writer.write("<c r=\"" + swatchRef + "\" s=\"" + styleId + "\"/>");
                }
                writer.write("</row>");
            }
        };

        sheetWriter.writeRow(headers, null);
        rows.writeRows(sheetWriter);

        writer.write("</sheetData>");
        writer.write("</worksheet>");
        writer.flush();
        zip.closeEntry();
    }

    private static Map<String, Integer> buildStyleMap(List<String> hexes) {
        Map<String, Integer> map = new LinkedHashMap<>();
        int styleIndex = 1; // 0 is default
        for (String hex : hexes) {
            String normalized = normalizeHex(hex);
            if (normalized == null || map.containsKey(normalized)) {
                continue;
            }
            map.put(normalized, styleIndex++);
        }
        return map;
    }

    private static String stylesXml(Map<String, Integer> styleByHex) {
        int fillCount = 2 + styleByHex.size();
        int xfCount = 1 + styleByHex.size();
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        sb.append("<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        sb.append("<fonts count=\"1\"><font><sz val=\"11\"/><color theme=\"1\"/>");
        sb.append("<name val=\"Calibri\"/><family val=\"2\"/></font></fonts>");
        sb.append("<fills count=\"").append(fillCount).append("\">");
        sb.append("<fill><patternFill patternType=\"none\"/></fill>");
        sb.append("<fill><patternFill patternType=\"gray125\"/></fill>");
        for (String hex : styleByHex.keySet()) {
            sb.append("<fill><patternFill patternType=\"solid\">");
            sb.append("<fgColor rgb=\"FF").append(hex.substring(1)).append("\"/>");
            sb.append("<bgColor indexed=\"64\"/>");
            sb.append("</patternFill></fill>");
        }
        sb.append("</fills>");
        sb.append("<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>");
        sb.append("<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>");
        sb.append("<cellXfs count=\"").append(xfCount).append("\">");
        sb.append("<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>");
        int fillId = 2;
        for (int i = 0; i < styleByHex.size(); i++) {
            sb.append("<xf numFmtId=\"0\" fontId=\"0\" fillId=\"").append(fillId++)
                .append("\" borderId=\"0\" xfId=\"0\" applyFill=\"1\"/>");
        }
        sb.append("</cellXfs>");
        sb.append("</styleSheet>");
        return sb.toString();
    }

    private static String workbookXml() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" "
            + "xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">"
            + "<sheets><sheet name=\"Export\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>";
    }

    private static String workbookRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" "
            + "Target=\"worksheets/sheet1.xml\"/>"
            + "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" "
            + "Target=\"styles.xml\"/>"
            + "</Relationships>";
    }

    private static String rootRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
            + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" "
            + "Target=\"xl/workbook.xml\"/>"
            + "</Relationships>";
    }

    private static String contentTypes() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
            + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
            + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
            + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
            + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
            + "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
            + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>"
            + "</Types>";
    }

    private static void writeEntry(ZipOutputStream zip, String name, String content) throws IOException {
        ZipEntry entry = new ZipEntry(name);
        zip.putNextEntry(entry);
        zip.write(content.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static String cellRef(int columnIndex, int rowIndex) {
        int col = columnIndex + 1;
        StringBuilder sb = new StringBuilder();
        while (col > 0) {
            int rem = (col - 1) % 26;
            sb.insert(0, (char) ('A' + rem));
            col = (col - 1) / 26;
        }
        return sb + String.valueOf(rowIndex);
    }

    private static String escapeXml(String value) {
        if (value == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder(value.length());
        for (char c : value.toCharArray()) {
            switch (c) {
                case '&' -> sb.append("&amp;");
                case '<' -> sb.append("&lt;");
                case '>' -> sb.append("&gt;");
                case '"' -> sb.append("&quot;");
                case '\'' -> sb.append("&apos;");
                default -> sb.append(c);
            }
        }
        return sb.toString();
    }

    private static String normalizeHex(String hex) {
        if (hex == null || hex.isBlank()) {
            return null;
        }
        String cleaned = hex.trim().toUpperCase(Locale.ROOT);
        if (!cleaned.startsWith("#")) {
            cleaned = "#" + cleaned;
        }
        if (cleaned.length() != 7) {
            return null;
        }
        for (int i = 1; i < cleaned.length(); i++) {
            char c = cleaned.charAt(i);
            boolean isHex = (c >= '0' && c <= '9') || (c >= 'A' && c <= 'F');
            if (!isHex) {
                return null;
            }
        }
        return cleaned;
    }
}
