package com.notdogshit.exoscanner.util;

import java.util.Locale;
import java.util.Set;

public final class IgnoredDyeColors {
    private static final Set<String> IGNORED = Set.of(
        "#7FFFD4",
        "#B80036",
        "#002FA7",
        "#E3DAC9",
        "#CB4154",
        "#702963",
        "#960018",
        "#ACE1AF",
        "#B2FFFF",
        "#7B3F00",
        "#B87333",
        "#F56FA1",
        "#301934",
        "#4F2A2A",
        "#50C878",
        "#E25822",
        "#866F12",
        "#09D8EB",
        "#3C6746",
        "#71A6D2",
        "#00A86B",
        "#CEB7AA",
        "#FDBE02",
        "#74A12E",
        "#50216C",
        "#967969",
        "#6F6F0C",
        "#F6ADC6",
        "#E7413C",
        "#E9FFDB",
        "#115555",
        "#50414C",
        "#CCCCFF",
        "#000000",
        "#0013FF",
        "#FFFFFF",
        "#FFF700",
        "#D40808",
        "#7D7D7D",
        "#324D6C",
        "#FCD12A",
        "#FF43A4"
    );

    private IgnoredDyeColors() {
    }

    public static boolean isIgnored(String hex) {
        String normalized = normalize(hex);
        return normalized != null && IGNORED.contains(normalized);
    }

    private static String normalize(String hex) {
        if (hex == null) {
            return null;
        }
        String cleaned = hex.trim().toUpperCase(Locale.ROOT);
        if (cleaned.isEmpty()) {
            return null;
        }
        if (!cleaned.startsWith("#")) {
            cleaned = "#" + cleaned;
        }
        if (cleaned.length() != 7) {
            return null;
        }
        return cleaned;
    }
}
