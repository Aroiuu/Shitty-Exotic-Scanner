package com.notdogshit.exoscanner.api;

import com.notdogshit.exoscanner.config.ExoScannerConfig;

public final class ApiKeyManagerTestHarness {
    private ApiKeyManagerTestHarness() {
    }

    public static void main(String[] args) {
        ExoScannerConfig config = new ExoScannerConfig();
        config.apiKeys = new String[] {"key1", "key2", "key3"};
        config.keyDailyCap = 5000;
        config.keyBurstThreshold = 3;
        config.keyBurstWindowMinutes = 5;
        config.keyCooldownMinutes = 10;

        ApiKeyManager manager = new ApiKeyManager();
        manager.updateKeys(config);
        ApiKeyManager.KeySelection sel = manager.selectKeyForAuto(config);
        if (sel == null || sel.slot != 1) {
            throw new IllegalStateException("Expected slot 1 to be selected.");
        }
        manager.recordRequest(1, config);
        manager.recordRequest(1, config);
        manager.recordRequest(1, config);
        if (!manager.isCooling(1)) {
            throw new IllegalStateException("Expected slot 1 to be cooling after burst.");
        }
        ApiKeyManager.KeySelection sel2 = manager.selectKeyForAuto(config);
        if (sel2 == null || sel2.slot == 1) {
            throw new IllegalStateException("Expected rotation to another slot.");
        }
        System.out.println("ApiKeyManagerTestHarness OK");
    }
}
