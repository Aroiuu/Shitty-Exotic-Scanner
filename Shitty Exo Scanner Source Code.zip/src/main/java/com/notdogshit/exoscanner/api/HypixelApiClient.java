package com.notdogshit.exoscanner.api;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.notdogshit.exoscanner.ExoScannerClient;
import com.notdogshit.exoscanner.armor.ArmorKeyResolver;
import com.notdogshit.exoscanner.armor.SeymourKeys;
import com.notdogshit.exoscanner.color.SeymourTierService;
import com.notdogshit.exoscanner.config.ConfigManager;
import com.notdogshit.exoscanner.db.ExoScanDatabase;
import com.notdogshit.exoscanner.db.ScanRecord;
import com.notdogshit.exoscanner.illegal.IllegalType;
import com.notdogshit.exoscanner.util.IgnoredDyeColors;
import com.notdogshit.exoscanner.whitelist.WhitelistManager;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntArrayTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtAccounter;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.NbtUtils;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;
import java.util.zip.GZIPInputStream;
import java.util.zip.InflaterInputStream;

public final class HypixelApiClient {
    // Client-side Hypixel API integration for profile/armor scans.
    private static final String MOJANG_PROFILE_URL = "https://api.mojang.com/users/profiles/minecraft/";
    private static final String[] HYPIXEL_PROFILE_URLS = new String[] {
        "https://api.hypixel.net/v2/skyblock/profiles?uuid=",
        "https://api.hypixel.net/skyblock/profiles?uuid="
    };
    private static final Pattern UUID_32 = Pattern.compile("^[0-9a-fA-F]{32}$");
    private static final Pattern UUID_36 = Pattern.compile("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");

    private final HttpClient httpClient;
    private final ConfigManager configManager;
    private final WhitelistManager whitelistManager;
    private final ExoScanDatabase database;
    private final Deque<Long> requestTimes = new ArrayDeque<>();
    private final Object requestLock = new Object();
    private static boolean nbtMethodLogged;

    public HypixelApiClient(ConfigManager configManager, WhitelistManager whitelistManager, ExoScanDatabase database) {
        // Reuse a single HttpClient and shared config/db references.
        this.httpClient = HttpClient.newHttpClient();
        this.configManager = configManager;
        this.whitelistManager = whitelistManager;
        this.database = database;
    }

    public UUID resolveUuid(String username) throws IOException, InterruptedException {
        // Mojang username -> UUID lookup (used before Hypixel profile calls).
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(MOJANG_PROFILE_URL + username))
            .GET()
            .build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            return null;
        }
        JsonObject root = JsonParser.parseString(response.body()).getAsJsonObject();
        if (!root.has("id")) {
            return null;
        }
        String raw = root.get("id").getAsString();
        return uuidFromUndashed(raw);
    }

    public ScanSummary scanProfiles(UUID uuid, String username, String apiKey) throws IOException, InterruptedException {
        // Fetch SkyBlock profiles and scan armor data using a single API key.
        HttpResponse<String> response = sendProfileRequest(uuid.toString(), apiKey, null, 0);
        if (response.statusCode() != 200) {
            throw new IOException("Hypixel API status " + response.statusCode());
        }
        return parseProfiles(response.body(), uuid, username);
    }

    public ScanSummary scanProfiles(UUID uuid, String username, String apiKey, ApiKeyManager keyManager, int keySlot)
        throws IOException, InterruptedException {
        // Same as above but records per-key usage/response data.
        HttpResponse<String> response = sendProfileRequest(uuid.toString(), apiKey, keyManager, keySlot);
        if (response.statusCode() != 200) {
            throw new IOException("Hypixel API status " + response.statusCode());
        }
        return parseProfiles(response.body(), uuid, username);
    }

    private ScanSummary parseProfiles(String body, UUID uuid, String username) throws IOException {
        // Parse profile response and scan each member inventory section.
        JsonObject root = JsonParser.parseString(body).getAsJsonObject();
        boolean success = root.has("success") && root.get("success").getAsBoolean();
        if (!success) {
            throw new IOException("Hypixel API returned success=false");
        }
        ScanSummary summary = new ScanSummary();
        if (!root.has("profiles") || root.get("profiles").isJsonNull()) {
            return summary;
        }
        JsonArray profiles = root.getAsJsonArray("profiles");
        String memberKey = uuid.toString().replace("-", "").toLowerCase(Locale.ROOT);
        for (JsonElement profileEl : profiles) {
            if (!profileEl.isJsonObject()) {
                continue;
            }
            JsonObject profile = profileEl.getAsJsonObject();
            if (!profile.has("members")) {
                continue;
            }
            JsonObject members = profile.getAsJsonObject("members");
            if (!members.has(memberKey)) {
                continue;
            }
            JsonObject member = members.getAsJsonObject(memberKey);
            scanMemberInventories(member, uuid, username, summary);
        }
        return summary;
    }

    private HttpResponse<String> sendProfileRequest(String uuid, String apiKey, ApiKeyManager keyManager, int keySlot)
        throws IOException, InterruptedException {
        // Hypixel profile endpoint with dashed/undashed UUID fallback.
        String dashed = uuid;
        String undashed = uuid.replace("-", "");
        for (String base : HYPIXEL_PROFILE_URLS) {
            HttpResponse<String> response = sendOnce(base + dashed, apiKey, keyManager, keySlot);
            ExoScannerClient.LOGGER.info("Hypixel API request: {} -> {}", base + dashed, response.statusCode());
            if (response.statusCode() != 404) {
                return response;
            }
            response = sendOnce(base + undashed, apiKey, keyManager, keySlot);
            ExoScannerClient.LOGGER.info("Hypixel API request: {} -> {}", base + undashed, response.statusCode());
            if (response.statusCode() != 404) {
                return response;
            }
        }
        return sendOnce(HYPIXEL_PROFILE_URLS[0] + dashed, apiKey, keyManager, keySlot);
    }

    private HttpResponse<String> sendOnce(String url, String apiKey, ApiKeyManager keyManager, int keySlot)
        throws IOException, InterruptedException {
        if (configManager.get().debugApiScan) {
            int len = apiKey == null ? 0 : apiKey.trim().length();
            ExoScannerClient.LOGGER.info("Hypixel API key length={} keySlot={}", len, keySlot);
        }
        HttpRequest request = HttpRequest.newBuilder()
            .uri(URI.create(url))
            .header("API-Key", apiKey)
            .GET()
            .build();
        recordApiRequest();
        if (keyManager != null && keySlot > 0) {
            keyManager.recordRequest(keySlot, configManager.get());
        }
        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (keyManager != null && keySlot > 0) {
                keyManager.recordResponse(keySlot, response.statusCode(), configManager.get());
            }
            return response;
        } catch (IOException | InterruptedException e) {
            if (keyManager != null && keySlot > 0) {
                keyManager.recordError(keySlot);
            }
            throw e;
        }
    }

    public ApiRequestStats getApiRequestStats() {
        long now = System.currentTimeMillis();
        long cutoff = now - (24L * 60L * 60L * 1000L);
        long cutoff5 = now - (5L * 60L * 1000L);
        int last5 = 0;
        int last24 = 0;
        synchronized (requestLock) {
            pruneRequests(cutoff);
            for (Long ts : requestTimes) {
                if (ts >= cutoff5) {
                    last5++;
                }
                last24++;
            }
        }
        return new ApiRequestStats(last5, last24);
    }

    // Track API call timestamps for rate/usage reporting.
    private void recordApiRequest() {
        long now = System.currentTimeMillis();
        long cutoff = now - (24L * 60L * 60L * 1000L);
        synchronized (requestLock) {
            requestTimes.addLast(now);
            pruneRequests(cutoff);
        }
    }

    private void pruneRequests(long cutoff) {
        while (!requestTimes.isEmpty()) {
            Long ts = requestTimes.peekFirst();
            if (ts == null || ts >= cutoff) {
                break;
            }
            requestTimes.removeFirst();
        }
    }

    // Scan inventory payloads for armor pieces.
    private void scanMemberInventories(JsonObject member, UUID playerUuid, String playerName, ScanSummary summary) {
        List<String> keys = List.of(
            "inv_armor",
            "inv_armor_data",
            "wardrobe",
            "wardrobe_contents",
            "inv_contents",
            "ender_chest",
            "ender_chest_contents",
            "ender_chest_inventory",
            "ender_chest_data",
            "enderchest",
            "backpack_contents",
            "backpack_contents_old",
            "backpack_contents_new",
            "backpack_contents_bag",
            "backpack_contents_rift",
            "bag_contents",
            "sacks",
            "vault",
            "personal_vault",
            "vault_contents",
            "personal_vault_contents"
        );
        scanKeys(member, keys, playerUuid, playerName, summary, "member");
        if (member.has("inventory") && member.get("inventory").isJsonObject()) {
            scanKeys(member.getAsJsonObject("inventory"), keys, playerUuid, playerName, summary, "member.inventory");
        }
    }

    // Decode base64 NBT blobs and forward each item to the handler.
    private void scanKeys(JsonObject source, List<String> keys, UUID playerUuid, String playerName, ScanSummary summary, String sourceLabel) {
        for (String key : keys) {
            if (!source.has(key) || source.get(key).isJsonNull()) {
                continue;
            }
            JsonElement element = source.get(key);
            List<String> payloads = extractBase64List(element);
            if (payloads.isEmpty()) {
                ExoScannerClient.LOGGER.info("Hypixel API inventory key {}.{} has no base64 data.", sourceLabel, key);
                continue;
            }
            for (int i = 0; i < payloads.size(); i++) {
                String base64 = payloads.get(i);
                if (base64 == null || base64.isBlank()) {
                    continue;
                }
                ExoScannerClient.LOGGER.info(
                    "Hypixel API inventory key {}.{} base64 length={} (entry {}/{})",
                    sourceLabel,
                    key,
                    base64.length(),
                    i + 1,
                    payloads.size()
                );
                List<CompoundTag> items = parseInventory(base64, sourceLabel + "." + key);
                ExoScannerClient.LOGGER.info("Hypixel API inventory key {}.{} items={}", sourceLabel, key, items.size());
                for (CompoundTag item : items) {
                    handleItem(item, playerUuid, playerName, summary);
                }
            }
        }
    }

    private static List<String> extractBase64List(JsonElement element) {
        List<String> values = new ArrayList<>();
        if (element == null || element.isJsonNull()) {
            return values;
        }
        if (element.isJsonPrimitive()) {
            values.add(element.getAsString());
            return values;
        }
        if (element.isJsonArray()) {
            JsonArray array = element.getAsJsonArray();
            for (JsonElement entry : array) {
                if (entry == null || entry.isJsonNull()) {
                    continue;
                }
                if (entry.isJsonPrimitive()) {
                    values.add(entry.getAsString());
                } else if (entry.isJsonObject()) {
                    JsonObject obj = entry.getAsJsonObject();
                    if (obj.has("data") && obj.get("data").isJsonPrimitive()) {
                        values.add(obj.get("data").getAsString());
                    }
                }
            }
            return values;
        }
        if (element.isJsonObject()) {
            JsonObject obj = element.getAsJsonObject();
            if (obj.has("data") && obj.get("data").isJsonPrimitive()) {
                values.add(obj.get("data").getAsString());
                return values;
            }
            for (Map.Entry<String, JsonElement> entry : obj.entrySet()) {
                JsonElement value = entry.getValue();
                if (value == null || value.isJsonNull()) {
                    continue;
                }
                if (value.isJsonPrimitive()) {
                    values.add(value.getAsString());
                } else if (value.isJsonObject()) {
                    JsonObject inner = value.getAsJsonObject();
                    if (inner.has("data") && inner.get("data").isJsonPrimitive()) {
                        values.add(inner.get("data").getAsString());
                    }
                }
            }
        }
        return values;
    }

    // Convert an NBT item entry into a ScanRecord when it matches rules.
    private void handleItem(CompoundTag itemTag, UUID playerUuid, String playerName, ScanSummary summary) {
        boolean debug = configManager.get().debugApiScan;
        String itemId = readString(itemTag, "id");
        if (debug) {
            ExoScannerClient.LOGGER.info(
                "API item: player={}, itemId={}, hasTag={}",
                playerName,
                itemId,
                itemTag != null && hasKey(itemTag, "tag")
            );
        }
        CompoundTag tag = getCompound(itemTag, "tag");
        if (tag == null) {
            if (debug) {
                ExoScannerClient.LOGGER.info(
                    "API skip: missing tag. player={}, itemId={}",
                    playerName,
                    itemId
                );
            }
            return;
        }
        String armorId = null;
        CompoundTag extra = getCompound(tag, "ExtraAttributes");
        if (extra != null) {
            armorId = readString(extra, "id");
            if (armorId == null) {
                armorId = readString(extra, "item_id");
            }
        }
        if (armorId == null) {
            armorId = readString(tag, "id");
        }
        boolean forceScan = SeymourKeys.isSeymourKey(armorId);
        if (!forceScan && !isLeatherItemId(itemId)) {
            if (debug) {
                ExoScannerClient.LOGGER.info(
                    "API skip: not leather. player={}, itemId={}",
                    playerName,
                    itemId
                );
            }
            return;
        }
        Integer color = readDyedColor(tag);
        if (color == null && !forceScan) {
            if (debug) {
                ExoScannerClient.LOGGER.info(
                    "API skip: no color. player={}, itemId={}",
                    playerName,
                    itemId
                );
            }
            return;
        }
        if (extra != null) {
            if (hasHypixelDye(extra, tag, debug, playerName, itemId, armorId)) {
                if (debug) {
                    ExoScannerClient.LOGGER.info(
                        "API skip: hypixel dye. player={}, itemId={}, armorId={}",
                        playerName,
                        itemId,
                        armorId
                    );
                }
                return;
            }
        }
        if (armorId == null) {
            if (debug) {
                ExoScannerClient.LOGGER.info(
                    "API skip: no armorId. player={}, itemId={}",
                    playerName,
                    itemId
                );
            }
            return;
        }
        String resolved = forceScan
            ? SeymourKeys.normalizeKey(armorId)
            : ArmorKeyResolver.resolveForWhitelist(armorId, whitelistManager);
        if (resolved == null) {
            if (debug) {
                ExoScannerClient.LOGGER.info(
                    "API skip: not in whitelist. player={}, itemId={}, armorId={}",
                    playerName,
                    itemId,
                    armorId
                );
            }
            return;
        }
        String colorHex = color == null ? "#000000" : String.format("#%06X", (0xFFFFFF & color));
        if (!forceScan && IgnoredDyeColors.isIgnored(colorHex)) {
            if (debug) {
                ExoScannerClient.LOGGER.info(
                    "API skip: ignored dye color. player={}, armorKey={}, colorHex={}",
                    playerName,
                    resolved,
                    colorHex
                );
            }
            return;
        }
        boolean willStore = forceScan || !whitelistManager.isAllowed(resolved, colorHex);
        if (!willStore) {
            if (debug) {
                ExoScannerClient.LOGGER.info(
                    "API skip: allowed color. player={}, armorKey={}, colorHex={}",
                    playerName,
                    resolved,
                    colorHex
                );
            }
            return;
        }
        if (debug) {
            ExoScannerClient.LOGGER.info(
                "API exotic: player={}, armorKey={}, colorHex={}, armorId={}, forceScan={}, armorUuid={}",
                playerName,
                resolved,
                colorHex,
                armorId,
                forceScan,
                readArmorUuid(tag)
            );
        }

        ScanRecord record = new ScanRecord();
        record.timestamp = System.currentTimeMillis();
        record.playerName = playerName;
        record.playerUuid = playerUuid;
        String armorUuid = readArmorUuid(tag);
        if (debug && willStore && (armorUuid == null || armorUuid.isBlank())) {
            ExoScannerClient.LOGGER.info(
                "API armor UUID missing. player={}, armorKey={}, armorId={}, itemId={}, hasExtraAttributes={}, tagKeys={}",
                playerName,
                resolved,
                armorId,
                itemId,
                extra != null,
                getAllKeys(tag)
            );
        }
        if (willStore && (armorUuid == null || armorUuid.isBlank())
            && configManager.get().notifyOnMissingArmorUuid) {
            Minecraft client = Minecraft.getInstance();
            if (client != null && client.player != null) {
                String message = "ExoScanner: missing armor UUID (api scan) "
                    + playerName + " " + resolved + " " + colorHex;
                client.player.displayClientMessage(Component.literal(message), false);
            }
        }
        record.armorUuid = armorUuid;
        record.armorKey = resolved;
        record.armorSetKey = deriveSetKey(resolved);
        record.pieceType = pieceTypeFromKey(resolved);
        record.colorHex = colorHex;
        record.illegalType = forceScan
            ? "SEYMOUR"
            : IllegalType.classify(colorHex, resolved).name();

        if (forceScan) {
            SeymourTierService.Settings settings = new SeymourTierService.Settings(
                76,
                true,
                true,
                true
            );
            SeymourTierService.SeymourTierResult result =
                SeymourTierService.computeTierForHex(record.colorHex, record.armorKey, settings);
            if (result != null) {
                record.seymourTier = result.tier;
                record.seymourBestDeltaE = result.bestDeltaE;
                record.seymourBestMatchName = result.bestMatchName;
                record.seymourBestMatchHex = result.bestMatchHex;
                record.seymourTierComputedAt = System.currentTimeMillis();
            }
        }

        database.appendIfNew(record);
        boolean isSeymour = SeymourKeys.isSeymourKey(record.armorKey);
        if (!isSeymour) {
            summary.totalExotics++;
        }
        summary.bySet.merge(record.armorSetKey, 1, Integer::sum);
        summary.byPiece.merge(record.armorKey, 1, Integer::sum);
        if (!isSeymour) {
            summary.byType.merge(record.illegalType, 1, Integer::sum);
        } else {
            summary.byType.merge("SEYMOUR", 1, Integer::sum);
        }
    }

    private List<CompoundTag> parseInventory(String base64, String label) {
        List<CompoundTag> items = new ArrayList<>();
        Tag rootTag = readCompressedNbt(base64);
        if (rootTag == null) {
            ExoScannerClient.LOGGER.info("Hypixel API inventory {} failed to decode NBT.", label);
            return items;
        }
        ExoScannerClient.LOGGER.info("Hypixel API inventory {} root tag type={}", label, rootTag.getClass().getName());
        if (rootTag instanceof ListTag listTag) {
            collectFromList(listTag, items);
            return items;
        }
        if (!(rootTag instanceof CompoundTag root)) {
            ExoScannerClient.LOGGER.info("Hypixel API inventory {} unsupported root tag.", label);
            return items;
        }
        ListTag list = getList(root, "i");
        if (list == null) {
            list = getList(root, "items");
        }
        if (list == null) {
            ExoScannerClient.LOGGER.info("Hypixel API inventory {} has no item list keys.", label);
            return items;
        }
        collectFromList(list, items);
        return items;
    }

    // Decode base64 NBT with legacy and fallback readers.
    private Tag readCompressedNbt(String base64) {
        try {
            byte[] data = Base64.getDecoder().decode(base64);
            try (ByteArrayInputStream input = new ByteArrayInputStream(data)) {
                return NbtIo.readCompressed(input, NbtAccounter.unlimitedHeap());
            }
        } catch (Exception e) {
            ExoScannerClient.LOGGER.warn("Failed to read Hypixel NBT payload (legacy), trying fallback.", e);
            try {
                byte[] data = Base64.getDecoder().decode(base64);
                Object fallback = readNbtFromBytes(data);
                if (fallback instanceof Tag tag) {
                    return tag;
                }
            } catch (Exception ex) {
                ExoScannerClient.LOGGER.warn("Failed to read Hypixel NBT payload (fallback).", ex);
            }
            return null;
        }
    }

    // Attempt to read NBT using multiple method signatures/encodings.
    private Object readNbtFromBytes(byte[] data) throws Exception {
        if (!nbtMethodLogged) {
            nbtMethodLogged = true;
            ExoScannerClient.LOGGER.info("NBT read: scanning declared methods for NbtIo/NbtUtils.");
        }
        Object hardwired = invokeHardwiredRead(data);
        if (hardwired != null) {
            return hardwired;
        }
        boolean gzip = isGzip(data);
        ExoScannerClient.LOGGER.info("NBT read: firstBytes={}, gzip={}", firstBytesHex(data, 8), gzip);
        if (gzip) {
            Object value = invokeObfuscatedReadCompressed(data);
            if (value != null) {
                return value;
            }
            value = invokeReadCompressed(NbtIo.class, data, Compression.GZIP);
            if (value != null) {
                return value;
            }
            value = invokeReadCompressed(NbtUtils.class, data, Compression.GZIP);
            if (value != null) {
                return value;
            }
            value = invokeReadCompressedAnyName(NbtIo.class, data, Compression.GZIP);
            if (value != null) {
                return value;
            }
            byte[] uncompressed = gunzip(data);
            if (uncompressed != null) {
                ExoScannerClient.LOGGER.info("NBT read: uncompressed firstBytes={}", firstBytesHex(uncompressed, 8));
                value = invokeReadUncompressed(NbtIo.class, uncompressed);
                if (value != null) {
                    return value;
                }
                value = invokeReadUncompressed(NbtUtils.class, uncompressed);
                if (value != null) {
                    return value;
                }
            }
        }
        Object value = invokeReadCompressed(NbtIo.class, data, Compression.RAW);
        if (value != null) {
            return value;
        }
        value = invokeReadCompressed(NbtUtils.class, data, Compression.RAW);
        if (value != null) {
            return value;
        }
        value = invokeObfuscatedReadCompressed(data);
        if (value != null) {
            return value;
        }
        value = invokeReadCompressed(NbtIo.class, data, Compression.DEFLATE);
        if (value != null) {
            return value;
        }
        value = invokeReadCompressed(NbtUtils.class, data, Compression.DEFLATE);
        if (value != null) {
            return value;
        }
        throw new NoSuchMethodException("No compatible NBT read method found.");
    }

    private Object invokeReadCompressed(Class<?> clazz, byte[] data, Compression compression) throws Exception {
        for (var method : clazz.getDeclaredMethods()) {
            if (!method.getName().equals("readCompressed")) {
                continue;
            }
            Object result = invokeMethodWithData(method, data, compression);
            if (shouldAcceptTag(result)) {
                return result;
            }
        }
        return null;
    }

    private Object invokeObfuscatedReadCompressed(byte[] data) {
        try {
            Class<?> nbtIo = Class.forName("net.minecraft.class_2507");
            Class<?> accounterClass = Class.forName("net.minecraft.class_2505");
            Object accounter = createAccounter(accounterClass);
            java.lang.reflect.Method target = findObfuscatedReadMethod(nbtIo, accounterClass);
            if (target == null) {
                ExoScannerClient.LOGGER.info("NBT read: obfuscated read method not found.");
                return null;
            }
            ExoScannerClient.LOGGER.info("NBT read: using obfuscated method {}", target.getName());
            target.setAccessible(true);
            Compression compression = isGzip(data) ? Compression.GZIP : Compression.RAW;
            try (InputBundle bundle = InputBundle.open(data, compression)) {
                Object result = target.invoke(null, bundle.inputStream, accounter);
                Object unwrapped = unwrapTagResult(result);
                if (shouldAcceptTag(unwrapped)) {
                    return unwrapped;
                }
            }
            if (compression == Compression.GZIP) {
                byte[] uncompressed = gunzip(data);
                if (uncompressed != null) {
                    ExoScannerClient.LOGGER.info("NBT read: obfuscated method retry on uncompressed bytes.");
                    try (InputBundle bundle = InputBundle.open(uncompressed, Compression.RAW)) {
                        Object result = target.invoke(null, bundle.inputStream, accounter);
                        Object unwrapped = unwrapTagResult(result);
                        if (shouldAcceptTag(unwrapped)) {
                            return unwrapped;
                        }
                    }
                }
            }
            } catch (java.lang.reflect.InvocationTargetException e) {
                Throwable cause = e.getCause();
                ExoScannerClient.LOGGER.info("NBT read: obfuscated read failed: {}",
                    cause == null ? e.toString() : (cause.getClass().getName() + ": " + cause.getMessage()));
                return null;
            } catch (Exception e) {
                ExoScannerClient.LOGGER.info("NBT read: obfuscated read failed: {}", e.toString());
                return null;
            }
        return null;
    }

    private Object invokeHardwiredRead(byte[] data) {
        try {
            Class<?> nbtIo = Class.forName("net.minecraft.class_2507");
            Class<?> accounterClass = Class.forName("net.minecraft.class_2505");
            Object accounter = createAccounter(accounterClass);
            java.lang.reflect.Method method = nbtIo.getDeclaredMethod("method_10629", java.io.InputStream.class, accounterClass);
            method.setAccessible(true);
            try (java.io.InputStream input = new java.io.ByteArrayInputStream(data)) {
                Object result = method.invoke(null, input, accounter);
                Object unwrapped = unwrapTagResult(result);
                if (shouldAcceptTag(unwrapped)) {
                    return unwrapped;
                }
            }
            if (isGzip(data)) {
                byte[] uncompressed = gunzip(data);
                if (uncompressed != null) {
                    ExoScannerClient.LOGGER.info("NBT read: hardwired retry on uncompressed bytes.");
                    try (java.io.InputStream input = new java.io.ByteArrayInputStream(uncompressed)) {
                        Object result = method.invoke(null, input, accounter);
                        Object unwrapped = unwrapTagResult(result);
                        if (shouldAcceptTag(unwrapped)) {
                            return unwrapped;
                        }
                    }
                }
            }
        } catch (java.lang.reflect.InvocationTargetException e) {
            Throwable cause = e.getCause();
            ExoScannerClient.LOGGER.info("NBT read: hardwired read failed: {}",
                cause == null ? e.toString() : (cause.getClass().getName() + ": " + cause.getMessage()));
        } catch (Exception e) {
            ExoScannerClient.LOGGER.info("NBT read: hardwired read failed: {}", e.toString());
        }
        return null;
    }

    private Object createAccounter(Class<?> accounterClass) throws Exception {
        try {
            return accounterClass.getMethod("method_53898").invoke(null);
        } catch (NoSuchMethodException ignored) {
            // fall through
        }
        for (var method : accounterClass.getDeclaredMethods()) {
            if (!java.lang.reflect.Modifier.isStatic(method.getModifiers())) {
                continue;
            }
            if (!accounterClass.isAssignableFrom(method.getReturnType())) {
                continue;
            }
            Class<?>[] params = method.getParameterTypes();
            if (params.length == 1 && (params[0] == long.class || params[0] == Long.class)) {
                method.setAccessible(true);
                return method.invoke(null, Long.MAX_VALUE);
            }
        }
        throw new NoSuchMethodException("No compatible NbtAccounter factory method found.");
    }

    private java.lang.reflect.Method findObfuscatedReadMethod(Class<?> nbtIo, Class<?> accounterClass) {
        try {
            return nbtIo.getDeclaredMethod("method_10629", java.io.InputStream.class, accounterClass);
        } catch (NoSuchMethodException ignored) {
            // fall through
        }
        for (var method : nbtIo.getDeclaredMethods()) {
            Class<?>[] params = method.getParameterTypes();
            if (params.length == 2
                && java.io.InputStream.class.isAssignableFrom(params[0])
                && accounterClass.isAssignableFrom(params[1])) {
                return method;
            }
        }
        return null;
    }

    private Object invokeReadCompressedAnyName(Class<?> clazz, byte[] data, Compression compression) throws Exception {
        for (var method : clazz.getDeclaredMethods()) {
            Class<?>[] params = method.getParameterTypes();
            if (!java.lang.reflect.Modifier.isStatic(method.getModifiers())) {
                continue;
            }
            if (!Tag.class.isAssignableFrom(method.getReturnType())) {
                continue;
            }
            if (params.length == 2
                && java.io.InputStream.class.isAssignableFrom(params[0])
                && (params[1] == NbtAccounter.class || params[1] == long.class || params[1] == Long.class)) {
                Object result = invokeMethodWithData(method, data, compression);
                if (shouldAcceptTag(result)) {
                    return result;
                }
            }
        }
        return null;
    }

    private Object invokeReadUncompressed(Class<?> clazz, byte[] data) throws Exception {
        for (var method : clazz.getDeclaredMethods()) {
            if (method.getName().equals("readCompressed")) {
                continue;
            }
            Object result = invokeMethodWithData(method, data, Compression.RAW);
            if (shouldAcceptTag(result)) {
                return result;
            }
        }
        return null;
    }

    private Object invokeMethodWithData(java.lang.reflect.Method method, byte[] data, Compression compression) throws Exception {
            Class<?>[] params = method.getParameterTypes();
            if (!java.lang.reflect.Modifier.isStatic(method.getModifiers())) {
                return null;
            }
            if (!Tag.class.isAssignableFrom(method.getReturnType())) {
                return null;
            }
            if (params.length == 1) {
                if (java.io.InputStream.class.isAssignableFrom(params[0])) {
                    method.setAccessible(true);
                    return invokeWithStream(method, data, compression, StreamKind.INPUT);
                }
                if (java.io.DataInput.class.isAssignableFrom(params[0])) {
                    method.setAccessible(true);
                    return invokeWithStream(method, data, compression, StreamKind.DATA_INPUT);
                }
                if (params[0] == byte[].class) {
                    method.setAccessible(true);
                    Object result = unwrapTagResult(method.invoke(null, data));
                    return result;
                }
            } else if (params.length == 2) {
                Object second = buildSecondParam(params[1]);
                if (second == null) {
                    return null;
                }
                if (java.io.InputStream.class.isAssignableFrom(params[0])) {
                    method.setAccessible(true);
                    return invokeWithStream(method, data, compression, StreamKind.INPUT, second);
                }
                if (java.io.DataInput.class.isAssignableFrom(params[0])) {
                    method.setAccessible(true);
                    return invokeWithStream(method, data, compression, StreamKind.DATA_INPUT, second);
                }
            }
        return null;
    }

    private enum Compression {
        RAW,
        GZIP,
        DEFLATE
    }

    private enum StreamKind {
        INPUT,
        DATA_INPUT
    }

    private Object invokeWithStream(java.lang.reflect.Method method, byte[] data, Compression compression, StreamKind kind, Object... extraArgs) throws Exception {
        try (InputBundle bundle = InputBundle.open(data, compression)) {
            Object arg = kind == StreamKind.INPUT ? bundle.inputStream : bundle.dataInput;
            Object result;
            try {
                if (extraArgs.length == 0) {
                    result = unwrapTagResult(method.invoke(null, arg));
                } else {
                    result = unwrapTagResult(method.invoke(null, arg, extraArgs[0]));
                }
            } catch (java.lang.reflect.InvocationTargetException e) {
                if (e.getCause() instanceof java.util.zip.ZipException) {
                    return null;
                }
                throw e;
            }
            return result;
        }
    }

    private static final class InputBundle implements AutoCloseable {
        private final java.io.InputStream inputStream;
        private final DataInputStream dataInput;

        private InputBundle(java.io.InputStream inputStream) {
            this.inputStream = inputStream;
            this.dataInput = new DataInputStream(inputStream);
        }

        static InputBundle open(byte[] data, Compression compression) throws IOException {
            ByteArrayInputStream raw = new ByteArrayInputStream(data);
            return switch (compression) {
                case GZIP -> new InputBundle(new GZIPInputStream(raw));
                case DEFLATE -> new InputBundle(new InflaterInputStream(raw));
                case RAW -> new InputBundle(raw);
            };
        }

        @Override
        public void close() throws IOException {
            dataInput.close();
        }
    }

    private boolean shouldAcceptTag(Object result) {
        if (result == null) {
            return false;
        }
        return result instanceof Tag;
    }

    private Object unwrapTagResult(Object value) {
        if (value == null) {
            return null;
        }
        if (value instanceof Tag) {
            return value;
        }
        if (value instanceof java.util.Optional<?> optional) {
            Object inner = optional.orElse(null);
            if (inner instanceof Tag) {
                return inner;
            }
        }
        return null;
    }

    private void collectFromList(ListTag list, List<CompoundTag> items) {
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = getCompound(list, i);
            if (entry != null) {
                items.add(entry);
            }
        }
    }

    private static String firstBytesHex(byte[] data, int count) {
        if (data == null || data.length == 0) {
            return "";
        }
        int len = Math.min(data.length, count);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < len; i++) {
            sb.append(String.format("%02X", data[i]));
            if (i + 1 < len) {
                sb.append(" ");
            }
        }
        return sb.toString();
    }

    private static boolean isGzip(byte[] data) {
        return data != null
            && data.length >= 2
            && (data[0] == (byte) 0x1F)
            && (data[1] == (byte) 0x8B);
    }

    private static byte[] gunzip(byte[] data) {
        try (ByteArrayInputStream raw = new ByteArrayInputStream(data);
             GZIPInputStream gzipIn = new GZIPInputStream(raw)) {
            return gzipIn.readAllBytes();
        } catch (IOException e) {
            return null;
        }
    }

    private Object buildSecondParam(Class<?> type) {
        try {
            if (type == NbtAccounter.class) {
                return NbtAccounter.unlimitedHeap();
            }
            if (type == long.class || type == Long.class) {
                return Long.MAX_VALUE;
            }
            var method = type.getMethod("unlimitedHeap");
            return method.invoke(null);
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    private static Integer readDyedColor(CompoundTag tag) {
        CompoundTag display = getCompound(tag, "display");
        if (display == null) {
            Integer fallback = readRgbStringFromTag(tag);
            if (fallback != null) {
                return fallback;
            }
            CompoundTag extra = getCompound(tag, "ExtraAttributes");
            if (extra != null) {
                return readRgbStringFromTag(extra);
            }
            return null;
        }
        Integer color = getInt(display, "color");
        if (color != null) {
            return color;
        }
        Tag raw = getTagByKey(display, "color");
        if (raw != null) {
            String rawText = readTagString(raw);
            Integer parsed = parseLegacyNumericId(rawText);
            if (parsed != null) {
                return parsed;
            }
            parsed = parseRgbString(rawText);
            if (parsed != null) {
                return parsed;
            }
        }
        Integer fallback = readRgbStringFromTag(tag);
        if (fallback != null) {
            return fallback;
        }
        CompoundTag extra = getCompound(tag, "ExtraAttributes");
        if (extra != null) {
            return readRgbStringFromTag(extra);
        }
        return null;
    }

    private static Integer readRgbStringFromTag(CompoundTag tag) {
        if (tag == null) {
            return null;
        }
        Tag raw = getTagByKey(tag, "color");
        if (raw == null) {
            return null;
        }
        String rawText = readTagString(raw);
        if (rawText == null) {
            return null;
        }
        Integer parsed = parseRgbString(rawText);
        if (parsed != null) {
            return parsed;
        }
        return parseLegacyNumericId(rawText);
    }

    private static Integer parseRgbString(String value) {
        if (value == null) {
            return null;
        }
        String cleaned = value.trim();
        String[] parts = cleaned.split("[,: ]+");
        if (parts.length != 3) {
            return null;
        }
        try {
            int r = Integer.parseInt(parts[0].trim());
            int g = Integer.parseInt(parts[1].trim());
            int b = Integer.parseInt(parts[2].trim());
            r = clampColor(r);
            g = clampColor(g);
            b = clampColor(b);
            return (r << 16) | (g << 8) | b;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static int clampColor(int value) {
        if (value < 0) {
            return 0;
        }
        if (value > 255) {
            return 255;
        }
        return value;
    }

    private static boolean hasHypixelDye(CompoundTag extra, CompoundTag tag, boolean debug, String playerName, String itemId, String armorId) {
        String dyeItem = readString(extra, "dye_item");
        if (dyeItem == null || !dyeItem.toUpperCase(Locale.ROOT).startsWith("DYE_")) {
            return false;
        }
        CompoundTag display = getCompound(tag, "display");
        boolean markerFound = false;
        if (display != null) {
            String name = readString(display, "Name");
            if (containsDyedMarker(name)) {
                markerFound = true;
            } else {
                for (String line : readLoreLines(display)) {
                    if (containsDyedMarker(line)) {
                        markerFound = true;
                        break;
                    }
                }
            }
        }
        if (!markerFound && debug) {
            ExoScannerClient.LOGGER.info(
                "API dye_item present but no marker. player={}, itemId={}, armorId={}, dyeItem={}",
                playerName,
                itemId,
                armorId,
                dyeItem
            );
        }
        return true;
    }

    private static String readString(CompoundTag tag, String key) {
        Tag value = getTagByKey(tag, key);
        return value == null ? null : readTagString(value);
    }

    private static String readArmorUuid(CompoundTag tag) {
        String uuid = readUuidFromTag(tag);
        if (uuid != null) {
            return uuid;
        }
        CompoundTag extra = getCompound(tag, "ExtraAttributes");
        if (extra != null) {
            return readUuidFromTag(extra);
        }
        return null;
    }

    private static String readUuidFromTag(CompoundTag nbt) {
        if (nbt == null) {
            return null;
        }
        for (String key : new String[] {
            "uuid", "UUID", "id", "Id", "item_uuid", "itemUUID", "ItemUUID",
            "uniqueId", "unique_id", "itemId", "item_id"
        }) {
            Tag tag = getTagByKey(nbt, key);
            if (tag == null) {
                continue;
            }
            String value = readTagString(tag);
            String normalized = normalizeUuidString(value);
            if (normalized != null) {
                return normalized;
            }
            if (tag instanceof IntArrayTag intArrayTag) {
                int[] arr = intArrayTag.getAsIntArray();
                if (arr.length == 4) {
                    long most = ((long) arr[0] << 32) | (arr[1] & 0xFFFFFFFFL);
                    long least = ((long) arr[2] << 32) | (arr[3] & 0xFFFFFFFFL);
                    return new java.util.UUID(most, least).toString();
                }
            } else if (tag instanceof CompoundTag compoundTag) {
                Long most = readLong(compoundTag, "Most");
                Long least = readLong(compoundTag, "Least");
                if (most != null && least != null) {
                    return new java.util.UUID(most, least).toString();
                }
            }
        }
        return null;
    }

    private static String normalizeUuidString(String value) {
        if (value == null) {
            return null;
        }
        String cleaned = value.trim();
        if (cleaned.isEmpty()) {
            return null;
        }
        if (UUID_36.matcher(cleaned).matches()) {
            try {
                return UUID.fromString(cleaned).toString();
            } catch (IllegalArgumentException ignored) {
                return null;
            }
        }
        if (UUID_32.matcher(cleaned).matches()) {
            String dashed = cleaned.substring(0, 8) + "-" +
                cleaned.substring(8, 12) + "-" +
                cleaned.substring(12, 16) + "-" +
                cleaned.substring(16, 20) + "-" +
                cleaned.substring(20);
            try {
                return UUID.fromString(dashed).toString();
            } catch (IllegalArgumentException ignored) {
                return null;
            }
        }
        return null;
    }

    private static List<String> readLoreLines(CompoundTag display) {
        List<String> lines = new ArrayList<>();
        ListTag loreList = getList(display, "Lore");
        if (loreList == null) {
            return lines;
        }
        for (int i = 0; i < loreList.size(); i++) {
            Tag tag = loreList.get(i);
            if (tag != null) {
                String line = readTagString(tag);
                if (line != null) {
                    lines.add(line);
                }
            }
        }
        return lines;
    }

    private static boolean containsDyedMarker(String text) {
        if (text == null || text.isBlank()) {
            return false;
        }
        String cleaned = stripFormatting(text);
        return cleaned.toLowerCase(Locale.ROOT).contains("dyed");
    }

    private static String stripFormatting(String text) {
        if (text == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder(text.length());
        boolean skipNext = false;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (skipNext) {
                skipNext = false;
                continue;
            }
            if (c == '\u00A7') {
                skipNext = true;
                continue;
            }
            sb.append(c);
        }
        return sb.toString();
    }

    private static boolean isLeatherItemId(String itemId) {
        if (itemId == null || itemId.isBlank()) {
            return false;
        }
        String lower = itemId.toLowerCase(Locale.ROOT);
        if (lower.contains("leather")) {
            return true;
        }
        Integer numeric = parseLegacyNumericId(itemId);
        if (numeric == null) {
            return false;
        }
        return numeric == 298 || numeric == 299 || numeric == 300 || numeric == 301;
    }

    private static Integer parseLegacyNumericId(String value) {
        if (value == null) {
            return null;
        }
        String digits = value.replaceAll("[^0-9-]", "");
        if (digits.isEmpty() || "-".equals(digits)) {
            return null;
        }
        try {
            return Integer.parseInt(digits);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static CompoundTag getCompound(CompoundTag tag, String key) {
        if (tag == null || key == null) {
            return null;
        }
        Tag value = getTagByKey(tag, key);
        return value instanceof CompoundTag compound ? compound : null;
    }

    private static CompoundTag getCompound(ListTag list, int index) {
        if (list == null || index < 0 || index >= list.size()) {
            return null;
        }
        Tag value = list.get(index);
        return value instanceof CompoundTag compound ? compound : null;
    }

    private static Tag getTagByKey(CompoundTag tag, String key) {
        if (tag == null) {
            return null;
        }
        Object value = tag.get(key);
        Tag direct = unwrapOptional(value, Tag.class);
        return direct;
    }

    private static ListTag getList(CompoundTag tag, String key) {
        if (tag == null || key == null) {
            return null;
        }
        Tag value = getTagByKey(tag, key);
        return value instanceof ListTag list ? list : null;
    }

    private static Integer getInt(CompoundTag tag, String key) {
        if (tag == null || key == null) {
            return null;
        }
        try {
            Object value = tag.getClass().getMethod("getInt", String.class).invoke(tag, key);
            return unwrapOptional(value, Integer.class);
        } catch (ReflectiveOperationException e) {
            Tag raw = getTagByKey(tag, key);
            if (raw == null) {
                return null;
            }
            String rawText = readTagString(raw);
            return parseLegacyNumericId(rawText);
        }
    }

    private static Long readLong(CompoundTag tag, String key) {
        if (tag == null || key == null) {
            return null;
        }
        try {
            Object value = tag.getClass().getMethod("getLong", String.class).invoke(tag, key);
            return unwrapOptional(value, Long.class);
        } catch (ReflectiveOperationException ignored) {
            return null;
        }
    }

    private static <T> T unwrapOptional(Object value, Class<T> type) {
        if (value == null) {
            return null;
        }
        if (type.isInstance(value)) {
            return type.cast(value);
        }
        if (value instanceof java.util.Optional<?> optional) {
            Object inner = optional.orElse(null);
            if (type.isInstance(inner)) {
                return type.cast(inner);
            }
        }
        return null;
    }

    private static boolean hasKey(CompoundTag tag, String key) {
        if (tag == null || key == null) {
            return false;
        }
        return getTagByKey(tag, key) != null;
    }

    private static String readTagString(Tag tag) {
        try {
            var method = tag.getClass().getMethod("getAsString");
            Object value = method.invoke(tag);
            return value == null ? null : value.toString();
        } catch (ReflectiveOperationException ignored) {
            String fallback = tag.toString();
            if (fallback == null) {
                return null;
            }
            return fallback.replace("\"", "");
        }
    }

    private static String pieceTypeFromKey(String armorKey) {
        if (armorKey.endsWith("_HELMET")) {
            return "HELMET";
        }
        if (armorKey.endsWith("_CHESTPLATE")) {
            return "CHESTPLATE";
        }
        if (armorKey.endsWith("_LEGGINGS")) {
            return "LEGGINGS";
        }
        if (armorKey.endsWith("_BOOTS")) {
            return "BOOTS";
        }
        return "UNKNOWN";
    }

    private static String deriveSetKey(String armorKey) {
        if (armorKey.endsWith("_HELMET")) {
            return armorKey.substring(0, armorKey.length() - "_HELMET".length());
        }
        if (armorKey.endsWith("_CHESTPLATE")) {
            return armorKey.substring(0, armorKey.length() - "_CHESTPLATE".length());
        }
        if (armorKey.endsWith("_LEGGINGS")) {
            return armorKey.substring(0, armorKey.length() - "_LEGGINGS".length());
        }
        if (armorKey.endsWith("_BOOTS")) {
            return armorKey.substring(0, armorKey.length() - "_BOOTS".length());
        }
        return armorKey;
    }

    private static UUID uuidFromUndashed(String undashed) {
        if (undashed == null || undashed.length() != 32) {
            return null;
        }
        String withDashes = undashed.substring(0, 8) + "-" +
            undashed.substring(8, 12) + "-" +
            undashed.substring(12, 16) + "-" +
            undashed.substring(16, 20) + "-" +
            undashed.substring(20);
        return UUID.fromString(withDashes);
    }

    public static final class ScanSummary {
        public int totalExotics;
        public final Map<String, Integer> bySet = new HashMap<>();
        public final Map<String, Integer> byPiece = new HashMap<>();
        public final Map<String, Integer> byType = new HashMap<>();
    }

    public static final class ApiRequestStats {
        public final int last5Minutes;
        public final int last24Hours;

        public ApiRequestStats(int last5Minutes, int last24Hours) {
            this.last5Minutes = last5Minutes;
            this.last24Hours = last24Hours;
        }
    }

    private static java.util.Set<String> getAllKeys(CompoundTag tag) {
        try {
            var method = tag.getClass().getMethod("getAllKeys");
            Object value = method.invoke(tag);
            if (value instanceof java.util.Set<?> set) {
                java.util.Set<String> keys = new java.util.HashSet<>();
                for (Object entry : set) {
                    if (entry != null) {
                        String raw = entry.toString();
                        int eq = raw.indexOf('=');
                        keys.add(eq > 0 ? raw.substring(0, eq) : raw);
                    }
                }
                return keys;
            }
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        try {
            var method = tag.getClass().getMethod("getKeys");
            Object value = method.invoke(tag);
            if (value instanceof java.util.Set<?> set) {
                java.util.Set<String> keys = new java.util.HashSet<>();
                for (Object entry : set) {
                    if (entry != null) {
                        String raw = entry.toString();
                        int eq = raw.indexOf('=');
                        keys.add(eq > 0 ? raw.substring(0, eq) : raw);
                    }
                }
                return keys;
            }
        } catch (ReflectiveOperationException ignored) {
            // fall through
        }
        for (var method : tag.getClass().getDeclaredMethods()) {
            Class<?>[] params = method.getParameterTypes();
            if (params.length == 0 && java.util.Set.class.isAssignableFrom(method.getReturnType())) {
                try {
                    method.setAccessible(true);
                    Object value = method.invoke(tag);
                    if (value instanceof java.util.Set<?> set) {
                        java.util.Set<String> keys = new java.util.HashSet<>();
                        for (Object entry : set) {
                            if (entry != null) {
                                String raw = entry.toString();
                                int eq = raw.indexOf('=');
                                keys.add(eq > 0 ? raw.substring(0, eq) : raw);
                            }
                        }
                        return keys;
                    }
                } catch (ReflectiveOperationException ignored) {
                    // keep searching
                }
            }
        }
        return java.util.Set.of();
    }
}
