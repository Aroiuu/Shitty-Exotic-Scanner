package com.notdogshit.exoscanner.api;

import com.notdogshit.exoscanner.ExoScannerClient;
import com.notdogshit.exoscanner.config.ExoScannerConfig;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;

public final class ApiKeyManager {
    // Tracks multiple API keys with per-key usage and cooldown windows.
    public enum KeyState {
        OK,
        COOLING,
        PAUSED,
        CAPPED,
        MISSING
    }

    public static final class KeyStatus {
        public final int slot;
        public final boolean present;
        public final int count5m;
        public final int count24h;
        public final KeyState state;
        public final long cooldownUntil;
        public final long pausedUntil;

        private KeyStatus(int slot, boolean present, int count5m, int count24h, KeyState state,
                          long cooldownUntil, long pausedUntil) {
            this.slot = slot;
            this.present = present;
            this.count5m = count5m;
            this.count24h = count24h;
            this.state = state;
            this.cooldownUntil = cooldownUntil;
            this.pausedUntil = pausedUntil;
        }
    }

    public static final class KeySelection {
        public final int slot;
        public final String key;

        private KeySelection(int slot, String key) {
            this.slot = slot;
            this.key = key;
        }

        public static KeySelection of(int slot, String key) {
            return new KeySelection(slot, key);
        }
    }

    private static final class KeyData {
        String key = "";
        final Deque<Long> last5m = new ArrayDeque<>();
        final Deque<Long> last24h = new ArrayDeque<>();
        long cooldownUntil;
        long pausedUntil;
        long lastErrorAt;
        int lastErrorCode;
    }

    private final KeyData[] slots = new KeyData[] {new KeyData(), new KeyData(), new KeyData()};
    private boolean usageLoaded;

    public ApiKeyManager() {
    }

    public synchronized void updateKeys(ExoScannerConfig config) {
        // Pull latest keys from config and load usage snapshots once.
        if (config == null) {
            return;
        }
        if (!usageLoaded) {
            loadUsage(config);
            usageLoaded = true;
        }
        String[] keys = config.apiKeys == null ? new String[] {"", "", ""} : config.apiKeys;
        for (int i = 0; i < slots.length; i++) {
            String next = i < keys.length && keys[i] != null ? keys[i].trim() : "";
            if (!next.equals(slots[i].key)) {
                slots[i].key = next;
                slots[i].last5m.clear();
                slots[i].last24h.clear();
                slots[i].cooldownUntil = 0L;
                slots[i].pausedUntil = 0L;
                slots[i].lastErrorAt = 0L;
                slots[i].lastErrorCode = 0;
            }
        }
    }

    public synchronized KeySelection selectKeyForAuto(ExoScannerConfig config) {
        return selectKey(config, true);
    }

    public synchronized KeySelection selectKeyForManual(ExoScannerConfig config) {
        return selectKey(config, false);
    }

    private KeySelection selectKey(ExoScannerConfig config, boolean enforceCaps) {
        updateKeys(config);
        long now = System.currentTimeMillis();
        int dailyCap = config == null ? 5000 : config.keyDailyCap;
        KeySelection best = null;
        int best5 = Integer.MAX_VALUE;
        int best24 = Integer.MAX_VALUE;
        long bestError = Long.MAX_VALUE;
        for (int i = 0; i < slots.length; i++) {
            KeyData data = slots[i];
            if (data.key == null || data.key.isBlank()) {
                continue;
            }
            trim(data, now);
            if (enforceCaps && isCapped(data, dailyCap, now)) {
                continue;
            }
            if (now < data.pausedUntil || now < data.cooldownUntil) {
                continue;
            }
            int c5 = data.last5m.size();
            int c24 = data.last24h.size();
            long err = data.lastErrorAt == 0 ? Long.MAX_VALUE : data.lastErrorAt;
            if (c5 < best5 || (c5 == best5 && c24 < best24) || (c5 == best5 && c24 == best24 && err < bestError)) {
                best = new KeySelection(i + 1, data.key);
                best5 = c5;
                best24 = c24;
                bestError = err;
            }
        }
        if (config != null && config.debugApiScan) {
            if (best == null) {
                ExoScannerClient.LOGGER.info("ApiKeyManager: no key available (enforceCaps={}).", enforceCaps);
            } else {
                ExoScannerClient.LOGGER.info(
                    "ApiKeyManager: selected slot={} 5m={} 24h={} enforceCaps={}",
                    best.slot, best5, best24, enforceCaps
                );
            }
        }
        return best;
    }

    // Record a request timestamp for a given key slot.
    public synchronized void recordRequest(int slot, ExoScannerConfig config) {
        KeyData data = getSlot(slot);
        if (data == null) {
            return;
        }
        long now = System.currentTimeMillis();
        data.last5m.addLast(now);
        data.last24h.addLast(now);
        trim(data, now);
        if (config != null && isCapped(data, config.keyDailyCap, now)) {
            long nextClear = nextClearTime(data, 24L * 60L * 60L * 1000L);
            data.pausedUntil = Math.max(data.pausedUntil, nextClear);
            if (config.debugApiScan) {
                ExoScannerClient.LOGGER.info(
                    "ApiKeyManager: slot {} capped (24h={}/{}), pausedUntil={}",
                    slot, data.last24h.size(), config.keyDailyCap, data.pausedUntil
                );
            }
        }
        if (config != null) {
            int threshold = config.keyBurstThreshold;
            int windowMinutes = config.keyBurstWindowMinutes;
            if (threshold > 0 && windowMinutes > 0 && data.last5m.size() >= threshold) {
                data.cooldownUntil = Math.max(data.cooldownUntil, now + (long) config.keyCooldownMinutes * 60_000L);
                if (config.debugApiScan) {
                    ExoScannerClient.LOGGER.info(
                        "ApiKeyManager: slot {} cooling (5m={} threshold={}) cooldownUntil={}",
                        slot, data.last5m.size(), threshold, data.cooldownUntil
                    );
                }
            }
        }
    }

    // Update per-key state based on HTTP response codes.
    public synchronized void recordResponse(int slot, int statusCode, ExoScannerConfig config) {
        KeyData data = getSlot(slot);
        if (data == null) {
            return;
        }
        long now = System.currentTimeMillis();
        if (statusCode == 429) {
            data.pausedUntil = Math.max(data.pausedUntil, now + 10L * 60_000L);
        } else if (statusCode == 403) {
            data.pausedUntil = Math.max(data.pausedUntil, now + 24L * 60L * 60L * 1000L);
        } else if (statusCode >= 500) {
            data.pausedUntil = Math.max(data.pausedUntil, now + 90_000L);
        }
        data.lastErrorAt = now;
        data.lastErrorCode = statusCode;
        if (config != null && isCapped(data, config.keyDailyCap, now)) {
            long nextClear = nextClearTime(data, 24L * 60L * 60L * 1000L);
            data.pausedUntil = Math.max(data.pausedUntil, nextClear);
        }
        if (config != null && config.debugApiScan) {
            ExoScannerClient.LOGGER.info(
                "ApiKeyManager: slot {} response status={} pausedUntil={}",
                slot, statusCode, data.pausedUntil
            );
        }
    }

    public synchronized void recordError(int slot) {
        KeyData data = getSlot(slot);
        if (data == null) {
            return;
        }
        long now = System.currentTimeMillis();
        data.lastErrorAt = now;
        data.lastErrorCode = -1;
        data.pausedUntil = Math.max(data.pausedUntil, now + 90_000L);
        ExoScannerClient.LOGGER.info("ApiKeyManager: slot {} error, pausedUntil={}", slot, data.pausedUntil);
    }

    public synchronized void clearPauses() {
        long now = System.currentTimeMillis();
        for (int i = 0; i < slots.length; i++) {
            KeyData data = slots[i];
            if (data == null) {
                continue;
            }
            if (data.pausedUntil > 0L) {
                data.pausedUntil = 0L;
                if (data.cooldownUntil < now) {
                    data.cooldownUntil = 0L;
                }
                data.lastErrorAt = 0L;
                data.lastErrorCode = 0;
            }
        }
    }

    // Persist key usage counters into config for next session.
    public synchronized void exportUsage(ExoScannerConfig config) {
        if (config == null) {
            return;
        }
        long now = System.currentTimeMillis();
        List<List<Long>> out5m = new ArrayList<>();
        List<List<Long>> out24h = new ArrayList<>();
        for (KeyData data : slots) {
            trim(data, now);
            out5m.add(new ArrayList<>(data.last5m));
            out24h.add(new ArrayList<>(data.last24h));
        }
        config.apiKeyLast5m = out5m;
        config.apiKeyLast24h = out24h;
    }

    public synchronized boolean isCooling(int slot) {
        KeyData data = getSlot(slot);
        if (data == null) {
            return false;
        }
        long now = System.currentTimeMillis();
        return now < data.cooldownUntil;
    }

    public synchronized List<KeyStatus> getStatuses(ExoScannerConfig config) {
        updateKeys(config);
        long now = System.currentTimeMillis();
        List<KeyStatus> out = new ArrayList<>();
        for (int i = 0; i < slots.length; i++) {
            KeyData data = slots[i];
            boolean present = data.key != null && !data.key.isBlank();
            trim(data, now);
            KeyState state = KeyState.OK;
            if (!present) {
                state = KeyState.MISSING;
            } else if (config != null && isCapped(data, config.keyDailyCap, now)) {
                state = KeyState.CAPPED;
            } else if (now < data.pausedUntil) {
                state = KeyState.PAUSED;
            } else if (now < data.cooldownUntil) {
                state = KeyState.COOLING;
            }
            out.add(new KeyStatus(i + 1, present, data.last5m.size(), data.last24h.size(), state,
                data.cooldownUntil, data.pausedUntil));
        }
        return out;
    }

    public synchronized boolean allKeysExhausted(ExoScannerConfig config) {
        updateKeys(config);
        long now = System.currentTimeMillis();
        int dailyCap = config == null ? 5000 : config.keyDailyCap;
        for (KeyData data : slots) {
            if (data.key == null || data.key.isBlank()) {
                continue;
            }
            trim(data, now);
            if (now < data.pausedUntil || now < data.cooldownUntil) {
                continue;
            }
            if (!isCapped(data, dailyCap, now)) {
                return false;
            }
        }
        return true;
    }

    private KeyData getSlot(int slot) {
        int index = slot - 1;
        if (index < 0 || index >= slots.length) {
            return null;
        }
        return slots[index];
    }

    private static boolean isCapped(KeyData data, int dailyCap, long now) {
        if (dailyCap <= 0) {
            return false;
        }
        trim(data, now);
        return data.last24h.size() >= dailyCap;
    }

    private static long nextClearTime(KeyData data, long windowMillis) {
        Long oldest = data.last24h.peekFirst();
        if (oldest == null) {
            return System.currentTimeMillis() + 60_000L;
        }
        return oldest + windowMillis;
    }

    private static void trim(KeyData data, long now) {
        long cutoff5 = now - 5L * 60L * 1000L;
        while (!data.last5m.isEmpty()) {
            Long ts = data.last5m.peekFirst();
            if (ts == null || ts >= cutoff5) {
                break;
            }
            data.last5m.removeFirst();
        }
        long cutoff24 = now - 24L * 60L * 60L * 1000L;
        while (!data.last24h.isEmpty()) {
            Long ts = data.last24h.peekFirst();
            if (ts == null || ts >= cutoff24) {
                break;
            }
            data.last24h.removeFirst();
        }
    }

    // Restore key usage counters from config.
    private void loadUsage(ExoScannerConfig config) {
        long now = System.currentTimeMillis();
        List<List<Long>> in5m = config.apiKeyLast5m;
        List<List<Long>> in24h = config.apiKeyLast24h;
        for (int i = 0; i < slots.length; i++) {
            KeyData data = slots[i];
            data.last5m.clear();
            data.last24h.clear();
            if (in5m != null && i < in5m.size()) {
                List<Long> values = in5m.get(i);
                if (values != null) {
                    for (Long ts : values) {
                        if (ts != null && ts > 0) {
                            data.last5m.addLast(ts);
                        }
                    }
                }
            }
            if (in24h != null && i < in24h.size()) {
                List<Long> values = in24h.get(i);
                if (values != null) {
                    for (Long ts : values) {
                        if (ts != null && ts > 0) {
                            data.last24h.addLast(ts);
                        }
                    }
                }
            }
            trim(data, now);
        }
    }
}
