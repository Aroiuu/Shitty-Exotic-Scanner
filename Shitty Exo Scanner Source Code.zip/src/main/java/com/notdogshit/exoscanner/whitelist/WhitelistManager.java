package com.notdogshit.exoscanner.whitelist;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.notdogshit.exoscanner.ExoScannerClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class WhitelistManager {
    // Load/save whitelist of allowed armor keys and dye colors.
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String FILE_NAME = "exoticarmorwhitelist.json";
    private static final Type MAP_TYPE = new TypeToken<Map<String, Set<String>>>() {}.getType();

    private final Path whitelistPath;
    private Map<String, Set<String>> whitelist = new HashMap<>();

    public WhitelistManager() {
        this.whitelistPath = FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
    }

    public void loadOrCreate() {
        // Seed defaults if missing, then reload from disk.
        if (!Files.exists(whitelistPath)) {
            seedDefaultWhitelist();
        }
        reload();
    }

    public boolean isAllowed(String armorKey, String colorHex) {
        // Check if the specific armor key + color is allowed.
        Set<String> allowed = whitelist.getOrDefault(armorKey, Collections.emptySet());
        if (allowed.isEmpty()) {
            return false;
        }
        return allowed.contains(normalizeHex(colorHex));
    }

    public boolean hasArmorKey(String armorKey) {
        return whitelist.containsKey(armorKey);
    }

    public Set<String> getArmorKeys() {
        return new HashSet<>(whitelist.keySet());
    }

    public String resolveArmorKey(String armorKey) {
        // Resolve raw armor id to a whitelist key (including suffix matches).
        if (armorKey == null || armorKey.isBlank()) {
            return null;
        }
        String direct = resolvePieceSynonym(armorKey);
        if (direct != null && whitelist.containsKey(direct)) {
            return direct;
        }
        if (whitelist.containsKey(armorKey)) {
            return armorKey;
        }
        String best = null;
        for (String key : whitelist.keySet()) {
            if (armorKey.endsWith(key) && (best == null || key.length() > best.length())) {
                best = key;
                continue;
            }
            if (direct != null && direct.endsWith(key) && (best == null || key.length() > best.length())) {
                best = key;
            }
        }
        return best;
    }

    private static String resolvePieceSynonym(String armorKey) {
        if (armorKey.endsWith("_LEGGINGS")) {
            return armorKey.substring(0, armorKey.length() - "_LEGGINGS".length()) + "_PANTS";
        }
        if (armorKey.endsWith("_PANTS")) {
            return armorKey.substring(0, armorKey.length() - "_PANTS".length()) + "_LEGGINGS";
        }
        return null;
    }

    public void reload() {
        if (Files.exists(whitelistPath)) {
            try (Reader reader = Files.newBufferedReader(whitelistPath)) {
                Map<String, Set<String>> loaded = GSON.fromJson(reader, MAP_TYPE);
                if (loaded != null) {
                    whitelist = normalize(loaded);
                    return;
                }
            } catch (IOException e) {
                ExoScannerClient.LOGGER.warn("Failed to read whitelist, keeping previous version.", e);
                return;
            }
        }
        whitelist = new HashMap<>();
    }

    public void save() {
        try (Writer writer = Files.newBufferedWriter(whitelistPath)) {
            GSON.toJson(whitelist, writer);
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to write whitelist.", e);
        }
    }

    private void seedDefaultWhitelist() {
        try {
            Files.createDirectories(whitelistPath.getParent());
            try (var input = WhitelistManager.class.getResourceAsStream("/" + FILE_NAME)) {
                if (input == null) {
                    return;
                }
                Files.copy(input, whitelistPath);
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to seed whitelist.", e);
        }
    }

    private static Map<String, Set<String>> normalize(Map<String, Set<String>> input) {
        Map<String, Set<String>> out = new HashMap<>();
        for (Map.Entry<String, Set<String>> entry : input.entrySet()) {
            if (entry.getKey() == null) {
                continue;
            }
            String key = entry.getKey().trim().toUpperCase(Locale.ROOT);
            Set<String> colors = new HashSet<>();
            if (entry.getValue() != null) {
                for (String color : entry.getValue()) {
                    if (color == null || color.trim().isEmpty()) {
                        continue;
                    }
                    colors.add(normalizeHex(color));
                }
            }
            out.put(key, colors);
        }
        return out;
    }

    private static String normalizeHex(String hex) {
        String cleaned = hex.trim().toUpperCase(Locale.ROOT);
        if (!cleaned.startsWith("#")) {
            cleaned = "#" + cleaned;
        }
        return cleaned;
    }
}
