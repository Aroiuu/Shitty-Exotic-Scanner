package com.notdogshit.exoscanner.config;

public enum InventoryHighlightStyle {
    TRANSLUCENT,
    BORDER,
    BOTH
}
