package com.notdogshit.exoscanner.config;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class ExoScannerConfig {
    // Persisted config values (serialized to JSON).
    public boolean enableScanning = true;
    public int scanInterval = 5;

    public Set<String> enabledPieceTypes = new HashSet<>();
    public Set<String> enabledArmorSets = new HashSet<>();

    public boolean notifyOnExotic = false;
    public boolean notifyOnOwnerTransfer = false;
    public int defaultMetric = 2000;
    public int defaultRetentionDays = 30;
    public String dbPath = "";
    public boolean debugArmorScan = false;
    public boolean debugApiScan = false;
    public boolean debugLobbyScan = false;
    public boolean debugTrace = false;
    public boolean notifyOnMissingArmorUuid = false;

    // Player tracing (client-side).
    public boolean enablePlayerTracking = false;
    public double tracerLineWidth = 2.0;
    public int tracerLineColor = 0xFF3333;
    public double tracerAutoDisableRadius = 5.0;
    public double tracerLineOffset = 0.1;
    public boolean enableAutoTrace = false;
    public List<String> autoTracePlayers = new ArrayList<>();
    public int autoTraceMaxTargets = 3;

    // Auto lobby scan
    public boolean enableAutoLobbyScan = false;
    public boolean autoScanOnLobbySwitch = true;
    public boolean autoScanEvery5Minutes = false;
    public int autoScanDebounceSeconds = 6;
    public int autoScanMinGapSeconds = 75;
    public int autoScanJitterMillis = 750;
    public int autoScanMaxRequestsPerScan = 300;
    public int autoScanMaxPlayersPerScan = 200;

    // Hypixel API key rotation and limits.
    public String[] apiKeys = new String[] {"", "", ""};
    public int keyDailyCap = 5000;
    public int keyBurstThreshold = 300;
    public int keyBurstWindowMinutes = 5;
    public int keyCooldownMinutes = 10;
    public int autoPauseMinutesOnAllKeysExhausted = 30;
    public List<List<Long>> apiKeyLast5m = new ArrayList<>();
    public List<List<Long>> apiKeyLast24h = new ArrayList<>();

    // Legacy fields kept for migration
    public boolean scanningEnabled = true;
    public int scanIntervalSeconds = 5;
    public boolean debugScanAllLeather = false;
    public boolean debugLogging = false;
    public boolean useCie76 = false;

    public String apiKey = "";
    public int lobbyCacheDays = 30;
    public boolean enablePlayerCache = true;
    public boolean enableInventoryHighlight = true;
    public InventoryHighlightStyle inventoryHighlightStyle = InventoryHighlightStyle.TRANSLUCENT;
    public int inventoryHighlightColor = 0xFF5555;
}
