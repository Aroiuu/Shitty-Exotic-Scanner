package com.notdogshit.exoscanner.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.notdogshit.exoscanner.ExoScannerClient;
import com.notdogshit.exoscanner.color.ColorReferenceManager;
import com.notdogshit.exoscanner.color.SeymourTierService;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public final class ConfigManager {
    // Load/save config JSON and normalize defaults/migrations.
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String CONFIG_FILE = "exoscanner.json";

    private final Path configPath;
    private ExoScannerConfig config;

    public ConfigManager() {
        this.configPath = FabricLoader.getInstance().getConfigDir().resolve(CONFIG_FILE);
    }

    public ExoScannerConfig loadOrCreate() {
        // Load config or create a fresh one if missing/corrupt.
        if (Files.exists(configPath)) {
            try (Reader reader = Files.newBufferedReader(configPath)) {
                config = GSON.fromJson(reader, ExoScannerConfig.class);
            } catch (IOException e) {
                ExoScannerClient.LOGGER.warn("Failed to read config, using defaults.", e);
                config = new ExoScannerConfig();
            }
        } else {
            config = new ExoScannerConfig();
            save();
        }
        ensureDefaultColors();
        normalize();
        return config;
    }

    public ExoScannerConfig get() {
        if (config == null) {
            return loadOrCreate();
        }
        return config;
    }

    public void save() {
        // Persist config and refresh derived caches.
        if (config == null) {
            return;
        }
        try (Writer writer = Files.newBufferedWriter(configPath)) {
            GSON.toJson(config, writer);
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to write config.", e);
        }
        ColorReferenceManager.get().reload();
        SeymourTierService.clearCache();
    }

    public void setScanIntervalSeconds(int seconds) {
        // Normalize legacy and current fields together.
        int normalized = Math.max(1, seconds);
        config.scanIntervalSeconds = normalized;
        config.scanInterval = normalized;
        save();
    }

    public void setScanningEnabled(boolean enabled) {
        config.scanningEnabled = enabled;
        config.enableScanning = enabled;
        save();
    }

    public void setEnabledPieceTypes(Set<String> pieces) {
        config.enabledPieceTypes = normalizeSet(pieces);
        save();
    }

    public void setEnabledArmorSets(Set<String> sets) {
        config.enabledArmorSets = normalizeSet(sets);
        save();
    }

    public void setNotifyOnExotic(boolean enabled) {
        config.notifyOnExotic = enabled;
        save();
    }

    public void setNotifyOnOwnerTransfer(boolean enabled) {
        config.notifyOnOwnerTransfer = enabled;
        save();
    }

    public void setDebugScanAllLeather(boolean enabled) {
        config.debugScanAllLeather = enabled;
        save();
    }

    public void setDebugLogging(boolean enabled) {
        config.debugLogging = enabled;
        config.debugArmorScan = enabled;
        config.debugApiScan = enabled;
        config.debugLobbyScan = enabled;
        save();
    }

    public void setDebugAll(boolean enabled) {
        config.debugArmorScan = enabled;
        config.debugApiScan = enabled;
        config.debugLobbyScan = enabled;
        config.debugTrace = enabled;
        config.debugLogging = enabled;
        save();
    }

    public void setDebugArmorScan(boolean enabled) {
        config.debugArmorScan = enabled;
        config.debugLogging = config.debugArmorScan || config.debugApiScan || config.debugLobbyScan;
        save();
    }

    public void setDebugApiScan(boolean enabled) {
        config.debugApiScan = enabled;
        config.debugLogging = config.debugArmorScan || config.debugApiScan || config.debugLobbyScan;
        save();
    }

    public void setDebugLobbyScan(boolean enabled) {
        config.debugLobbyScan = enabled;
        config.debugLogging = config.debugArmorScan || config.debugApiScan || config.debugLobbyScan || config.debugTrace;
        save();
    }

    public void setDebugTrace(boolean enabled) {
        config.debugTrace = enabled;
        config.debugLogging = config.debugArmorScan || config.debugApiScan || config.debugLobbyScan || config.debugTrace;
        save();
    }

    public void setNotifyOnMissingArmorUuid(boolean enabled) {
        config.notifyOnMissingArmorUuid = enabled;
        save();
    }

    public void setPlayerTrackingEnabled(boolean enabled) {
        config.enablePlayerTracking = enabled;
        save();
    }

    public void setTracerLineWidth(double width) {
        double clamped = Math.max(0.5, Math.min(8.0, width));
        config.tracerLineWidth = clamped;
        save();
    }

    public void setTracerLineColor(int rgb) {
        int cleaned = rgb & 0xFFFFFF;
        config.tracerLineColor = cleaned;
        save();
    }

    public void setTracerAutoDisableRadius(double radius) {
        double clamped = Math.max(0.5, Math.min(50.0, radius));
        config.tracerAutoDisableRadius = clamped;
        save();
    }

    public void setTracerLineOffset(double offset) {
        double clamped = Math.max(0.0, Math.min(1.0, offset));
        config.tracerLineOffset = clamped;
        save();
    }

    public void setAutoTraceEnabled(boolean enabled) {
        config.enableAutoTrace = enabled;
        save();
    }

    public void setAutoTracePlayers(List<String> players) {
        config.autoTracePlayers = normalizeList(players);
        save();
    }

    public void setAutoTraceMaxTargets(int maxTargets) {
        int clamped = Math.max(1, Math.min(5, maxTargets));
        config.autoTraceMaxTargets = clamped;
        save();
    }

    public void setUseCie76(boolean enabled) {
        config.useCie76 = enabled;
        config.defaultMetric = enabled ? 76 : 2000;
        save();
    }

    public void setApiKey(String apiKey) {
        String normalized = normalizeApiKey(apiKey);
        config.apiKey = normalized == null ? "" : normalized;
        if (config.apiKeys == null || config.apiKeys.length == 0) {
            config.apiKeys = new String[] {"", "", ""};
        }
        config.apiKeys[0] = config.apiKey;
        save();
    }

    public static String normalizeApiKey(String apiKey) {
        if (apiKey == null) {
            return null;
        }
        String trimmed = apiKey.trim();
        if (trimmed.isEmpty()) {
            return null;
        }
        if (trimmed.matches("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")) {
            return trimmed;
        }
        if (trimmed.matches("^[0-9a-fA-F]{32}$")) {
            return trimmed.substring(0, 8) + "-" +
                trimmed.substring(8, 12) + "-" +
                trimmed.substring(12, 16) + "-" +
                trimmed.substring(16, 20) + "-" +
                trimmed.substring(20);
        }
        return null;
    }

    public void setLobbyCacheDays(int days) {
        config.lobbyCacheDays = Math.max(0, days);
        save();
    }

    public void setPlayerCacheEnabled(boolean enabled) {
        config.enablePlayerCache = enabled;
        save();
    }

    public void setInventoryHighlightEnabled(boolean enabled) {
        config.enableInventoryHighlight = enabled;
        save();
    }

    public void setInventoryHighlightStyle(InventoryHighlightStyle style) {
        config.inventoryHighlightStyle = style == null ? InventoryHighlightStyle.TRANSLUCENT : style;
        save();
    }

    public void setInventoryHighlightColor(int rgb) {
        int cleaned = rgb & 0xFFFFFF;
        config.inventoryHighlightColor = cleaned;
        save();
    }

    // Normalize config values and apply legacy migrations.
    private void normalize() {
        config.enabledPieceTypes = normalizeSet(config.enabledPieceTypes);
        config.enabledArmorSets = normalizeSet(config.enabledArmorSets);
        if (config.apiKeys == null || config.apiKeys.length < 3) {
            config.apiKeys = new String[] {"", "", ""};
        }
        if (config.apiKeys[0] == null) {
            config.apiKeys[0] = "";
        }
        if (config.apiKeys[1] == null) {
            config.apiKeys[1] = "";
        }
        if (config.apiKeys[2] == null) {
            config.apiKeys[2] = "";
        }
        for (int i = 0; i < config.apiKeys.length; i++) {
            String normalized = normalizeApiKey(config.apiKeys[i]);
            config.apiKeys[i] = normalized == null ? "" : normalized;
        }
        if (config.apiKey != null && !config.apiKey.isBlank() && config.apiKeys[0].isBlank()) {
            String normalized = normalizeApiKey(config.apiKey);
            if (normalized != null) {
                config.apiKeys[0] = normalized;
            }
        }
        config.apiKey = config.apiKeys[0];
        if (config.scanInterval < 1) {
            config.scanInterval = config.scanIntervalSeconds > 0 ? config.scanIntervalSeconds : 5;
        }
        if (config.scanIntervalSeconds < 1) {
            config.scanIntervalSeconds = config.scanInterval;
        }
        if (config.lobbyCacheDays < 0) {
            config.lobbyCacheDays = 30;
        }
        if (config.defaultMetric != 76 && config.defaultMetric != 2000) {
            config.defaultMetric = config.useCie76 ? 76 : 2000;
        }
        if (config.defaultRetentionDays < 1) {
            config.defaultRetentionDays = 30;
        }
        if (config.inventoryHighlightStyle == null) {
            config.inventoryHighlightStyle = InventoryHighlightStyle.TRANSLUCENT;
        }
        if (config.inventoryHighlightColor < 0) {
            config.inventoryHighlightColor = 0xFF5555;
        }
        if (config.dbPath != null) {
            config.dbPath = config.dbPath.trim();
        }
        if (config.debugLogging) {
            boolean anySet = config.debugArmorScan || config.debugApiScan || config.debugLobbyScan || config.debugTrace;
            if (!anySet) {
                config.debugArmorScan = true;
                config.debugApiScan = true;
                config.debugLobbyScan = true;
                config.debugTrace = true;
            }
        }
        config.debugLogging = config.debugArmorScan || config.debugApiScan || config.debugLobbyScan || config.debugTrace;
        config.enableScanning = config.enableScanning || config.scanningEnabled;
        config.scanningEnabled = config.enableScanning;
        if (config.autoScanDebounceSeconds < 3 || config.autoScanDebounceSeconds > 12) {
            config.autoScanDebounceSeconds = 6;
        }
        if (config.autoScanMinGapSeconds < 10) {
            config.autoScanMinGapSeconds = 75;
        }
        if (config.autoScanJitterMillis < 0) {
            config.autoScanJitterMillis = 750;
        }
        if (config.autoScanMaxRequestsPerScan < 50) {
            config.autoScanMaxRequestsPerScan = 300;
        }
        if (config.autoScanMaxPlayersPerScan < 10) {
            config.autoScanMaxPlayersPerScan = 200;
        }
        if (config.keyDailyCap < 1000) {
            config.keyDailyCap = 5000;
        }
        if (config.keyBurstThreshold < 50) {
            config.keyBurstThreshold = 300;
        }
        if (config.keyBurstWindowMinutes < 1) {
            config.keyBurstWindowMinutes = 5;
        }
        if (config.keyCooldownMinutes < 1) {
            config.keyCooldownMinutes = 10;
        }
        if (config.autoPauseMinutesOnAllKeysExhausted < 1) {
            config.autoPauseMinutesOnAllKeysExhausted = 30;
        }
        config.autoTracePlayers = normalizeList(config.autoTracePlayers);
        if (config.autoTraceMaxTargets < 1 || config.autoTraceMaxTargets > 5) {
            config.autoTraceMaxTargets = 3;
        }
        if (config.tracerLineOffset < 0.0 || config.tracerLineOffset > 1.0) {
            config.tracerLineOffset = 0.1;
        }
        save();
    }

    // Ensure default resource files exist alongside config.
    private void ensureDefaultColors() {
        seedDefaultFile("colors.json");
        seedDefaultFile("checklistdata.json");
    }

    private void seedDefaultFile(String resourceName) {
        Path target = FabricLoader.getInstance().getConfigDir().resolve(resourceName);
        if (Files.exists(target)) {
            return;
        }
        try {
            Files.createDirectories(target.getParent());
            try (var input = ConfigManager.class.getResourceAsStream("/" + resourceName)) {
                if (input == null) {
                    ExoScannerClient.LOGGER.warn("Default {} not found in resources.", resourceName);
                    return;
                }
                Files.copy(input, target);
            }
        } catch (IOException e) {
            ExoScannerClient.LOGGER.warn("Failed to seed default {}.", resourceName, e);
        }
    }

    private static Set<String> normalizeSet(Set<String> input) {
        Set<String> output = new TreeSet<>();
        if (input == null) {
            return output;
        }
        for (String value : input) {
            if (value == null || value.trim().isEmpty()) {
                continue;
            }
            output.add(value.trim().toUpperCase(Locale.ROOT));
        }
        return output;
    }

    private static List<String> normalizeList(List<String> input) {
        List<String> output = new java.util.ArrayList<>();
        if (input == null) {
            return output;
        }
        for (String value : input) {
            if (value == null) {
                continue;
            }
            String trimmed = value.trim();
            if (trimmed.isEmpty()) {
                continue;
            }
            if (!output.contains(trimmed)) {
                output.add(trimmed);
            }
        }
        return output;
    }
}
